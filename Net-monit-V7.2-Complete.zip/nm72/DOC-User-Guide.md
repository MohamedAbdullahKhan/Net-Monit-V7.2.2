# Net-monit V7.2 — User Guide

**© 2024–2026 Net-monit V7.2 — Developed by Abdullah — InfoXtek.com**

---

## 1. Signing In

Open the dashboard address your administrator gave you (typically
`http://<server>:5072`). Click **Sign in** (top-right), enter your email and
token, and click **Sign in**. Your role decides what you can see and do:

| Capability | User | Admin |
|---|---|---|
| View Infrastructure Overview | ✅ | ✅ |
| See device IP addresses | — | ✅ |
| Rearrange / resize your own dashboard tiles | ✅ | ✅ |
| Run a Speed Test | ✅ | ✅ |
| Run a quick URL check | ✅ (no login needed) | ✅ |
| Add/edit/delete devices, run a Network Scan | — | ✅ |
| Change Settings, manage users | — | ✅ |
| Activate the license | — | ✅ |
| Personalise theme & accent colour | ✅ | ✅ |

---

## 2. Infrastructure Overview (the main dashboard)

At the top you'll see four live summary cards:

- **WAN Download / WAN Upload** — most recent Speed Test result (Mbps)
- **Network Devices** — how many of your monitored network devices are online
- **Web Application Availability** — how many monitored URLs are responding normally

Below that, **category tabs** let you filter the tile grid: General (everything),
Network, Firewall, Windows, Linux, or URL.

### Status colours
| Colour | Meaning |
|---|---|
| 🟢 Green | Reachable, all metrics normal |
| 🟡 Yellow | Warning — a metric passed its warning threshold |
| 🔴 Red | Critical — a metric passed its critical threshold |
| ⚪ Grey | Offline / unreachable |

### Grid vs List view
Toggle between a visual card grid and a compact table using the buttons above
the tiles. Your choice is remembered for your account.

---

## 3. Organising Your Dashboard

1. Click **Edit Dashboard** to enter edit mode.
2. **Drag** any tile to reposition it; **drag the corner handle** to resize it.
3. Click the eye icon on a tile to hide it (it keeps monitoring in the
   background — hiding only affects what you see).
4. Click **Save Layout** — your arrangement is saved permanently to your
   account and will look exactly the same the next time you log in, on any
   device or browser.
5. Click **Reset** to go back to the default order at any time.

### Adding tiles
Click **+ Add Tile**:
- **Existing Device** tab — a checkbox list of every device that exists.
  Tick a box to add that device's tile to your dashboard; untick to remove it
  from view. Use the filter box to search by name or host.
- **New Device** tab — create a brand-new device to monitor from scratch
  (full configuration is available afterwards on the Devices page, if you're
  an Admin).

---

## 4. Speed Test

Go to **Speed Test** and click **Run Speed Test** (takes 20–40 seconds). You'll see:
- A circular gauge showing your download speed
- Upload speed and ping
- **ISP / carrier name** and **public IP address**
- **Jitter** — how stable your connection is (lower is better)

Every test is saved to your history table and chart below, and can be
exported to a CSV file with the **Export CSV** button.

---

## 5. URL Monitor

The **Quick URL Check** box lets anyone test any URL immediately — no sign-in
required. Enter a URL, optionally an expected HTTP status code and a keyword
that must appear in the response, and click **Check Now**.

The **Monitored URLs** list below shows every URL configured for ongoing
monitoring, with live status, response time, and days remaining until its
SSL certificate expires.

---

## 6. Network Scan

Enter a subnet (e.g. `192.168.1.0/24`) or click **Auto-detect** to have Net-monit
suggest the subnets your server can already see. Click **Scan Network**.

Once results appear, **click any row** (or the small arrow on the right) to
expand it and see:
- Full hostname
- MAC address
- Manufacturer/vendor (identified from the MAC address)
- Device type (Windows Server, Linux Host, Network Printer, etc.)
- Every open port found, with its identified service name

Tick the checkboxes next to hosts you want to keep an eye on and click
**Add Selected to Monitoring**.

*(Running a scan and adding devices requires an Admin session; viewing past
scan results does not.)*

---

## 7. Appearance

Click **Settings → Appearance** to choose:
- **Theme**: Dark, Light, or Match System
- **Accent colour**: pick from 7 presets or choose any custom colour

This preference is saved to your account and follows you to any device you
sign in from.

---

## 8. Signing Out

Click **Sign out** (top-right). Your session ends immediately and the page
reverts to the anonymous view right away — no manual refresh needed.

---

*Net-monit V7.2 — User Guide*
*© 2024–2026 Net-monit V7.2 — Developed by Abdullah — InfoXtek.com*
