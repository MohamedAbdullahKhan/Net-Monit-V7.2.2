# Net-monit V7.2 — Administrator Guide

**Copyright © 2024–2026 Net-monit V7.2 — Developed by Abdullah — InfoXtek.com**
**Contact: abuabdullah.be@outlook.com**

---

## 1. Quick Start

### Windows
1. Extract the Net-monit V7.2 package to any folder.
2. Right-click `Setup.bat` → **Run as administrator** (it auto-elevates if you forget).
3. `Setup.bat` finds Python automatically. If Python 3.9+ is not installed, it downloads
   and silently installs Python 3.11 for you before continuing — no manual steps required.
4. The Setup Wizard (a proper resizable window, not a console) walks you through 7 steps:
   Welcome → Python → License → Location → Options → Install → Finish.
5. Open **http://localhost:5072** in your browser.
6. Sign in with the default credentials below and **change them immediately**.

| Field | Default value |
|---|---|
| Email | `admin@email.com` |
| Password/Token | `Admin@54321$` |
| Port | `5072` |
| Windows Service name | `Net_Monit_V72` |

### Linux
```bash
sudo bash setup.sh --port 5072 --path /opt/netmonit-v72
```
Installs system packages, creates a Python virtual environment, registers a
`systemd` service, opens the firewall port, and starts the service automatically.

---

## 2. What's New in V7.2

| Area | What changed |
|---|---|
| Navigation | Reorganised — left sidebar now holds every primary workflow page (Overview, Devices, Speed Test, Sites Monitor, Network Scan, Settings, Alert Event Logs); the top bar holds only Admin Panel, License, and About. |
| Alert Event Logs | New dedicated page (`/alerts`, sidebar link with a live open-count badge). Every warning/critical automatically opens a card with **Acknowledge** and **Resolve Event** buttons. Acknowledging suppresses further escalation for that device+metric until 23:59:59 that day; if still unhealthy the next day it escalates again automatically. Resolving closes it immediately and sends the normal recovery notification — no re-verification required. |
| Speed Test | Rewritten to **average over ~15 seconds** across repeated samples (like a real speedometer test) instead of one instantaneous reading, with a live ticking timer and animated gauge sweep while it runs. |
| Sites Monitor | Fixed a false-offline bug where a working site could show OFFLINE on its scheduled check moments after passing a manual Quick Check — a flaky secondary SSL-expiry probe could interfere with reachability; it's now fully isolated and can never falsely flag a reachable site as down. Full **Edit** capability added for every monitored site. |
| Infrastructure Overview | Fixed: dashboard going blank after navigating away and back (now auto-retries instead of silently failing); category tabs (General/Network/Firewall/Windows/Linux/Sites) were previously non-functional — now fully wired with live counts; the Edit Dashboard button was permanently hidden due to a backend field that was never sent — fixed. |
| Add Tile | The existing-device picker is now grouped by category (Sites, Network Devices, Firewalls, Windows, Linux) instead of one flat list. |
| Show on Dashboard | New checkbox on both the Devices form and the Sites Monitor form — leave checked to show the tile immediately, or uncheck to keep the device monitored in the background without cluttering the dashboard. |

---

## 3. Setup Wizard — Step by Step

| Step | Page | What happens |
|---|---|---|
| 1 | Welcome | Feature overview and system requirements |
| 2 | Python | Auto-detects Python 3.9+. Offers one-click silent install of Python 3.11 if missing, with a visible download/install progress indicator |
| 3 | License | Full EULA text; the Next button unlocks only once you tick "I agree" |
| 4 | Location | Install folder, dashboard port (validated against the browser-blocked port list — see §4), Windows service name |
| 5 | Options | Virtual environment, firewall rule, auto-start, desktop shortcut |
| 6 | Install | Live scrolling log: directory creation, file copy, `pip install -r requirements.txt`, service registration, service start (polls up to 36 seconds for the RUNNING state and shows the reason if it doesn't reach it) |
| 7 | Finish | Summary card with your chosen port/path/service name, and a one-click "open in browser" checkbox |

The wizard is a native resizable window (built with Python's Tk toolkit), not a
console application — every field, checkbox, and button is fully interactive, and
the layout adapts responsively if you resize the window.

---

## 4. Choosing a Port

Ports **6000–6063** are permanently blocked by every major browser (Chrome,
Firefox, Edge) as a security measure against cross-protocol attacks — a server
listening on one of these will show `ERR_UNSAFE_PORT` and never load, no matter
how correctly the server itself is configured.

The Setup Wizard validates your chosen port against the full blocked-port list
and rejects unsafe choices before installation begins. The V7.2 default, **5072**,
is verified safe. If you need to pick a different port, good alternatives include
5072–5099, 7000–7099, 8080, 8181, 8443, 9000.

**Whatever port you choose during setup is propagated automatically** to:
`config.yaml` (`server.port`), the Windows Service registry environment
(`NETMON_PORT`), the firewall rule, and the "open in browser" shortcut — you
never need to edit multiple files by hand.

---

## 5. Service Management

### Windows
```cmd
python install_service.py install    REM Register service (also called by the wizard)
python install_service.py start
python install_service.py stop
python install_service.py restart
python install_service.py remove
python install_service.py status
python install_service.py debug      REM Run in the foreground for troubleshooting
```
If a service ever fails to start with **Error 1053**, run
`scripts\windows\Install-Service.ps1` as Administrator — it re-registers the
service via `sc.exe` with the correct interpreter path and waits for confirmation
that it reached the RUNNING state, printing the last log lines if it doesn't.

### Linux
```bash
sudo systemctl start   netmonit-v72
sudo systemctl stop    netmonit-v72
sudo systemctl restart netmonit-v72
sudo systemctl status  netmonit-v72
sudo journalctl -u netmonit-v72 -f     # live logs
```

### Uninstalling
- Windows: run `Uninstall.bat` as Administrator (stops the service, removes the
  registry key, firewall rule, and desktop shortcut; your `data/` folder is preserved).
- Linux: `sudo bash scripts/linux/uninstall.sh`

---

## 6. SMTP Email Configuration

Settings → Email / SMTP:

| Field | Notes |
|---|---|
| SMTP Host | e.g. `smtp-mail.outlook.com`, `smtp.gmail.com` |
| Port | `587` (TLS) or `465` (SSL) |
| Username | Full sending email address |
| Password | An **app password**, not your account password |
| From address | Single address, no commas |
| Admin emails | Receive every alert |
| Support emails | CC'd on Warning-and-above |
| Manager emails | CC'd on Critical only |

Use the environment variable `NETMON_SMTP_PASSWORD` instead of storing the
password in `config.yaml` if you prefer not to keep secrets in plain text on disk.

---

## 7. Monitoring Features

### 7.1 Device checks
| Method | Use case | Credentials |
|---|---|---|
| `ping` | Any host | None |
| `snmp` | Routers, switches | Community string |
| `powershell` | Windows servers | Username + password (Fernet-encrypted at rest) |
| `ssh` | Linux/Unix servers | Username + password or key file |
| `disk_usage` | Shares/mounts | Path only |
| `url` | Web applications | See §7.2 |

### 7.2 URL Monitor
Monitors HTTP(S) endpoints for status code, response time, SSL certificate
expiry (warns at 30 days, fails at 0), and keyword presence/absence in the
response body. A quick, no-login "Check Now" box is available for one-off
tests; adding a URL to permanent monitoring requires an Admin session.

### 7.3 Speed Test (WAN Telemetry)
Runs a real download/upload/latency/jitter test against Cloudflare's speed
endpoint (falling back automatically if the `speedtest-cli` Python package
isn't installed), plus an ISP/public-IP lookup. Results feed the Infrastructure
Overview dashboard's WAN cards and are stored in history with CSV export.
Running a test requires being signed in; viewing history and the "Purge Logs"
button (which deletes all history) require Admin.

### 7.4 Network Scanner
Scans a subnet (up to /16) using ICMP ping with a TCP fallback, ARP-table MAC
lookup, reverse DNS, and a configurable TCP port probe across 20 common ports.
Each result row expands (click anywhere on the row, or the chevron on the
right) to reveal the full hostname, MAC address, matched vendor (from a
40+ entry OUI table), device type classification, and every open port with
its identified service name. Selected hosts can be added to permanent
monitoring in one click, choosing ping/SNMP/SSH/PowerShell as the method.

---

## 8. Infrastructure Overview Dashboard

- **Category tabs** (General / Network / Firewall / Windows / Linux / URL)
  filter the tile grid by device type — General shows everything.
- **Edit mode**: click the pencil/Edit icon to drag-reposition and resize tiles
  freely. Click **Save Layout** to persist your arrangement permanently to
  your account — it survives logout, browser restarts, and page refreshes.
- **Grid / List toggle** switches between visual cards and a compact table;
  your choice is remembered per account.
- **+ Add Tile** has two tabs:
  - **Existing Device** — a checkbox list of every configured device; tick to
    show it on your dashboard, untick to hide it (the device keeps monitoring
    in the background either way).
  - **New Device** — the full device-creation form (ping/SNMP/SSH/PowerShell/
    disk/URL), same as the Devices page.

---

## 9. Appearance / Theming

Every signed-in user can set their own theme and accent colour under
**Settings → Appearance**:
- **Theme**: Dark, Light, or Match System.
- **Accent colour**: 7 presets or a custom colour picker — applied to buttons,
  links, active tab indicators, and highlights across the whole app.

Administrators additionally control the **organisation-wide default** shown to
anonymous visitors and any user who hasn't personalised their own preference,
under **Admin Panel → System → Default Appearance**.

---

## 10. License Activation

1. Settings → License shows your unique **Device ID** and **Activation Code**
   (both derived from this machine's hardware — 16 hex characters each).
2. Click **Copy Both Values** and email them to `abuabdullah.be@outlook.com`.
3. You'll receive a free `XXXXX-XXXXX` key by return email.
4. Enter it under **Enter License Key → Activate**.

Net-monit is free software; a license key is required after the 30-day trial
but there is no charge for it — redistribution/resale of the software itself
is not permitted without written permission.

---

## 11. Backup

Back up these three items regularly:

| File | Why |
|---|---|
| `data/monitor.db` | All device history, alerts, users, layouts, preferences |
| `data/secret.key` | Fernet encryption key — losing this makes stored device credentials unreadable |
| `config.yaml` | SMTP settings, port, device list |

---

## 12. Troubleshooting

| Symptom | Fix |
|---|---|
| `ERR_UNSAFE_PORT` in the browser | You (or a previous config) picked a port in the 6000–6063 range. Change `server.port` in `config.yaml` to something like 5072, restart the service, and update the firewall rule/shortcut to match. |
| Service won't start / Error 1053 | Run `scripts\windows\Install-Service.ps1` as Administrator, or `python install_service.py debug` to see the exact Python error in the console. |
| Setup.bat does nothing after "Running as Administrator - OK" | This was a batch-scripting hang in older builds; V7.2's `Setup.bat` uses simple sequential Python detection with visible progress at every step and cannot silently hang. If you still see no output, share the exact last line printed. |
| Network Scan page stuck loading forever | Fixed in V7.2 — a stray HTML tag inside a JavaScript template literal was silently breaking the entire page script. Confirmed fixed and validated. |
| Sign out doesn't visibly change anything | Fixed in V7.2 — the sign-out handler now updates the topbar immediately instead of a dead code path left over from an earlier UI version. |
| New device doesn't appear on the dashboard | Fixed in V7.2 — adding a device now triggers an immediate dashboard refresh, plus a follow-up refresh 2.5 seconds later once the scheduler completes its first poll. |
| Tile positions reset after refresh | Fixed — layouts are stored per user in the database (`user_prefs_kv`, key `tile_layout_v2`) and reloaded via `/api/dashboard/layout`, not a browser-local or shared-global setting. |

---

*Net-monit V7.2 — Administrator Guide*
*© 2024–2026 Net-monit V7.2 — Developed by Abdullah — InfoXtek.com*
