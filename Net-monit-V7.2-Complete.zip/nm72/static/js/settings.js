/* =============================================================================
 * Net-monit V3.5  –  settings.js  (FIXED)
 * FIXES:
 *  • saveEscGlobal / saveGlobalThresh / saveNotif — 404 bug fixed (routes reordered in app.py)
 *  • Escalation: toggle per-level (disabled by default); choose receivers per level
 *  • Devices quick-add: credential fields per method
 *  • Thresholds save/reset now works
 *  • Audit tab split: User/Device Audit + Alert Log
 *  • Dashboard tile manual refresh button (via /api/status?device=id)
 * ============================================================================= */
"use strict";

const parseEmails = t => t.split(/[\n,]+/).map(s=>s.trim()).filter(Boolean);
const fmtEmails   = a => (a||[]).join("\n");
const esc = s => String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const timeAgo = ts => {
  if(!ts) return "never";
  const d = Math.max(0, Date.now()/1000-ts);
  if(d<60)    return `${Math.floor(d)}s ago`;
  if(d<3600)  return `${Math.floor(d/60)}m ago`;
  if(d<86400) return `${Math.floor(d/3600)}h ago`;
  return `${Math.floor(d/86400)}d ago`;
};
const v = id => document.getElementById(id);
const setStatus = (id, msg, ok) => {
  const el = v(id); if(!el) return;
  el.textContent = msg;
  el.style.color = ok ? "var(--status-ok)" : "var(--status-critical)";
  setTimeout(()=>{ el.textContent=""; }, 5000);
};

const METRICS = ["latency_ms","packet_loss_pct","cpu_pct","memory_pct","disk_pct","bandwidth_pct"];
const METRIC_LABELS = {latency_ms:"Latency",packet_loss_pct:"Packet Loss",cpu_pct:"CPU",memory_pct:"Memory",disk_pct:"Disk",bandwidth_pct:"Bandwidth"};
const METRIC_UNITS  = {latency_ms:"ms",packet_loss_pct:"%",cpu_pct:"%",memory_pct:"%",disk_pct:"%",bandwidth_pct:"%"};
const BUILT_IN_DEFS = {latency_ms:{w:100,c:300},packet_loss_pct:{w:5,c:20},cpu_pct:{w:75,c:90},memory_pct:{w:80,c:95},disk_pct:{w:80,c:95},bandwidth_pct:{w:70,c:90}};

// Metrics available per check method
const METHOD_METRICS = {
  ping:        ["latency_ms","packet_loss_pct"],
  snmp:        ["latency_ms","packet_loss_pct","cpu_pct","bandwidth_pct"],
  powershell:  ["latency_ms","packet_loss_pct","cpu_pct","memory_pct","disk_pct","bandwidth_pct"],
  ssh:         ["latency_ms","packet_loss_pct","cpu_pct","memory_pct","disk_pct"],
  disk_usage:  ["disk_pct","latency_ms"],
};

let _allKnownEmails = [];

// ── Access gate ───────────────────────────────────────────────────────────
function checkAccess(){
  const role = sessionStorage.getItem("netmon_role");
  const sess = getSession();
  const isAdm = role==="admin" && !!sess;
  v("settings-locked")  && (v("settings-locked").style.display  = isAdm ? "none" : "");
  v("settings-content") && (v("settings-content").style.display = isAdm ? "" : "none");
  if(isAdm) initAll();
}
function onAdminLogin()  { checkAccess(); }
function onAdminLogout() { checkAccess(); }

// ── Tab switching ─────────────────────────────────────────────────────────
function switchTab(name){
  document.querySelectorAll(".stab").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));
  document.querySelectorAll(".stab-panel").forEach(p=>p.classList.toggle("active",p.id==="tab-"+name));
  TAB_LOADERS[name] && TAB_LOADERS[name]();
}
const TAB_LOADERS = {
  email:loadSmtp, notifications:loadNotifTab, escalation:loadEscTab,
  thresholds:loadThreshTab, devices:loadDevicesTab, users:loadUsersTab,
  audit:loadAuditTab, alerts:loadAlerts
};

/* ═══════════════════════════════════════════════════════════
   SMTP
═══════════════════════════════════════════════════════════ */
async function loadSmtp(){
  try{
    const r=await fetch("/api/settings/smtp",{headers:{"X-Session-Token":getSession()}});
    if(!r.ok) return;
    const s=await r.json();
    ["s-enabled","s-host","s-port","s-tls","s-username","s-from","s-resend"].forEach(id=>{
      const key=id.replace("s-","").replace(/-/g,"_");
      const map={"s-enabled":"enabled","s-host":"host","s-port":"port","s-tls":"use_tls","s-username":"username","s-from":"from_address","s-resend":"resend_interval_minutes"};
      if(v(id) && s[map[id]]!=null) v(id).value = String(s[map[id]]);
    });
    v("s-admin-emails")   && (v("s-admin-emails").value   = fmtEmails(s.admin_emails||s.to_addresses||[]));
    v("s-support-emails") && (v("s-support-emails").value = fmtEmails(s.support_emails||[]));
    v("s-manager-emails") && (v("s-manager-emails").value = fmtEmails(s.manager_emails||[]));
  }catch(e){ console.error("loadSmtp",e); }
}
async function saveSmtp(){
  const payload={
    enabled:v("s-enabled")?.value==="true",
    host:v("s-host")?.value.trim()||"",
    port:parseInt(v("s-port")?.value||"587"),
    use_tls:v("s-tls")?.value!=="false",
    username:v("s-username")?.value.trim()||"",
    from_address:v("s-from")?.value.trim()||"",
    resend_interval_minutes:parseInt(v("s-resend")?.value||"30"),
    admin_emails:parseEmails(v("s-admin-emails")?.value||""),
    support_emails:parseEmails(v("s-support-emails")?.value||""),
    manager_emails:parseEmails(v("s-manager-emails")?.value||""),
  };
  payload.to_addresses=payload.admin_emails;
  const pw=v("s-password")?.value; if(pw) payload.password=pw;
  const r=await fetch("/api/settings/smtp",{method:"POST",headers:authHeaders(),body:JSON.stringify(payload)});
  setStatus("s-smtp-status",r.ok?"Saved ✓":"Save failed — check server log",r.ok);
  if(r.ok && v("s-password")) v("s-password").value="";
}
async function testEmail(state){
  const r=await fetch("/api/settings/test-email",{method:"POST",headers:authHeaders(),body:JSON.stringify({state})});
  const d=await r.json();
  showToast(d.ok?`Test ${state} email sent ✓`:`Failed: ${d.message}`,d.ok?"success":"error");
}

/* ═══════════════════════════════════════════════════════════
   NOTIFICATIONS
═══════════════════════════════════════════════════════════ */
async function loadNotifTab(){
  try{
    const r=await fetch("/api/settings/notifications",{headers:{"X-Session-Token":getSession()}});
    if(r.ok){
      const s=await r.json();
      v("n-send-warn")    && (v("n-send-warn").value    = String(s.send_on_warning   !==false));
      v("n-send-crit")    && (v("n-send-crit").value    = String(s.send_on_critical  !==false));
      v("n-send-recov")   && (v("n-send-recov").value   = String(s.send_on_recovery  !==false));
      v("n-send-offline") && (v("n-send-offline").value = String(s.send_on_offline   !==false));
      v("n-resend-warn")  && (v("n-resend-warn").value  = s.resend_warn_minutes||60);
      v("n-resend-crit")  && (v("n-resend-crit").value  = s.resend_crit_minutes||30);
    }
  }catch(e){}
  loadNotifDeviceTable();
}
async function saveNotif(){
  const payload={
    send_on_warning: v("n-send-warn")?.value!=="false",
    send_on_critical:v("n-send-crit")?.value!=="false",
    send_on_recovery:v("n-send-recov")?.value!=="false",
    send_on_offline: v("n-send-offline")?.value!=="false",
    resend_warn_minutes:parseInt(v("n-resend-warn")?.value||60),
    resend_crit_minutes:parseInt(v("n-resend-crit")?.value||30),
  };
  const r=await fetch("/api/settings/notifications",{method:"POST",headers:authHeaders(),body:JSON.stringify(payload)});
  setStatus("s-notif-status",r.ok?"Saved ✓":"Save failed — check server log",r.ok);
}
async function loadNotifDeviceTable(){
  try{
    const devR=await fetch("/api/devices",{headers:{"X-Session-Token":getSession()}});
    const devices=await devR.json();
    const tbody=v("notif-device-tbody"); if(!tbody) return;
    const notifMap={};
    for(const d of devices){
      try{const nr=await fetch(`/api/devices/${encodeURIComponent(d.id)}/notify`,{headers:{"X-Session-Token":getSession()}});if(nr.ok)notifMap[d.id]=await nr.json();}catch(_){}
    }
    tbody.innerHTML=devices.map(d=>{
      const n=notifMap[d.id]||{};
      const en=n.notifications_enabled!==0;
      const emails=(n.notify_emails||[]).length?n.notify_emails.slice(0,2).join(", ")+(n.notify_emails.length>2?` +${n.notify_emails.length-2}…`:""):"<span style='color:var(--text-muted)'>admin (default)</span>";
      return `<tr>
        <td><strong>${esc(d.name)}</strong></td>
        <td><span style="color:${en?"var(--status-ok)":"var(--text-muted)"}">${en?"● Enabled":"○ Disabled"}</span></td>
        <td style="font-size:12px">${emails}</td>
        <td><button class="btn secondary small" onclick="openSettNotify('${esc(d.id)}','${esc(d.name)}')">Edit</button></td>
      </tr>`;
    }).join("")||`<tr><td colspan="4" style="color:var(--text-muted);text-align:center;padding:16px">No devices</td></tr>`;
  }catch(e){}
}

/* ═══════════════════════════════════════════════════════════
   ESCALATION  (FIXED: toggle per level, default=disabled)
═══════════════════════════════════════════════════════════ */
// State object for the 3 toggle levels
const ESC_GLOBAL = { l1:false, l2:false, l3:false };

async function loadEscTab(){
  try{
    const gr=await fetch("/api/admin/email-groups",{headers:{"X-Session-Token":getSession()}});
    if(gr.ok){ const g=await gr.json(); _allKnownEmails=g.all_emails||[]; }
  }catch(_){}
  try{
    const r=await fetch("/api/settings/escalation-defaults",{headers:{"X-Session-Token":getSession()}});
    if(r.ok){
      const s=await r.json();
      // Check if any emails exist to decide toggle state
      ESC_GLOBAL.l1 = (s.escalation_emails_l1||[]).length>0 || (s.escalation_after_sec_l1>0 && s._l1_enabled===true);
      ESC_GLOBAL.l2 = (s.escalation_emails_l2||[]).length>0;
      ESC_GLOBAL.l3 = (s.escalation_emails_l3||[]).length>0;
      window._escGlobalData = s;
    }
  }catch(e){}
  renderEscGlobalUI();
  loadEscDeviceTable();
}

function renderEscGlobalUI(){
  const c=v("esc-levels-container"); if(!c) return;
  const s=window._escGlobalData||{};
  const defs=[
    {n:1,key:"l1",col:"#F2B84B",sec:s.escalation_after_sec_l1||300,emails:s.escalation_emails_l1||[]},
    {n:2,key:"l2",col:"#FF8C00",sec:s.escalation_after_sec_l2||600,emails:s.escalation_emails_l2||[]},
    {n:3,key:"l3",col:"#FF5C5C",sec:s.escalation_after_sec_l3||1200,emails:s.escalation_emails_l3||[]},
  ];
  c.innerHTML=defs.map(lv=>{
    const on=ESC_GLOBAL[lv.key];
    return `<div style="border:1px solid ${on?lv.col+"44":"var(--border)"};border-radius:var(--radius-sm);
      padding:12px 14px;margin-bottom:10px;border-left:3px solid ${on?lv.col:"var(--border)"};
      transition:border .2s;opacity:${on?1:.6}">
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <label class="toggle-wrap" style="cursor:pointer;display:flex;align-items:center;gap:8px;">
          <span class="toggle-sw ${on?"on":""}" id="esc-tog-l${lv.n}" onclick="toggleEscLevel(${lv.n})"></span>
          <span style="font-size:13px;font-weight:700;color:${on?lv.col:"var(--text-muted)"};">⚡ Level ${lv.n}</span>
        </label>
        <div style="display:flex;align-items:center;gap:6px;${on?"":"opacity:.4;pointer-events:none"}">
          <label style="font-size:12px;color:var(--text-muted)">Escalate after</label>
          <input id="esc-g-sec-l${lv.n}" type="number" style="width:75px" value="${lv.sec}" min="30">
          <span style="font-size:12px;color:var(--text-muted)">seconds</span>
        </div>
      </div>
      <div style="${on?"":"opacity:.4;pointer-events:none"};margin-top:10px;">
        <label style="font-size:12px;color:var(--text-secondary)">Level ${lv.n} escalation emails</label>
        <textarea id="esc-g-emails-l${lv.n}" rows="2" class="code-textarea" style="margin-top:4px"
          placeholder="Enter email addresses (one per line)">${fmtEmails(lv.emails)}</textarea>
        ${_renderEmailPickerInline("esc-g-emails-l"+lv.n,lv.emails)}
      </div>
    </div>`;
  }).join("");
}

function toggleEscLevel(n){
  const key="l"+n;
  ESC_GLOBAL[key]=!ESC_GLOBAL[key];
  renderEscGlobalUI();
}

function _renderEmailPickerInline(taId, current){
  if(!_allKnownEmails.length) return "";
  return `<div style="margin-top:5px;display:flex;flex-wrap:wrap;gap:4px;">
    ${_allKnownEmails.map(e=>`
      <label style="display:flex;align-items:center;gap:3px;font-size:11.5px;cursor:pointer;
        padding:2px 8px;border-radius:4px;border:1px solid var(--border);background:var(--bg-hover);
        ${(current||[]).includes(e)?"border-color:var(--accent);background:rgba(79,209,197,.08)":""}">
        <input type="checkbox" data-email="${esc(e)}" data-target="${taId}"
          ${(current||[]).includes(e)?"checked":""}
          onchange="_syncEmailCb(this)"> ${esc(e)}</label>`).join("")}
  </div>`;
}

function _syncEmailCb(cb){
  const ta=document.getElementById(cb.dataset.target); if(!ta) return;
  const emails=ta.value.split(/[\n,]+/).map(s=>s.trim()).filter(Boolean);
  const email=cb.dataset.email;
  if(cb.checked){if(!emails.includes(email))emails.push(email);}
  else{const i=emails.indexOf(email);if(i>=0)emails.splice(i,1);}
  ta.value=emails.join("\n");
  // sync sibling checkboxes
  document.querySelectorAll(`input[type=checkbox][data-target="${cb.dataset.target}"][data-email="${email}"]`)
    .forEach(o=>{if(o!==cb)o.checked=cb.checked;});
}

async function saveEscGlobal(){
  const getE=n=>{const t=v(`esc-g-emails-l${n}`);return t&&ESC_GLOBAL["l"+n]?parseEmails(t.value):[];};
  const getS=n=>{const t=v(`esc-g-sec-l${n}`);return t?parseInt(t.value)||300:300;};
  const payload={
    escalation_after_sec_l1:getS(1),
    escalation_after_sec_l2:getS(2),
    escalation_after_sec_l3:getS(3),
    escalation_emails_l1:getE(1),
    escalation_emails_l2:getE(2),
    escalation_emails_l3:getE(3),
    _l1_enabled:ESC_GLOBAL.l1,
    _l2_enabled:ESC_GLOBAL.l2,
    _l3_enabled:ESC_GLOBAL.l3,
  };
  const r=await fetch("/api/settings/escalation-defaults",{method:"POST",headers:authHeaders(),body:JSON.stringify(payload)});
  if(!r.ok){
    const txt=await r.text();
    setStatus("s-esc-status",`Save failed (${r.status}) — ${txt.substring(0,120)}`,false);
    return;
  }
  setStatus("s-esc-status","Saved ✓",true);
  window._escGlobalData=payload;
}

async function applyEscToAll(){
  if(!confirm("Apply current global escalation settings to ALL devices?")) return;
  const getE=n=>{const t=v(`esc-g-emails-l${n}`);return t&&ESC_GLOBAL["l"+n]?parseEmails(t.value):[];};
  const getS=n=>{const t=v(`esc-g-sec-l${n}`);return t?parseInt(t.value)||300:300;};
  const payload={
    escalation_after_sec_l1:getS(1),escalation_after_sec_l2:getS(2),escalation_after_sec_l3:getS(3),
    escalation_emails_l1:getE(1),escalation_emails_l2:getE(2),escalation_emails_l3:getE(3),
    escalation_levels:ESC_GLOBAL.l3?3:ESC_GLOBAL.l2?2:ESC_GLOBAL.l1?1:0,
  };
  const r=await fetch("/api/settings/escalation-defaults/apply-all",{method:"POST",headers:authHeaders(),body:JSON.stringify(payload)});
  setStatus("s-esc-status",r.ok?"Applied to all devices ✓":"Failed",r.ok);
}

async function loadEscDeviceTable(){
  try{
    const devR=await fetch("/api/devices",{headers:{"X-Session-Token":getSession()}});
    const devices=await devR.json();
    const tbody=v("esc-device-tbody"); if(!tbody) return;
    const notifMap={};
    await Promise.all(devices.map(async d=>{
      try{const nr=await fetch(`/api/devices/${encodeURIComponent(d.id)}/notify`,{headers:{"X-Session-Token":getSession()}});if(nr.ok)notifMap[d.id]=await nr.json();}catch(_){}
    }));
    tbody.innerHTML=devices.map(d=>{
      const n=notifMap[d.id]||{};
      const lv=n.escalation_levels||0;
      return `<tr>
        <td><strong>${esc(d.name)}</strong></td>
        <td>${lv>0?`<span style="color:#F2B84B">${lv} level${lv>1?"s":""}</span>`:"<span style='color:var(--text-muted)'>Off</span>"}</td>
        <td style="font-size:12px">${lv>=1?`${n.escalation_after_sec_l1||300}s`:"—"}</td>
        <td style="font-size:12px">${lv>=2?`${n.escalation_after_sec_l2||600}s`:"—"}</td>
        <td><button class="btn secondary small" onclick="openSettNotify('${esc(d.id)}','${esc(d.name)}')">Edit</button></td>
      </tr>`;
    }).join("")||`<tr><td colspan="5" style="color:var(--text-muted);text-align:center;padding:16px">No devices</td></tr>`;
  }catch(e){}
}

/* ═══════════════════════════════════════════════════════════
   THRESHOLDS  (FIXED save)
═══════════════════════════════════════════════════════════ */
let _globalThresh={};
async function loadThreshTab(){
  try{
    const r=await fetch("/api/settings/thresholds",{headers:{"X-Session-Token":getSession()}});
    _globalThresh=r.ok?await r.json():{};
  }catch(e){_globalThresh={};}
  renderGlobalThreshTable();
  loadThreshDeviceTable();
}
function renderGlobalThreshTable(){
  const tbody=v("global-thresh-tbody"); if(!tbody) return;
  tbody.innerHTML=METRICS.map(m=>{
    const g=_globalThresh[m]||{}; const df=BUILT_IN_DEFS[m]||{};
    return `<tr>
      <td style="font-family:var(--font-mono);font-size:13px">${METRIC_LABELS[m]}</td>
      <td style="color:var(--text-muted);font-size:12px">${METRIC_UNITS[m]}</td>
      <td><input type="number" id="gt-w-${m}" style="width:85px" value="${g.warning!=null?g.warning:""}" placeholder="${df.w||""}"></td>
      <td><input type="number" id="gt-c-${m}" style="width:85px" value="${g.critical!=null?g.critical:""}" placeholder="${df.c||""}"></td>
      <td style="text-align:center"><input type="checkbox" id="gt-en-${m}" ${g.enabled!==false?"checked":""}></td>
    </tr>`;
  }).join("");
}
async function saveGlobalThresh(){
  const out={};
  METRICS.forEach(m=>{
    const w=v(`gt-w-${m}`);const c=v(`gt-c-${m}`);const en=v(`gt-en-${m}`);
    if(!w) return;
    out[m]={enabled:en?en.checked:true};
    if(w.value!=="") out[m].warning=parseFloat(w.value);
    if(c&&c.value!=="") out[m].critical=parseFloat(c.value);
  });
  const r=await fetch("/api/settings/thresholds",{method:"POST",headers:authHeaders(),body:JSON.stringify(out)});
  if(!r.ok){
    const txt=await r.text();
    setStatus("s-thresh-status",`Save failed (${r.status})`,false);
    console.error("Threshold save error:",txt);
    return;
  }
  _globalThresh=out;
  setStatus("s-thresh-status","Saved ✓",true);
}
function resetGlobalThresh(){
  METRICS.forEach(m=>{
    const df=BUILT_IN_DEFS[m]||{};
    if(v(`gt-w-${m}`)) v(`gt-w-${m}`).value=df.w||"";
    if(v(`gt-c-${m}`)) v(`gt-c-${m}`).value=df.c||"";
    if(v(`gt-en-${m}`)) v(`gt-en-${m}`).checked=true;
  });
  setStatus("s-thresh-status","Reset to defaults — click Save to persist",true);
}
async function loadThreshDeviceTable(){
  try{
    const devR=await fetch("/api/devices",{headers:{"X-Session-Token":getSession()}});
    const devices=await devR.json();
    const tbody=v("thresh-device-tbody"); if(!tbody) return;
    const notifMap={};
    await Promise.all(devices.map(async d=>{
      try{const nr=await fetch(`/api/devices/${encodeURIComponent(d.id)}/notify`,{headers:{"X-Session-Token":getSession()}});if(nr.ok)notifMap[d.id]=await nr.json();}catch(_){}
    }));
    tbody.innerHTML=devices.map(d=>{
      const t=(notifMap[d.id]||{}).thresholds||{};
      const fmt=m=>{
        const s=t[m]||{};const g=_globalThresh[m]||{};const df=BUILT_IN_DEFS[m]||{};
        const w=s.warning!=null?`<strong>${s.warning}</strong>`:`<span style='color:var(--text-muted)'>${g.warning||df.w||"—"}</span>`;
        const c=s.critical!=null?`<strong>${s.critical}</strong>`:`<span style='color:var(--text-muted)'>${g.critical||df.c||"—"}</span>`;
        return `${w}/${c}`;
      };
      return `<tr>
        <td><strong>${esc(d.name)}</strong></td>
        <td style="font-size:12px">${fmt("cpu_pct")}</td>
        <td style="font-size:12px">${fmt("memory_pct")}</td>
        <td style="font-size:12px">${fmt("disk_pct")}</td>
        <td style="font-size:12px">${fmt("latency_ms")}</td>
        <td><button class="btn secondary small" onclick="openSettNotify('${esc(d.id)}','${esc(d.name)}')">Edit</button></td>
      </tr>`;
    }).join("")||`<tr><td colspan="6" style="color:var(--text-muted);text-align:center;padding:16px">No devices</td></tr>`;
  }catch(e){}
}

/* ═══════════════════════════════════════════════════════════
   DEVICES TAB  (FIXED: credential fields per method)
═══════════════════════════════════════════════════════════ */
const QD_METHOD_FIELDS={
  ping:[],
  snmp:[
    {id:"qd-snmp-community",label:"Community string",placeholder:"public"},
    {id:"qd-snmp-version",label:"SNMP version",placeholder:"2",type:"number"},
  ],
  powershell:[
    {id:"qd-ps-remote",label:"Remote monitoring",type:"select",opts:["false:Local (run PS on this machine)","true:Remote (WinRM)"]},
    {id:"qd-ps-user",label:"Username (DOMAIN\\\\user)",placeholder:"DOMAIN\\\\user"},
    {id:"qd-ps-pass",label:"Password",type:"password",placeholder:""},
  ],
  ssh:[
    {id:"qd-ssh-port",label:"Port",placeholder:"22",type:"number"},
    {id:"qd-ssh-user",label:"Username",placeholder:"monitor"},
    {id:"qd-ssh-pass",label:"Password",type:"password",placeholder:""},
    {id:"qd-ssh-key",label:"Key path (optional)",placeholder:"/home/user/.ssh/id_rsa"},
  ],
  disk_usage:[
    {id:"qd-disk-os",label:"OS (windows/linux)",placeholder:"windows"},
    {id:"qd-disk-path",label:"Path (UNC or mount)",placeholder:"\\\\\\\\server\\\\share",wide:true},
    {id:"qd-disk-user",label:"Username",placeholder:""},
    {id:"qd-disk-pass",label:"Password",type:"password",placeholder:""},
  ],
};

// Metrics available per method — for the "what to monitor" checkboxes
const QD_METHOD_METRICS={
  ping:       [{id:"latency_ms",label:"Latency (ms)",chk:true},{id:"packet_loss_pct",label:"Packet Loss (%)",chk:true}],
  snmp:       [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"bandwidth_pct",label:"Bandwidth %",chk:true}],
  powershell: [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"memory_pct",label:"Memory %",chk:true},{id:"disk_pct",label:"Disk %",chk:true},{id:"bandwidth_pct",label:"Bandwidth %",chk:false}],
  ssh:        [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"memory_pct",label:"Memory %",chk:true},{id:"disk_pct",label:"Disk %",chk:true}],
  disk_usage: [{id:"disk_pct",label:"Disk %",chk:true},{id:"latency_ms",label:"Latency",chk:true}],
};

function renderQdMethodFields(){
  const m=v("qd-method")?.value||"ping";
  const fields=QD_METHOD_FIELDS[m]||[];
  const c=v("qd-cred-fields");
  if(c){
    c.innerHTML=fields.length?`
      <div style="margin-top:10px;padding:10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:rgba(255,255,255,.02);">
        <p style="font-size:11.5px;color:var(--text-muted);margin-bottom:8px;">🔒 Credentials for ${m}</p>
        <div class="form-grid">
          ${fields.map(f=>{
            if(f.type==="select"){
              return `<div class="field" style="${f.wide?"grid-column:1/-1":""}"><label>${f.label}</label>
                <select id="${f.id}">${f.opts.map(o=>{const[val,lbl]=o.split(":");return`<option value="${val}">${lbl}</option>`}).join("")}</select></div>`;
            }
            return `<div class="field" style="${f.wide?"grid-column:1/-1":""}"><label>${f.label}</label>
              <input id="${f.id}" type="${f.type||"text"}" placeholder="${f.placeholder||""}"></div>`;
          }).join("")}
        </div>
      </div>`:""
  }
  // Render what-to-monitor checkboxes
  const metrics=QD_METHOD_METRICS[m]||[];
  const mc=v("qd-monitor-metrics");
  if(mc){
    mc.innerHTML=metrics.length?`
      <div style="margin-top:10px;padding:10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:rgba(255,255,255,.02);">
        <p style="font-size:11.5px;color:var(--text-muted);margin-bottom:8px;">📊 Select metrics to monitor:</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          ${metrics.map(mt=>`
            <label style="display:flex;align-items:center;gap:5px;font-size:12.5px;cursor:pointer;
              padding:4px 10px;border-radius:4px;border:1px solid var(--border);background:var(--bg-hover);">
              <input type="checkbox" id="qd-m-${mt.id}" ${mt.chk?"checked":""}> ${mt.label}</label>`).join("")}
        </div>
      </div>`:"";
  }
}

function _qdVal(id){const e=v(id);return e?e.value.trim():"";}

async function settingsAddDevice(){
  const m=v("qd-method")?.value||"ping";
  const device={
    id:_qdVal("qd-id"),name:_qdVal("qd-name"),host:_qdVal("qd-host"),
    type:v("qd-type")?.value||"network",method:m,
  };
  const iv=_qdVal("qd-interval"); if(iv) device.poll_interval_seconds=parseInt(iv);
  if(!device.id||!device.name||!device.host){setStatus("qd-status","ID, name and host required",false);return;}

  // Collect credentials
  if(m==="powershell"){
    device.powershell={remote:_qdVal("qd-ps-remote")==="true",use_winrm:true,username:_qdVal("qd-ps-user")||null,password:_qdVal("qd-ps-pass")||null};
    if(!device.powershell.username) delete device.powershell.username;
    if(!device.powershell.password) delete device.powershell.password;
  } else if(m==="snmp"){
    device.snmp={community:_qdVal("qd-snmp-community")||"public",version:parseInt(_qdVal("qd-snmp-version")||"2")};
  } else if(m==="ssh"){
    device.ssh={port:parseInt(_qdVal("qd-ssh-port")||"22"),username:_qdVal("qd-ssh-user")||"monitor",password:_qdVal("qd-ssh-pass")||null,key_path:_qdVal("qd-ssh-key")||null};
    if(!device.ssh.password) delete device.ssh.password;
    if(!device.ssh.key_path) delete device.ssh.key_path;
  } else if(m==="disk_usage"){
    const path=_qdVal("qd-disk-path");
    if(!path){setStatus("qd-status","Path required for disk method",false);return;}
    device.disk={os:_qdVal("qd-disk-os")||"windows",path,remote:true,username:_qdVal("qd-disk-user")||null,password:_qdVal("qd-disk-pass")||null};
    if(!device.disk.username) delete device.disk.username;
    if(!device.disk.password) delete device.disk.password;
  }

  // Collect monitored metrics
  const metricsEnabled={};
  (QD_METHOD_METRICS[m]||[]).forEach(mt=>{
    const cb=v(`qd-m-${mt.id}`);
    metricsEnabled[mt.id]={enabled:cb?cb.checked:true};
  });
  // Save as initial thresholds config
  device._initial_thresholds=metricsEnabled;

  const r=await fetch("/api/devices",{method:"POST",headers:authHeaders(),body:JSON.stringify(device)});
  if(r.ok){
    // Save initial threshold selection as device notify config
    const thresholds={};
    Object.entries(metricsEnabled).forEach(([k,v2])=>{
      thresholds[k]={enabled:v2.enabled,...(BUILT_IN_DEFS[k]||{})};
    });
    await fetch(`/api/devices/${encodeURIComponent(device.id)}/notify`,{
      method:"POST",headers:authHeaders(),
      body:JSON.stringify({notifications_enabled:1,notify_emails:[],escalation_levels:0,
        escalation_emails_l1:[],escalation_emails_l2:[],escalation_emails_l3:[],
        escalation_after_sec_l1:300,escalation_after_sec_l2:600,escalation_after_sec_l3:1200,thresholds})
    });
    setStatus("qd-status",`${device.name} added ✓`,true);
    ["qd-id","qd-name","qd-host","qd-interval"].forEach(id=>{if(v(id))v(id).value="";});
    loadDevicesTab();
  } else {
    const d=await r.json();
    setStatus("qd-status",d.error||"Failed",false);
  }
}

async function loadDevicesTab(){
  try{
    const[devR,statR]=await Promise.all([
      fetch("/api/devices",{headers:{"X-Session-Token":getSession()}}),
      fetch("/api/status",{headers:{"X-Session-Token":getSession()}})
    ]);
    const devices=await devR.json();
    const stat=statR.ok?(await statR.json()).devices:[];
    const statMap=Object.fromEntries(stat.map(d=>[d.device_id,d]));
    const tbodyNet   = v("sett-devices-tbody");
    const tbodySites = v("sett-sites-tbody");
    if(!tbodyNet && !tbodySites) return;

    const rowHtml = (d) => {
      const s=statMap[d.id]||{};const sc=s.status||"unknown";
      const cols={ok:"var(--status-ok)",warning:"var(--status-warning)",critical:"var(--status-critical)",offline:"var(--text-muted)",unknown:"var(--text-muted)"};
      return `<tr>
        <td><strong>${esc(d.name)}</strong><br><span style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono)">${esc(d.id)}</span></td>
        <td style="font-size:12px">${esc(d.type||"")}</td>
        <td style="font-size:12px">${esc(d.method||"")}</td>
        <td><span style="color:${cols[sc]};font-weight:600">● ${sc}</span></td>
        <td>
          <button class="btn secondary small" onclick="settTestDevice('${esc(d.id)}','${esc(d.name)}')">▶ Test</button>
          <span id="st-res-${esc(d.id)}" style="font-size:11px;margin-left:4px;"></span>
        </td>
        <td><button class="btn secondary small" onclick="openSettNotify('${esc(d.id)}','${esc(d.name)}')">⚙ Notify</button></td>
        <td><button class="btn danger small" onclick="settRemoveDevice('${esc(d.id)}','${esc(d.name)}')">Remove</button></td>
      </tr>`;
    };

    const netDevices   = devices.filter(d => (d.method||"") !== "url");
    const siteDevices  = devices.filter(d => (d.method||"") === "url");

    if (tbodyNet) {
      tbodyNet.innerHTML = netDevices.map(rowHtml).join("") ||
        `<tr><td colspan="7" style="color:var(--text-muted);text-align:center;padding:16px">No network devices yet</td></tr>`;
    }
    if (tbodySites) {
      tbodySites.innerHTML = siteDevices.map(rowHtml).join("") ||
        `<tr><td colspan="7" style="color:var(--text-muted);text-align:center;padding:16px">No sites yet — add one from the Sites Monitor page</td></tr>`;
    }
  }catch(e){console.error("loadDevicesTab",e);}
}
async function settTestDevice(id,name){
  const el=v(`st-res-${id}`);if(el){el.textContent="Testing…";el.style.color="var(--text-muted)";}
  const r=await fetch(`/api/devices/${encodeURIComponent(id)}/test`,{method:"POST",headers:authHeaders()});
  const d=await r.json();
  if(el){el.textContent=d.ok?"✔ PASS":"✖ FAIL";el.style.color=d.ok?"var(--status-ok)":"var(--status-critical)";el.title=d.detail||"";}
  showToast(d.ok?`${name}: PASS — ${d.detail}`:`${name}: FAIL — ${d.detail}`,d.ok?"success":"error");
}
async function settRemoveDevice(id,name){
  if(!confirm(`Remove "${name}"?`)) return;
  const r=await fetch(`/api/devices/${encodeURIComponent(id)}`,{method:"DELETE",headers:authHeaders()});
  if(r.ok){showToast(`${name} removed`,"success");loadDevicesTab();}
  else showToast("Failed","error");
}

/* ═══════════════════════════════════════════════════════════
   USERS
═══════════════════════════════════════════════════════════ */
async function loadUsersTab(){
  try{
    const r=await fetch("/api/admin/users",{headers:{"X-Session-Token":getSession()}});
    if(!r.ok) return;
    const users=await r.json();
    const tbody=v("su-users-tbody"); if(!tbody) return;
    tbody.innerHTML=users.length?users.map(u=>`<tr>
      <td style="font-weight:600">${esc(u.email)}</td>
      <td><span style="padding:2px 8px;border-radius:4px;font-size:11.5px;font-weight:700;
        background:${u.role==="admin"?"rgba(59,139,235,.15)":"rgba(242,184,75,.12)"};
        color:${u.role==="admin"?"var(--accent)":"var(--status-warning)"}">
        ${u.role==="admin"?"⚙ admin":"👁 viewer"}</span></td>
      <td>${u.active?"● Active":"○ Inactive"}</td>
      <td style="display:flex;gap:6px;flex-wrap:wrap;">
        <button class="btn secondary small" onclick="suResetToken('${esc(u.email)}')">🔑 Token</button>
        <button class="btn danger small" onclick="suDeleteUser('${esc(u.email)}')">Remove</button>
      </td>
    </tr>`).join(""):`<tr><td colspan="4" style="color:var(--text-muted);text-align:center;padding:16px">No users</td></tr>`;
  }catch(e){}
}
async function suGenToken(){
  try{const r=await fetch("/api/admin/generate-token",{headers:{"X-Session-Token":getSession()}});const d=await r.json();if(d.token){v("su-token").value=d.token;suCheckToken();}}catch(e){}
}
function suCheckToken(){
  const t=v("su-token")?.value||"";const bar=v("su-token-bar");const hint=v("su-token-hint");if(!bar||!hint)return;
  const ok={len:t.length>=8,up:/[A-Z]/.test(t),lo:/[a-z]/.test(t),di:/[0-9]/.test(t)};
  const score=Object.values(ok).filter(Boolean).length;
  bar.style.width=score<=2?"33%":score===3?"66%":"100%";
  bar.style.background=score<=2?"#FF5C5C":score===3?"#F2B84B":"#3DD68C";
  hint.innerHTML=`<span style="color:${ok.len?"#3DD68C":"#FF5C5C"}">8+ chars</span> <span style="color:${ok.up?"#3DD68C":"#FF5C5C"}">A-Z</span> <span style="color:${ok.lo?"#3DD68C":"#FF5C5C"}">a-z</span> <span style="color:${ok.di?"#3DD68C":"#FF5C5C"}">0-9</span>`;
}
async function suAddUser(){
  const email=v("su-email")?.value.trim().toLowerCase()||"";
  const role=v("su-role")?.value||"user";
  const token=v("su-token")?.value.trim()||"";
  if(!email||!token){setStatus("su-status","Email and token required",false);return;}
  if(token.length<8||!/[A-Z]/.test(token)||!/[a-z]/.test(token)||!/[0-9]/.test(token)){setStatus("su-status","Token: 8+ chars, upper+lower+number",false);return;}
  const r=await fetch("/api/admin/users",{method:"POST",headers:authHeaders(),body:JSON.stringify({email,role,token})});
  const d=await r.json();
  if(r.ok){setStatus("su-status",`${email} added${d.welcome_email_sent?" · welcome email sent ✓":""}`,true);if(v("su-email"))v("su-email").value="";if(v("su-token"))v("su-token").value="";loadUsersTab();}
  else setStatus("su-status",d.error||"Failed",false);
}
async function suResetToken(email){
  const t=prompt(`New token for "${email}" (8+ chars, upper+lower+number):`);
  if(t===null)return;
  if(t.length<8||!/[A-Z]/.test(t)||!/[a-z]/.test(t)||!/[0-9]/.test(t)){showToast("Token too weak","error");return;}
  const r=await fetch(`/api/admin/users/${encodeURIComponent(email)}/token`,{method:"PUT",headers:authHeaders(),body:JSON.stringify({token:t})});
  showToast(r.ok?"Token reset ✓":"Failed",r.ok?"success":"error");
}
async function suDeleteUser(email){
  if(!confirm(`Remove "${email}"?`)) return;
  const r=await fetch(`/api/admin/users/${encodeURIComponent(email)}`,{method:"DELETE",headers:authHeaders()});
  if(r.ok){showToast(`${email} removed`,"success");loadUsersTab();}else showToast("Failed","error");
}

/* ═══════════════════════════════════════════════════════════
   AUDIT TAB (split: user/device audit + alert log)
═══════════════════════════════════════════════════════════ */
async function loadAuditTab(){
  loadAuditLog();
}
async function loadAuditLog(){
  try{
    const r=await fetch("/api/audit?limit=300",{headers:{"X-Session-Token":getSession()}});
    const logs=r.ok?await r.json():[];
    // Split into user/device actions vs alert actions
    const userDevActions=["add_user","delete_user","reset_token","add_device","edit_device","delete_device","test_device","apply_esc_defaults_all","reset_token"];
    const userDevLogs=logs.filter(l=>userDevActions.some(a=>l.action?.includes(a.split("_").slice(0,2).join("_"))||l.action===a));
    const alertLogs=logs.filter(l=>!userDevLogs.includes(l));
    renderAuditTable("audit-user-tbody",userDevLogs);
    renderAuditTable("audit-device-tbody",alertLogs);
  }catch(e){console.error("loadAuditLog",e);}
}
function renderAuditTable(tbodyId,logs){
  const tbody=v(tbodyId);if(!tbody)return;
  tbody.innerHTML=logs.length?logs.map(l=>`<tr>
    <td style="font-size:11.5px;white-space:nowrap;color:var(--text-muted)">${new Date(l.ts*1000).toLocaleString()}</td>
    <td style="font-family:var(--font-mono);font-size:12px;color:var(--accent)">${esc(l.actor||"system")}</td>
    <td><span class="audit-badge">${esc(l.action||"")}</span></td>
    <td style="font-size:12px">${esc(l.target||"")}</td>
    <td style="font-size:11.5px;color:var(--text-muted)">${esc(l.detail||"")}</td>
  </tr>`).join(""):`<tr><td colspan="5" style="color:var(--text-muted);text-align:center;padding:16px">No entries</td></tr>`;
}

/* ═══════════════════════════════════════════════════════════
   ALERT LOG
═══════════════════════════════════════════════════════════ */
let _allAlerts=[],_alertFilter="all";
async function loadAlerts(){
  try{
    const r=await fetch("/api/alerts?limit=200",{headers:{"X-Session-Token":getSession()}});
    _allAlerts=r.ok?await r.json():[];
    renderAlerts();renderAlertSummary();
  }catch(e){}
}
function filterAlerts(f){
  _alertFilter=f;
  document.querySelectorAll("[id^='af-']").forEach(b=>b.classList.remove("active"));
  const m={all:"all",critical:"crit",warning:"warn",recovered:"rec",offline:"off"};
  v(`af-${m[f]||f}`)?.classList.add("active");
  renderAlerts();
}
function renderAlerts(){
  const rows=_alertFilter==="all"?_allAlerts:_allAlerts.filter(a=>a.state===_alertFilter);
  const tbody=v("alerts-tbody");if(!tbody)return;
  const COL={warning:"var(--status-warning)",critical:"var(--status-critical)",recovered:"var(--status-ok)",offline:"var(--text-muted)"};
  tbody.innerHTML=rows.length?rows.map(a=>`<tr>
    <td style="font-size:12px;white-space:nowrap">${new Date(a.ts*1000).toLocaleString()}</td>
    <td>${esc(a.device_name)}</td>
    <td style="font-family:var(--font-mono);font-size:12px">${esc((a.metric||"").replace(/_/g," "))}</td>
    <td><span style="color:${COL[a.state]||"var(--text-secondary)"};font-weight:700">${esc(a.state?.toUpperCase())}</span></td>
    <td style="font-family:var(--font-mono);font-size:12px">${typeof a.value==="number"?a.value.toFixed(1):a.value}</td>
    <td style="color:${a.emailed?"var(--status-ok)":"var(--text-muted)"}">${a.emailed?"✓ sent":"—"}</td>
    <td style="font-size:12px;color:var(--text-muted)">${esc(a.message||"")}</td>
  </tr>`).join(""):`<tr><td colspan="7" style="color:var(--text-muted);text-align:center;padding:20px">No alerts${_alertFilter!=="all"?" with filter "+_alertFilter:""}</td></tr>`;
}
function renderAlertSummary(){
  const now=Date.now()/1000;const day=_allAlerts.filter(a=>a.ts>now-86400);
  v("asum-crit")  && (v("asum-crit").textContent  = day.filter(a=>a.state==="critical").length);
  v("asum-warn")  && (v("asum-warn").textContent  = day.filter(a=>a.state==="warning").length);
  v("asum-rec")   && (v("asum-rec").textContent   = day.filter(a=>a.state==="recovered").length);
  v("asum-email") && (v("asum-email").textContent = day.filter(a=>a.emailed).length);
}

/* ═══════════════════════════════════════════════════════════
   PER-DEVICE NOTIFY MODAL (escalation toggle per device)
═══════════════════════════════════════════════════════════ */
let _snmDeviceId="";
const SNM_ESC={l1:false,l2:false,l3:false};

async function openSettNotify(deviceId,deviceName){
  _snmDeviceId=deviceId;
  if(v("snm-name")) v("snm-name").textContent=deviceName;
  v("sett-notify-modal")?.classList.remove("hidden");
  try{const gr=await fetch("/api/admin/email-groups",{headers:{"X-Session-Token":getSession()}});if(gr.ok){const g=await gr.json();_allKnownEmails=g.all_emails||[];}}catch(_){}
  const r=await fetch(`/api/devices/${encodeURIComponent(deviceId)}/notify`,{headers:{"X-Session-Token":getSession()}});
  const cfg=r.ok?await r.json():{};
  if(v("snm-enabled")) v("snm-enabled").checked=cfg.notifications_enabled!==0;
  if(v("snm-notify-emails")) v("snm-notify-emails").value=fmtEmails(cfg.notify_emails||[]);
  SNM_ESC.l1=(cfg.escalation_levels||0)>=1;
  SNM_ESC.l2=(cfg.escalation_levels||0)>=2;
  SNM_ESC.l3=(cfg.escalation_levels||0)>=3;
  window._snmCfg=cfg;
  renderSnmNotifyEmailPicker(cfg.notify_emails||[]);
  renderSnmEscLevels(cfg);
  renderSnmThresholds(cfg.thresholds||{},deviceId);
}
function renderSnmNotifyEmailPicker(current){
  const c=v("snm-notify-email-picker");if(!c)return;
  if(!_allKnownEmails.length){c.innerHTML="";return;}
  c.innerHTML=`<p style="font-size:11.5px;color:var(--text-muted);margin-bottom:4px;">Quick-select:</p>
    <div style="display:flex;flex-wrap:wrap;gap:4px;">
      ${_allKnownEmails.map(e=>`
        <label style="display:flex;align-items:center;gap:3px;font-size:12px;cursor:pointer;
          padding:2px 8px;border-radius:4px;border:1px solid var(--border);background:var(--bg-hover);
          ${(current||[]).includes(e)?"border-color:var(--accent)":""}">
          <input type="checkbox" data-email="${esc(e)}" data-target="snm-notify-emails"
            ${(current||[]).includes(e)?"checked":""} onchange="_syncEmailCb(this)"> ${esc(e)}</label>`).join("")}
    </div>`;
}
function renderSnmEscLevels(cfg){
  cfg=cfg||{};
  const c=v("snm-esc-container");if(!c)return;
  const defs=[
    {n:1,key:"l1",col:"#F2B84B",sec:cfg.escalation_after_sec_l1||300,emails:cfg.escalation_emails_l1||[]},
    {n:2,key:"l2",col:"#FF8C00",sec:cfg.escalation_after_sec_l2||600,emails:cfg.escalation_emails_l2||[]},
    {n:3,key:"l3",col:"#FF5C5C",sec:cfg.escalation_after_sec_l3||1200,emails:cfg.escalation_emails_l3||[]},
  ];
  c.innerHTML=defs.map(lv=>{
    const on=SNM_ESC[lv.key];
    return `<div style="border:1px solid ${on?lv.col+"44":"var(--border)"};border-radius:var(--radius-sm);
      padding:10px 12px;margin-bottom:8px;border-left:3px solid ${on?lv.col:"var(--border)"};opacity:${on?1:.6}">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <label style="cursor:pointer;display:flex;align-items:center;gap:7px;">
          <span class="toggle-sw ${on?"on":""}" id="snm-tog-l${lv.n}" onclick="toggleSnmEsc(${lv.n})"></span>
          <span style="font-size:12.5px;font-weight:700;color:${on?lv.col:"var(--text-muted)"}">⚡ Level ${lv.n}</span>
        </label>
        <div style="${on?"":"opacity:.4;pointer-events:none"};display:flex;align-items:center;gap:5px;">
          <span style="font-size:12px;color:var(--text-muted)">after</span>
          <input id="snm-sec-l${lv.n}" type="number" style="width:65px" value="${lv.sec}" min="30">
          <span style="font-size:12px;color:var(--text-muted)">sec</span>
        </div>
      </div>
      <div style="${on?"":"opacity:.4;pointer-events:none"};margin-top:8px;">
        <label style="font-size:11.5px;color:var(--text-secondary)">Level ${lv.n} emails (Cc)</label>
        <textarea id="snm-esc-l${lv.n}" rows="2" class="code-textarea" style="margin-top:3px"
          placeholder="email@corp.com">${fmtEmails(lv.emails)}</textarea>
        ${_renderEmailPickerInline("snm-esc-l"+lv.n,lv.emails)}
      </div>
    </div>`;
  }).join("");
}
function toggleSnmEsc(n){SNM_ESC["l"+n]=!SNM_ESC["l"+n];renderSnmEscLevels(window._snmCfg||{});}

async function renderSnmThresholds(saved,deviceId){
  // Get device method to show relevant metrics
  let method="ping";
  try{
    const r=await fetch("/api/devices",{headers:{"X-Session-Token":getSession()}});
    if(r.ok){const devs=await r.json();const d=devs.find(x=>x.id===deviceId);if(d)method=d.method||"ping";}
  }catch(_){}
  const availMetrics=METHOD_METRICS[method]||METRICS;
  const c=v("snm-thresholds");if(!c)return;
  c.innerHTML=`<table class="data-table" style="margin:0;">
    <thead><tr><th>Metric</th><th>Enabled</th><th>Warning</th><th>Critical</th>
      <th style="color:var(--text-muted);font-size:11px">Default W</th>
      <th style="color:var(--text-muted);font-size:11px">Default C</th></tr></thead>
    <tbody>${availMetrics.map(m=>{
      const s=saved[m]||{};const d=BUILT_IN_DEFS[m]||{};
      return `<tr>
        <td style="font-family:var(--font-mono);font-size:12px">${METRIC_LABELS[m]||m}</td>
        <td style="text-align:center"><input type="checkbox" id="snmt-en-${m}" ${s.enabled!==false?"checked":""}></td>
        <td><input type="number" id="snmt-w-${m}" style="width:72px" value="${s.warning!=null?s.warning:""}" placeholder="${d.w||""}"></td>
        <td><input type="number" id="snmt-c-${m}" style="width:72px" value="${s.critical!=null?s.critical:""}" placeholder="${d.c||""}"></td>
        <td style="color:var(--text-muted);font-size:12px">${d.w||"—"}</td>
        <td style="color:var(--text-muted);font-size:12px">${d.c||"—"}</td>
      </tr>`;
    }).join("")}
    </tbody></table>`;
}
async function saveSettNotifyModal(){
  const levels=SNM_ESC.l3?3:SNM_ESC.l2?2:SNM_ESC.l1?1:0;
  const getE=n=>{const t=v(`snm-esc-l${n}`);return t&&SNM_ESC["l"+n]?parseEmails(t.value):[];};
  const getS=n=>{const t=v(`snm-sec-l${n}`);return t?parseInt(t.value)||300:300;};
  const thresholds={};
  METRICS.forEach(m=>{
    const w=v(`snmt-w-${m}`);const c=v(`snmt-c-${m}`);const en=v(`snmt-en-${m}`);
    if(!w) return;
    thresholds[m]={enabled:en?en.checked:true};
    if(w.value!=="") thresholds[m].warning=parseFloat(w.value);
    if(c&&c.value!=="") thresholds[m].critical=parseFloat(c.value);
  });
  const payload={
    notifications_enabled:v("snm-enabled")?.checked?1:0,
    notify_emails:parseEmails(v("snm-notify-emails")?.value||""),
    escalation_levels:levels,
    escalation_emails_l1:getE(1),escalation_emails_l2:getE(2),escalation_emails_l3:getE(3),
    escalation_after_sec_l1:getS(1),escalation_after_sec_l2:getS(2),escalation_after_sec_l3:getS(3),
    thresholds,
  };
  const r=await fetch(`/api/devices/${encodeURIComponent(_snmDeviceId)}/notify`,{method:"POST",headers:authHeaders(),body:JSON.stringify(payload)});
  setStatus("snm-status",r.ok?"Saved ✓":"Save failed",r.ok);
  if(r.ok){setTimeout(closeSettNotifyModal,1200);loadEscDeviceTable();loadThreshDeviceTable();loadNotifDeviceTable();loadDevicesTab();}
}
function closeSettNotifyModal(){v("sett-notify-modal")?.classList.add("hidden");}

/* ═══════════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════════ */
function initAll(){
  loadSmtp();
  setInterval(()=>{if(document.getElementById("tab-alerts")?.classList.contains("active"))loadAlerts();},15000);
  setInterval(()=>{if(document.getElementById("tab-audit")?.classList.contains("active"))loadAuditLog();},20000);
}
document.addEventListener("DOMContentLoaded",()=>{
  document.querySelectorAll(".stab").forEach(btn=>btn.addEventListener("click",()=>switchTab(btn.dataset.tab)));
  v("btn-save-smtp")       ?.addEventListener("click",saveSmtp);
  v("btn-test-warn")       ?.addEventListener("click",()=>testEmail("warning"));
  v("btn-test-crit")       ?.addEventListener("click",()=>testEmail("critical"));
  v("btn-save-notif")      ?.addEventListener("click",saveNotif);
  v("btn-save-esc-global") ?.addEventListener("click",saveEscGlobal);
  v("btn-apply-esc-all")   ?.addEventListener("click",applyEscToAll);
  v("btn-save-thresh")     ?.addEventListener("click",saveGlobalThresh);
  v("btn-reset-thresh")    ?.addEventListener("click",resetGlobalThresh);
  v("su-token")            ?.addEventListener("input",suCheckToken);
  v("btn-sett-add-device") ?.addEventListener("click",settingsAddDevice);
  v("qd-method")           ?.addEventListener("change",renderQdMethodFields);
  checkAccess();
});
