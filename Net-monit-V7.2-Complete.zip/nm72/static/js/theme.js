/* =============================================================================
 * Net-monit V7.2
 * Copyright (c) 2024-2026 Abdullah | Abdullah-InfoXtek.com
 * =============================================================================
 * theme.js — dark/light mode + custom accent colour, shared across every page.
 *
 * Storage model:
 *   - Applied instantly from localStorage (so there's no flash-of-wrong-theme)
 *   - Synced to the server per logged-in user via /api/prefs/theme and
 *     /api/prefs/accent-color so the preference follows the user across devices
 *   - Anonymous visitors: theme/colour only persist in this browser (localStorage)
 * ========================================================================== */

const THEME_KEY  = "netmon_theme";       // "dark" | "light" | "system"
const ACCENT_KEY = "netmon_accent";      // hex colour string, e.g. "#0078d4"

const ACCENT_PRESETS = [
  { name: "Blue",   value: "#0078d4" },
  { name: "Indigo", value: "#6366f1" },
  { name: "Teal",   value: "#0d9488" },
  { name: "Green",  value: "#16a34a" },
  { name: "Amber",  value: "#d97706" },
  { name: "Rose",   value: "#e11d48" },
  { name: "Violet", value: "#7c3aed" },
];

// ── Apply theme immediately (called at top of <head>, before paint) ────────
function applyTheme(mode) {
  const resolved = mode === "system"
    ? (window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")
    : (mode || "dark");
  document.documentElement.setAttribute("data-theme", resolved);
  return resolved;
}

function applyAccent(hex) {
  if (!hex) return;
  document.documentElement.style.setProperty("--accent", hex);
  // Derive a slightly darker hover shade
  try {
    const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
    const darker = "#" + [r,g,b].map(c => Math.max(0, Math.round(c*0.8)).toString(16).padStart(2,'0')).join('');
    document.documentElement.style.setProperty("--accent-dim", hex + "33");
    document.documentElement.style.setProperty("--acc-hov", darker);
  } catch (_) {}
}

// ── Apply immediately on script load (before DOMContentLoaded) to avoid flash ──
(function initThemeEarly() {
  const savedTheme  = localStorage.getItem(THEME_KEY)  || "dark";
  const savedAccent = localStorage.getItem(ACCENT_KEY) || "";
  applyTheme(savedTheme);
  if (savedAccent) applyAccent(savedAccent);
})();

// ── Persist + sync helpers ──────────────────────────────────────────────────
async function setTheme(mode) {
  localStorage.setItem(THEME_KEY, mode);
  applyTheme(mode);
  updateThemeSwitcherUI(mode);
  const sess = (typeof getSession === "function") ? getSession() : "";
  if (sess) {
    try {
      await fetch("/api/prefs/theme", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Session-Token": sess },
        body: JSON.stringify({ theme: mode }),
      });
    } catch (_) { /* offline — local preference still applied */ }
  }
}

async function setAccent(hex) {
  localStorage.setItem(ACCENT_KEY, hex);
  applyAccent(hex);
  updateAccentSwatchUI(hex);
  const sess = (typeof getSession === "function") ? getSession() : "";
  if (sess) {
    try {
      await fetch("/api/prefs/accent-color", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Session-Token": sess },
        body: JSON.stringify({ color: hex }),
      });
    } catch (_) { /* offline — local preference still applied */ }
  }
}

// ── Pull the server-stored preference once logged in (overrides local guess) ──
async function syncThemeFromServer() {
  const sess = (typeof getSession === "function") ? getSession() : "";
  if (!sess) return;
  try {
    const [tRes, aRes] = await Promise.all([
      fetch("/api/prefs/theme",        { headers: { "X-Session-Token": sess } }),
      fetch("/api/prefs/accent-color", { headers: { "X-Session-Token": sess } }),
    ]);
    const tData = await tRes.json();
    const aData = await aRes.json();
    if (tData.theme) {
      localStorage.setItem(THEME_KEY, tData.theme);
      applyTheme(tData.theme);
      updateThemeSwitcherUI(tData.theme);
    }
    if (aData.color) {
      localStorage.setItem(ACCENT_KEY, aData.color);
      applyAccent(aData.color);
      updateAccentSwatchUI(aData.color);
    }
  } catch (_) { /* keep local preference */ }
}

// ── UI wiring: theme switcher pill (dark/light/system) ──────────────────────
function updateThemeSwitcherUI(mode) {
  document.querySelectorAll(".theme-opt").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.theme === mode);
  });
}

function updateAccentSwatchUI(hex) {
  document.querySelectorAll(".accent-swatch").forEach(sw => {
    sw.classList.toggle("active", (sw.dataset.color || "").toLowerCase() === (hex||"").toLowerCase());
  });
}

function buildThemeSwitcher(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `
    <button class="theme-opt" data-theme="light" title="Light">&#9728;</button>
    <button class="theme-opt" data-theme="dark"  title="Dark">&#9790;</button>
    <button class="theme-opt" data-theme="system" title="Match system">&#128421;</button>
  `;
  el.querySelectorAll(".theme-opt").forEach(btn => {
    btn.addEventListener("click", () => setTheme(btn.dataset.theme));
  });
  updateThemeSwitcherUI(localStorage.getItem(THEME_KEY) || "dark");
}

function buildAccentPicker(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const current = localStorage.getItem(ACCENT_KEY) || "#0078d4";
  el.innerHTML = ACCENT_PRESETS.map(p =>
    `<div class="accent-swatch ${p.value.toLowerCase()===current.toLowerCase()?'active':''}"
          style="background:${p.value};" data-color="${p.value}" title="${p.name}"></div>`
  ).join('') +
  `<input type="color" class="accent-swatch-custom" id="accent-custom-input"
          value="${current}" title="Custom colour">`;

  el.querySelectorAll(".accent-swatch").forEach(sw => {
    sw.addEventListener("click", () => setAccent(sw.dataset.color));
  });
  const customInput = document.getElementById("accent-custom-input");
  if (customInput) {
    customInput.addEventListener("input", (e) => setAccent(e.target.value));
  }
}

// ── Wire up on every page ───────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  buildThemeSwitcher("theme-switcher-topbar");
  buildThemeSwitcher("theme-switcher-settings");
  buildAccentPicker("accent-picker-settings");
  // Once auth.js has validated the session, pull any server-saved preference
  setTimeout(syncThemeFromServer, 300);
});
