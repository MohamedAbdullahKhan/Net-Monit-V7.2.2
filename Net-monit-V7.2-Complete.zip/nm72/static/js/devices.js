/* =============================================================================
 * Net-monit V3.5
 * Copyright (c) 2024-2026 Abdullah. All rights reserved.
 * Contact: abuabdullah.be@outlook.com
 * ============================================================================= */
/* devices.js — V3.5
   FIXES:
   #5  PowerShell credentials fields shown correctly
   #6  Escalation: existing receivers pre-checked; + / − buttons to add/remove from predefined list
   #7  Per-metric enabled checkbox persists correctly; notify emails shown who already receive alerts
   #9  Test device button — calls /api/devices/<id>/test, shows pass/fail with detail
*/

const METHOD_FIELDS = {
  ping: [],
  snmp: [
    {id:"snmp-community", label:"Community string", placeholder:"public"},
    {id:"snmp-version",   label:"SNMP version",     placeholder:"2", type:"number"},
  ],
  powershell: [
    {id:"ps-remote",   label:"Remote monitoring",         type:"select",   opts:["false:Local (this machine runs PS)","true:Remote (WinRM)"]},
    {id:"ps-username", label:"Username (DOMAIN\\\\user)", placeholder:"DOMAIN\\\\username"},
    {id:"ps-password", label:"Password",                   placeholder:"", type:"password"},
  ],
  ssh: [
    {id:"ssh-port",     label:"Port",                   placeholder:"22", type:"number"},
    {id:"ssh-username", label:"Username",               placeholder:"monitor"},
    {id:"ssh-password", label:"Password",               placeholder:"", type:"password"},
    {id:"ssh-keypath",  label:"Key path (optional)",    placeholder:"/home/user/.ssh/id_rsa"},
  ],
  disk_usage: [
    {id:"disk-os",       label:"OS (windows/linux)",   placeholder:"windows"},
    {id:"disk-path",     label:"Path (UNC or mount)",  placeholder:"\\\\server\\share", wide:true},
    {id:"disk-username", label:"Username",             placeholder:""},
    {id:"disk-password", label:"Password",             placeholder:"", type:"password"},
  ],
};

const METRICS = ["latency_ms","packet_loss_pct","cpu_pct","memory_pct","disk_pct","bandwidth_pct"];
const METRIC_LABELS = {
  latency_ms:"Latency (ms)", packet_loss_pct:"Packet Loss (%)",
  cpu_pct:"CPU (%)", memory_pct:"Memory (%)", disk_pct:"Disk (%)", bandwidth_pct:"Bandwidth (%)"
};
const DEFAULTS = {
  latency_ms:{warning:100,critical:300}, packet_loss_pct:{warning:5,critical:20},
  cpu_pct:{warning:75,critical:90}, memory_pct:{warning:80,critical:95},
  disk_pct:{warning:80,critical:95}, bandwidth_pct:{warning:70,critical:90},
};

function esc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function val(id){ const e=document.getElementById(id); return e?e.value.trim():""; }
function emailListToArr(text){ return text.split(/[,\n]+/).map(s=>s.trim()).filter(Boolean); }
function arrToEmailList(arr){ return (arr||[]).join("\n"); }

// ── Method-specific extra fields ───────────────────────────────────────────
const DEV_METHOD_METRICS = {
  ping:       [{id:"latency_ms",label:"Latency (ms)",chk:true},{id:"packet_loss_pct",label:"Packet Loss (%)",chk:true}],
  snmp:       [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"bandwidth_pct",label:"Bandwidth %",chk:true}],
  powershell: [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"memory_pct",label:"Memory %",chk:true},{id:"disk_pct",label:"Disk %",chk:true},{id:"bandwidth_pct",label:"Bandwidth %",chk:false}],
  ssh:        [{id:"latency_ms",label:"Latency",chk:true},{id:"packet_loss_pct",label:"Packet Loss",chk:true},{id:"cpu_pct",label:"CPU %",chk:true},{id:"memory_pct",label:"Memory %",chk:true},{id:"disk_pct",label:"Disk %",chk:true}],
  disk_usage: [{id:"disk_pct",label:"Disk %",chk:true},{id:"latency_ms",label:"Latency",chk:true}],
};

function renderMethodFields(){
  const m = document.getElementById("f-method").value;
  const fields = METHOD_FIELDS[m] || [];
  const c = document.getElementById("method-fields");
  // Render metric checkboxes
  const mc = document.getElementById("method-metrics");
  const metrics = DEV_METHOD_METRICS[m]||[];
  if(mc && metrics.length){
    mc.innerHTML=`<div style="padding:10px;border:1px solid var(--border);border-radius:var(--radius-sm);background:rgba(255,255,255,.02);">
      <p style="font-size:11.5px;color:var(--text-muted);margin-bottom:7px;">📊 Metrics to monitor:</p>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">
        ${metrics.map(mt=>`<label style="display:flex;align-items:center;gap:4px;font-size:12px;cursor:pointer;
          padding:3px 9px;border-radius:4px;border:1px solid var(--border);background:var(--bg-hover);">
          <input type="checkbox" id="fm-${mt.id}" ${mt.chk?"checked":""}> ${mt.label}</label>`).join("")}
      </div></div>`;
  } else if(mc){ mc.innerHTML=""; }
  if(!fields.length){ c.innerHTML=""; return; }
  c.innerHTML=`<div class="form-grid">${fields.map(f=>{
    if(f.type==="select"){
      return `<div class="field" style="${f.wide?"grid-column:1/-1;":""}">
        <label>${f.label}</label>
        <select id="${f.id}">${f.opts.map(o=>{const[v,l]=o.split(":");return`<option value="${v}">${l}</option>`;}).join("")}</select></div>`;
    }
    return `<div class="field" style="${f.wide?"grid-column:1/-1;":""}">
      <label>${f.label}</label>
      <input id="${f.id}" type="${f.type||"text"}" placeholder="${f.placeholder||""}"></div>`;
  }).join("")}</div>`;
}

// ── Build device payload ───────────────────────────────────────────────────
function buildDevice(){
  const m = val("f-method");
  const d = {id:val("f-id"), name:val("f-name"), host:val("f-host"), type:val("f-type"), method:m};
  const iv = val("f-interval"); if(iv) d.poll_interval_seconds = parseInt(iv);
  if(m==="snmp")
    d.snmp = {community:val("snmp-community")||"public", version:parseInt(val("snmp-version")||"2")};
  else if(m==="powershell"){
    const remote = (() => { const el = document.getElementById("ps-remote"); return el ? el.value === "true" : false; })();
    d.powershell = {remote, use_winrm:true, username:val("ps-username")||null, password:val("ps-password")||null};
    if(!d.powershell.username) delete d.powershell.username;
    if(!d.powershell.password) delete d.powershell.password;
  } else if(m==="ssh")
    d.ssh = {port:parseInt(val("ssh-port")||"22"), username:val("ssh-username")||"monitor", password:val("ssh-password")||null, key_path:val("ssh-keypath")||null};
  else if(m==="disk_usage")
    d.disk = {os:val("disk-os")||"windows", path:val("disk-path"), remote:true, username:val("disk-username")||null, password:val("disk-password")||null};
  return d;
}

// ── Add / update device ────────────────────────────────────────────────────
async function addDevice(){
  const device  = buildDevice();
  if(!device.id||!device.name||!device.host){ showToast("ID, name, host required","error"); return; }
  const isEdit  = !!_editDeviceId;
  const url     = isEdit ? `/api/devices/${encodeURIComponent(_editDeviceId)}` : "/api/devices";
  const method  = isEdit ? "PUT" : "POST";
  if(isEdit){
    if(device.powershell&&!device.powershell.password) delete device.powershell.password;
    if(device.ssh&&!device.ssh.password)               delete device.ssh.password;
    if(device.disk&&!device.disk.password)             delete device.disk.password;
  }
  const r = await fetch(url,{method, headers:authHeaders(), body:JSON.stringify(device)});
  if(r.ok){
    // "Show on Dashboard" checkbox -- new devices default to visible on the
    // server already, so we only need to act when the box was UNCHECKED.
    const showBox = document.getElementById("f-show-dashboard");
    if (showBox) {
      try {
        await fetch(`/api/tiles/${encodeURIComponent(device.id)}/${showBox.checked ? "show" : "hide"}`,
          { method: "POST", headers: authHeaders() });
      } catch(_) {}
    }
    showToast(isEdit?`${device.name} updated`:`${device.name} added`,"success");
    cancelEdit();
    loadDevices();
  } else {
    const d = await r.json();
    showToast(d.error||"Failed","error");
  }
}

function cancelEdit(){
  _editDeviceId = null;
  document.getElementById("f-id").disabled = false;
  document.getElementById("add-device-card").querySelector(".card-title").textContent = "Add device / server / shared drive";
  document.getElementById("btn-add-device").textContent = "Add device";
  document.getElementById("btn-cancel-edit").style.display = "none";
  ["f-id","f-name","f-host","f-interval"].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=""; });
  document.getElementById("method-fields").innerHTML="";
}

async function deleteDevice(id, name){
  if(!confirm(`Permanently remove "${name}"?\n\nThis stops monitoring and clears all history.\nTo just hide from dashboard, use the tile menu (… button) → Hide tile.`)) return;
  const r = await fetch(`/api/devices/${encodeURIComponent(id)}`,{method:"DELETE",headers:authHeaders()});
  if(r.ok){ showToast(`${name} removed`,"success"); loadDevices(); }
  else showToast("Failed","error");
}

// ── FIX #9: Test device ────────────────────────────────────────────────────
async function testDevice(id, name){
  const btn = document.getElementById(`test-btn-${id}`);
  const res = document.getElementById(`test-result-${id}`);
  if(btn){ btn.disabled=true; btn.textContent="Testing…"; }
  if(res){ res.textContent=""; res.className=""; }
  try{
    const r = await fetch(`/api/devices/${encodeURIComponent(id)}/test`,{method:"POST",headers:authHeaders()});
    const d = await r.json();
    if(res){
      res.textContent = d.ok ? `✔ PASS — ${d.detail}` : `✖ FAIL — ${d.detail}`;
      res.style.color = d.ok ? "var(--status-ok)" : "var(--status-critical)";
      res.style.fontSize = "12px";
    }
    showToast(d.ok ? `${name}: Test PASS` : `${name}: Test FAIL — ${d.detail}`, d.ok?"success":"error");
  } catch(e){
    if(res){ res.textContent="Error: "+e.message; res.style.color="var(--status-critical)"; }
  } finally {
    if(btn){ btn.disabled=false; btn.textContent="Test"; }
  }
}

// ── Credential hint ────────────────────────────────────────────────────────
function credHint(d){
  const fields = {powershell:d.powershell?.password, ssh:d.ssh?.password, disk_usage:d.disk?.password};
  const pw = fields[d.method];
  if(!pw) return "";
  const enc = pw && pw.startsWith("ENC:");
  return `<span style="font-size:10.5px;color:${enc?"var(--status-ok)":"var(--status-warning)"};margin-top:2px;display:block;">
    ${enc?"🔒 Credentials encrypted":"⚠ Credentials stored as plain text — re-save to encrypt"}
  </span>`;
}

// ── Device list ────────────────────────────────────────────────────────────
const TYPE_ICONS = {
  network:"🌐", firewall:"🛡", wireless:"📡", windows:"🖥", linux:"🐧",
  vmware:"⚙", nas:"💾", printer:"🖨", ups:"⚡", camera:"📷", other:"📦",
};

async function loadDevices(){
  const r = await fetch("/api/devices",{headers:{"X-Session-Token":getSession()}});
  const allDevices = await r.json();
  // URL/site devices are managed exclusively on the Sites Monitor page --
  // keep the Devices page focused on hardware/network devices only.
  const devices = allDevices.filter(d => (d.method || "") !== "url");
  document.getElementById("device-count").textContent = `${devices.length} device(s) configured`;
  const list = document.getElementById("device-list");
  const isAdm = !!getSession();
  if(!devices.length){ list.innerHTML=`<p class="card-sub">No devices yet. (Web/URL sites are managed on the Sites Monitor page.)</p>`; return; }
  list.innerHTML = devices.map(d=>`
    <div class="device-list-row">
      <div class="device-list-meta">
        <span class="device-type-badge" title="${esc(d.type)}">${TYPE_ICONS[d.type]||"📦"} ${esc(d.method)}</span>
        <div>
          <div style="font-weight:600;">${esc(d.name)}</div>
          <div class="device-host">${esc(d.host||"***")}${d.disk&&d.disk.path?" — "+esc(d.disk.path):""}</div>
          <div style="font-size:11px;color:var(--text-muted);">${esc(d.type||"")}${d.poll_interval_seconds?" · poll every "+d.poll_interval_seconds+"s":""}</div>
          ${credHint(d)}
          <div id="test-result-${esc(d.id)}" style="margin-top:3px;"></div>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        ${isAdm?`<button id="test-btn-${esc(d.id)}" class="btn secondary small" onclick="testDevice('${esc(d.id)}','${esc(d.name)}')">&#9654; Test</button>`:""}
        <button class="btn secondary small" onclick="openNotifyModal('${esc(d.id)}','${esc(d.name)}')" title="Notification & escalation settings">&#9993; Notify</button>
        ${isAdm?`<button class="btn secondary small" onclick='openEditModal(${JSON.stringify(JSON.stringify(d))})'>&#9998; Edit</button>`:""}
        ${isAdm?`<button class="btn danger small" onclick="deleteDevice('${esc(d.id)}','${esc(d.name)}')">Remove</button>`:""}
      </div>
    </div>`).join("");
}

// ── Edit modal ─────────────────────────────────────────────────────────────
let _editDeviceId = null;

function openEditModal(deviceJsonStr){
  try{
    const d = JSON.parse(deviceJsonStr);
    _editDeviceId = d.id;
    document.getElementById("f-id").value     = d.id;
    document.getElementById("f-id").disabled  = true;
    document.getElementById("f-name").value   = d.name||"";
    document.getElementById("f-host").value   = d.host==="***"?"":d.host||"";
    document.getElementById("f-type").value   = d.type||"network";
    document.getElementById("f-method").value = d.method||"ping";
    document.getElementById("f-interval").value = d.poll_interval_seconds||"";
    renderMethodFields();
    if(d.method==="powershell"&&d.powershell){
      const remEl = document.getElementById("ps-remote");
      if(remEl) remEl.value = String(d.powershell.remote||false);
      if(document.getElementById("ps-username")) document.getElementById("ps-username").value = d.powershell.username||"";
      const enc = d.powershell.password?.startsWith("ENC:");
      if(document.getElementById("ps-password")) document.getElementById("ps-password").placeholder = enc?"(leave blank to keep encrypted)":"";
    }
    if(d.method==="ssh"&&d.ssh){
      if(document.getElementById("ssh-port"))     document.getElementById("ssh-port").value     = d.ssh.port||22;
      if(document.getElementById("ssh-username")) document.getElementById("ssh-username").value = d.ssh.username||"monitor";
      if(document.getElementById("ssh-keypath"))  document.getElementById("ssh-keypath").value  = d.ssh.key_path||"";
      const enc = d.ssh.password?.startsWith("ENC:");
      if(document.getElementById("ssh-password")) document.getElementById("ssh-password").placeholder = enc?"(leave blank to keep encrypted)":"";
    }
    if(d.method==="disk_usage"&&d.disk){
      if(document.getElementById("disk-os"))       document.getElementById("disk-os").value       = d.disk.os||"windows";
      if(document.getElementById("disk-path"))     document.getElementById("disk-path").value     = d.disk.path||"";
      if(document.getElementById("disk-username")) document.getElementById("disk-username").value = d.disk.username||"";
    }
    const card = document.getElementById("add-device-card");
    card.querySelector(".card-title").textContent = "Edit Device";
    document.getElementById("btn-add-device").textContent = "Save changes";
    document.getElementById("btn-cancel-edit").style.display = "";
    card.style.display = "";
    card.scrollIntoView({behavior:"smooth"});
  } catch(e){ console.error("Edit modal error:", e); }
}

// ── Notify modal (V3.5) ────────────────────────────────────────────────────
let _notifyDeviceId = "";
let _knownEmails    = [];  // from email groups API

async function openNotifyModal(deviceId, deviceName){
  _notifyDeviceId = deviceId;
  document.getElementById("nm-device-name").textContent = deviceName;
  document.getElementById("notify-modal").classList.remove("hidden");

  // FIX #6 & #7: Load all known emails for checkbox pickers
  try{
    const gr = await fetch("/api/admin/email-groups",{headers:{"X-Session-Token":getSession()}});
    if(gr.ok){ const g = await gr.json(); _knownEmails = g.all_emails||[]; }
  } catch(_){}

  const r   = await fetch(`/api/devices/${encodeURIComponent(deviceId)}/notify`,
                          {headers:{"X-Session-Token":getSession()}});
  const cfg = r.ok ? await r.json() : {};

  // FIX #7: checkbox enabled state
  document.getElementById("nm-enabled").checked     = cfg.notifications_enabled!==0;
  document.getElementById("nm-notify-emails").value = arrToEmailList(cfg.notify_emails||[]);
  document.getElementById("nm-esc-levels").value    = String(cfg.escalation_levels||1);

  // FIX #7: show existing notify_emails as checked in picker
  renderNotifyEmailPicker(cfg.notify_emails||[]);
  renderThresholdRows(cfg.thresholds||{});
  renderEscLevels(cfg);
}

// FIX #7: notify email picker with checkboxes for known emails
function renderNotifyEmailPicker(current){
  const container = document.getElementById("nm-notify-email-picker");
  if(!container) return;
  if(!_knownEmails.length){ container.innerHTML=""; return; }
  container.innerHTML = `
    <p style="font-size:11.5px;color:var(--text-muted);margin-bottom:5px;">Quick-select from known emails:</p>
    <div style="display:flex;flex-wrap:wrap;gap:5px;">
      ${_knownEmails.map(e=>`
        <label style="display:flex;align-items:center;gap:4px;font-size:12px;cursor:pointer;
          background:var(--bg-hover);padding:3px 8px;border-radius:4px;border:1px solid var(--border);">
          <input type="checkbox" data-email="${esc(e)}" data-target="nm-notify-emails"
            ${(current||[]).includes(e)?"checked":""}
            onchange="_syncEmailCheckbox(this)">
          ${esc(e)}</label>`).join("")}
    </div>`;
}

// FIX #6: renderEscLevels now pre-checks existing receivers
function renderEscLevels(cfg){
  cfg = cfg || {};
  const levels    = parseInt(document.getElementById("nm-esc-levels").value||"1");
  const container = document.getElementById("nm-esc-levels-container");
  if(levels === 0){ container.innerHTML=`<p style="color:var(--text-muted);font-size:12.5px;">Escalation disabled for this device.</p>`; return; }

  const levelDefs = [
    {n:1, label:"Level 1", color:"var(--status-warning)",
     secDef: cfg.escalation_after_sec_l1||cfg.escalation_after_sec||300,
     emailsDef: cfg.escalation_emails_l1||cfg.escalation_emails||[]},
    {n:2, label:"Level 2", color:"#FF8C00",
     secDef: cfg.escalation_after_sec_l2||600,
     emailsDef: cfg.escalation_emails_l2||[]},
    {n:3, label:"Level 3 (highest)", color:"var(--status-critical)",
     secDef: cfg.escalation_after_sec_l3||1200,
     emailsDef: cfg.escalation_emails_l3||[]},
  ];

  container.innerHTML = levelDefs.slice(0, levels).map(lv=>`
    <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:10px;border-left:3px solid ${lv.color};">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
        <span style="font-size:12px;font-weight:700;color:${lv.color};background:${lv.color}22;padding:2px 8px;border-radius:4px;">⚡ ${lv.label}</span>
        <div class="field" style="margin:0;flex-direction:row;align-items:center;gap:6px;flex:1;">
          <label style="font-size:12px;white-space:nowrap;">Escalate after</label>
          <input id="nm-esc-sec-l${lv.n}" type="number" style="width:80px;" value="${lv.secDef}" min="60">
          <span style="font-size:12px;color:var(--text-muted);">seconds</span>
        </div>
      </div>
      <div class="field">
        <label style="font-size:12px;">Level ${lv.n} escalation emails <span style="color:var(--text-muted)">(Cc when this level fires)</span></label>
        <textarea id="nm-esc-emails-l${lv.n}" rows="2" class="code-textarea"
          placeholder="manager@corp.com">${arrToEmailList(lv.emailsDef)}</textarea>
        ${_renderEscEmailPicker("nm-esc-emails-l"+lv.n, lv.emailsDef)}
      </div>
    </div>`).join("");
}

// FIX #6: email picker with pre-checked receivers + add/remove
function _renderEscEmailPicker(textareaId, current){
  if(!_knownEmails.length) return "";
  return `<div style="margin-top:5px;">
    <p style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">&#43; / &#8722; from known emails:</p>
    <div style="display:flex;flex-wrap:wrap;gap:5px;">
      ${_knownEmails.map(e=>`
        <label style="display:flex;align-items:center;gap:4px;font-size:12px;cursor:pointer;
          background:var(--bg-hover);padding:3px 8px;border-radius:4px;border:1px solid var(--border);
          ${(current||[]).includes(e)?"border-color:var(--accent);background:rgba(79,209,197,.08)":""}">
          <input type="checkbox" data-email="${esc(e)}" data-target="${textareaId}"
            ${(current||[]).includes(e)?"checked":""}
            onchange="_syncEmailCheckbox(this)">
          ${esc(e)}</label>`).join("")}
    </div>
  </div>`;
}

function _syncEmailCheckbox(cb){
  const ta = document.getElementById(cb.dataset.target);
  if(!ta) return;
  const emails = emailListToArr(ta.value);
  const email  = cb.dataset.email;
  if(cb.checked){ if(!emails.includes(email)) emails.push(email); }
  else { const i = emails.indexOf(email); if(i>=0) emails.splice(i,1); }
  ta.value = arrToEmailList(emails);
  // Update sibling checkboxes for same email in same textarea
  document.querySelectorAll(`input[type=checkbox][data-target="${cb.dataset.target}"][data-email="${email}"]`).forEach(other=>{
    if(other !== cb) other.checked = cb.checked;
  });
}

// FIX #7: renderThresholdRows - enabled checkbox persists
function renderThresholdRows(saved){
  const container = document.getElementById("nm-thresholds");
  container.innerHTML = `<table class="data-table" style="margin:0;">
    <thead><tr><th>Metric</th><th>Enabled</th><th>Warning</th><th>Critical</th>
      <th style="color:var(--text-muted);font-size:11px;">Default W</th>
      <th style="color:var(--text-muted);font-size:11px;">Default C</th></tr></thead>
    <tbody>${METRICS.map(m=>{
      const s = saved[m]||{};
      const d = DEFAULTS[m]||{};
      // FIX #7: enabled defaults to true only if not explicitly set to false
      const isEnabled = s.enabled !== false;
      return `<tr>
        <td style="font-family:var(--font-mono);font-size:12px;">${METRIC_LABELS[m]||m}</td>
        <td><input type="checkbox" id="thr-en-${m}" ${isEnabled?"checked":""}></td>
        <td><input type="number" id="thr-w-${m}" style="width:80px;" value="${s.warning!=null?s.warning:""}" placeholder="${d.warning||""}"></td>
        <td><input type="number" id="thr-c-${m}" style="width:80px;" value="${s.critical!=null?s.critical:""}" placeholder="${d.critical||""}"></td>
        <td style="color:var(--text-muted);font-size:12px;">${d.warning||"—"}</td>
        <td style="color:var(--text-muted);font-size:12px;">${d.critical||"—"}</td>
      </tr>`;}).join("")}
    </tbody></table>`;
}

function collectThresholds(){
  const out = {};
  METRICS.forEach(m=>{
    const w  = document.getElementById(`thr-w-${m}`);
    const c  = document.getElementById(`thr-c-${m}`);
    const en = document.getElementById(`thr-en-${m}`);
    if(!w) return;
    // FIX #7: always include enabled field explicitly
    out[m] = { enabled: en ? en.checked : true };
    if(w.value!=="")  out[m].warning  = parseFloat(w.value);
    if(c&&c.value!=="") out[m].critical = parseFloat(c.value);
  });
  return out;
}

function _getEscEmails(level){
  const ta = document.getElementById("nm-esc-emails-l"+level);
  return ta ? emailListToArr(ta.value) : [];
}
function _getEscSec(level){
  const el = document.getElementById("nm-esc-sec-l"+level);
  return el ? (parseInt(el.value)||300) : 300;
}

async function saveNotifyModal(){
  const levels = parseInt(document.getElementById("nm-esc-levels").value||"1");
  const payload = {
    notifications_enabled:   document.getElementById("nm-enabled").checked ? 1 : 0,
    notify_emails:           emailListToArr(document.getElementById("nm-notify-emails").value),
    escalation_levels:       levels,
    escalation_emails_l1:    levels>=1 ? _getEscEmails(1) : [],
    escalation_emails_l2:    levels>=2 ? _getEscEmails(2) : [],
    escalation_emails_l3:    levels>=3 ? _getEscEmails(3) : [],
    escalation_after_sec_l1: levels>=1 ? _getEscSec(1) : 300,
    escalation_after_sec_l2: levels>=2 ? _getEscSec(2) : 600,
    escalation_after_sec_l3: levels>=3 ? _getEscSec(3) : 1200,
    thresholds: collectThresholds(),
  };
  const r = await fetch(`/api/devices/${encodeURIComponent(_notifyDeviceId)}/notify`,
    {method:"POST", headers:authHeaders(), body:JSON.stringify(payload)});
  const st = document.getElementById("nm-status");
  if(r.ok){
    st.textContent="Saved ✓"; st.style.color="var(--status-ok)";
    setTimeout(()=>st.textContent="",2500);
  } else {
    st.textContent="Save failed"; st.style.color="var(--status-critical)";
  }
}

function closeNotifyModal(){ document.getElementById("notify-modal").classList.add("hidden"); }

// ── callbacks from auth.js ─────────────────────────────────────────────────
function onAdminLogin(){
  loadDevices();
  document.getElementById("add-device-form").style.opacity  = "";
  document.getElementById("add-device-form").style.pointerEvents = "";
  document.getElementById("admin-required-msg").style.display = "none";
}
function onAdminLogout(){ loadDevices(); }

document.addEventListener("DOMContentLoaded", ()=>{
  document.getElementById("f-method").addEventListener("change", renderMethodFields);
  document.getElementById("btn-add-device").addEventListener("click", addDevice);
  renderMethodFields();
  loadDevices();
  const role = getRole();
  if(role !== "admin"){
    document.getElementById("admin-required-msg").style.display = "";
    document.getElementById("add-device-form").style.opacity = "0.4";
    document.getElementById("add-device-form").style.pointerEvents = "none";
  }
});
