/* =============================================================================
 * Net-monit V7.2
 * Copyright (c) 2024-2026 Abdullah | Abdullah-InfoXtek.com
 * Contact: abuabdullah.be@outlook.com
 * =============================================================================
 * auth.js — shared authentication utilities (loaded on every page via base.html)
 *
 * Session model:
 *   - session token stored in sessionStorage (cleared when browser tab closes)
 *   - role ("admin" | "user") and email cached alongside the token
 *   - roles: "admin" (full access) | "user" (read-only dashboard)
 *
 * UI elements this file controls (must exist in base.html):
 *   #login-overlay, #login-close, #li-email, #li-token, #li-submit, #li-error
 *   #session-info, #session-email, #session-role-badge, #btn-signout, #btn-signin
 *   #sidebar-session
 *   #toast
 * ========================================================================== */

const SESS_KEY  = "netmon_session";
const ROLE_KEY  = "netmon_role";
const EMAIL_KEY = "netmon_email";

// ── Session storage helpers ─────────────────────────────────────────────────
function getSession() { return sessionStorage.getItem(SESS_KEY)  || ""; }
function getRole()    { return sessionStorage.getItem(ROLE_KEY)  || ""; }
function getEmail()   { return sessionStorage.getItem(EMAIL_KEY) || ""; }

function setSession(token, role, email) {
  sessionStorage.setItem(SESS_KEY,  token || "");
  sessionStorage.setItem(ROLE_KEY,  role  || "");
  sessionStorage.setItem(EMAIL_KEY, email || "");
}

function clearSession() {
  sessionStorage.removeItem(SESS_KEY);
  sessionStorage.removeItem(ROLE_KEY);
  sessionStorage.removeItem(EMAIL_KEY);
}

function authHeaders() {
  const s = getSession();
  return s
    ? { "Content-Type": "application/json", "X-Session-Token": s }
    : { "Content-Type": "application/json" };
}

// ── Toast notifications (used across all pages) ────────────────────────────
function showToast(msg, type = "info", durationMs = 4000) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.className   = `toast show ${type}`;
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(() => { t.className = "toast"; }, durationMs);
}

// ── Topbar UI sync — the SINGLE source of truth for the auth UI ────────────
function _updateTopbar(role, email) {
  const sessInfo  = document.getElementById("session-info");
  const sessEmail = document.getElementById("session-email");
  const sessBadge = document.getElementById("session-role-badge");
  const btnSignin = document.getElementById("btn-signin");
  const sidebarSess = document.getElementById("sidebar-session");
  const navLicense  = document.getElementById("nav-license");

  if (role && email) {
    if (sessInfo)  sessInfo.style.display = "";
    if (sessEmail) sessEmail.textContent  = email;
    if (sessBadge) {
      sessBadge.textContent = role === "admin" ? "ADMIN" : "VIEWER";
      sessBadge.className   = `role-badge ${role}`;
    }
    if (btnSignin) btnSignin.style.display = "none";
    if (navLicense && role === "admin") navLicense.style.display = "";
    if (sidebarSess) {
      sidebarSess.innerHTML =
        `<div style="font-size:12px;color:var(--text-muted);margin-bottom:3px;">Logged in as</div>
         <div style="font-size:12px;font-weight:600;word-break:break-all;">${email}</div>
         <span class="role-badge ${role}" style="display:inline-block;margin-top:4px;">
           ${role === "admin" ? "ADMIN" : "VIEWER"}
         </span>`;
    }
  } else {
    if (sessInfo)  sessInfo.style.display  = "none";
    if (btnSignin) btnSignin.style.display = "";
    if (navLicense) navLicense.style.display = "none";
    if (sidebarSess) sidebarSess.innerHTML = "";
  }
}

// ── Server-side session validation (called once per page load) ────────────
async function checkAdminStatus() {
  const sess = getSession();
  if (!sess) { _updateTopbar(null, null); return null; }
  try {
    const r = await fetch("/api/auth/check", { headers: { "X-Session-Token": sess } });
    const d = await r.json();
    if (d.logged_in) {
      setSession(sess, d.role, d.email);
      _updateTopbar(d.role, d.email);
      return d.role;
    }
  } catch (_) { /* network error — fall through to clear */ }
  // Session invalid or server unreachable with a stale token
  clearSession();
  _updateTopbar(null, null);
  return null;
}

// ── Login modal open / close ────────────────────────────────────────────────
function openLoginModal() {
  const overlay = document.getElementById("login-overlay");
  const errEl   = document.getElementById("li-error");
  if (errEl) errEl.textContent = "";
  overlay?.classList.remove("hidden");
  setTimeout(() => document.getElementById("li-email")?.focus(), 60);
}

function closeLoginModal() {
  document.getElementById("login-overlay")?.classList.add("hidden");
}

// Backwards-compatible aliases (some inline onclick= handlers may use these)
function openAdminModal()  { openLoginModal(); }
function closeAdminModal() { closeLoginModal(); }
window.openLogin = openLoginModal;

// ── Login submit ─────────────────────────────────────────────────────────
async function doLogin() {
  const emailEl = document.getElementById("li-email");
  const tokenEl = document.getElementById("li-token");
  const errEl   = document.getElementById("li-error");
  if (!emailEl || !tokenEl) return;

  const email = emailEl.value.trim().toLowerCase();
  const token = tokenEl.value.trim();
  if (errEl) errEl.textContent = "";

  if (!email || !token) {
    if (errEl) errEl.textContent = "Email and token are required.";
    return;
  }

  try {
    const r = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, token }),
    });
    const d = await r.json();

    if (d.ok) {
      setSession(d.session, d.role, d.email || email);
      tokenEl.value = "";
      closeLoginModal();
      _updateTopbar(d.role, d.email || email);
      const roleLabel = d.role === "admin" ? "Admin" : "Viewer";
      showToast(`${roleLabel} session active — access unlocked.`, "success");
      if (typeof window.onAdminLogin === "function") window.onAdminLogin(d.role);
    } else {
      if (errEl) errEl.textContent = d.error || "Invalid email or token.";
    }
  } catch (_) {
    if (errEl) errEl.textContent = "Network error — is the server running?";
  }
}

// ── Logout ───────────────────────────────────────────────────────────────
async function adminLogout() {
  const sess = getSession();
  if (sess) {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: { "X-Session-Token": sess },
      });
    } catch (_) { /* ignore — clearing local session regardless */ }
  }
  clearSession();
  closeLoginModal();
  // THE FIX: update the topbar UI immediately — this is the single function
  // that actually controls #session-info / #btn-signin visibility.
  _updateTopbar(null, null);
  showToast("Signed out.", "info");

  if (typeof window.onAdminLogout === "function") {
    window.onAdminLogout();
  }
}

// ── Wire up DOM once on every page ─────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const btnSignin  = document.getElementById("btn-signin");
  const btnSignout = document.getElementById("btn-signout");
  const liClose    = document.getElementById("login-close");
  const liSubmit   = document.getElementById("li-submit");
  const overlay    = document.getElementById("login-overlay");
  const liEmail    = document.getElementById("li-email");
  const liToken    = document.getElementById("li-token");

  if (btnSignin)  btnSignin.addEventListener("click", openLoginModal);
  if (btnSignout) btnSignout.addEventListener("click", adminLogout);
  if (liClose)    liClose.addEventListener("click", closeLoginModal);
  if (liSubmit)   liSubmit.addEventListener("click", doLogin);
  if (overlay) {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeLoginModal();
    });
  }
  if (liEmail) liEmail.addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("li-token")?.focus();
  });
  if (liToken) liToken.addEventListener("keydown", (e) => {
    if (e.key === "Enter") doLogin();
  });

  // Validate any existing session against the server and sync the UI
  checkAdminStatus();
});
