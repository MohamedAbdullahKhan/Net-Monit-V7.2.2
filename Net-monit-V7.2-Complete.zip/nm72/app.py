# =============================================================================
# Net-monit V7.2
# Copyright (c) 2024-2026 Abdullah | Abdullah-InfoXtek.com
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution is strictly prohibited.
# =============================================================================
"""
app.py -- Net-monit V7.2
Port   : 5072
Supports HTTP and HTTPS (set NETMON_SSL_CERT / NETMON_SSL_KEY env vars for HTTPS)
"""
import json, logging, os, platform, time, warnings

warnings.filterwarnings("ignore", message=".*TripleDES.*")
try:
    from cryptography.utils import CryptographyDeprecationWarning as _CW
    warnings.filterwarnings("ignore", category=_CW)
except ImportError:
    pass

from flask import Flask, jsonify, render_template, request, redirect

from monitor import database as db
from monitor import config_manager
from monitor import scheduler as sched
from monitor import email_notifier
from monitor import auth
from monitor.license import license_manager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
log = logging.getLogger("netmonit.app")

APP_VERSION = "7.2"
APP_PORT    = int(os.environ.get("NETMON_PORT", 5072))
SSL_CERT    = os.environ.get("NETMON_SSL_CERT", "")
SSL_KEY     = os.environ.get("NETMON_SSL_KEY",  "")

app = Flask(__name__)
app.secret_key = os.environ.get("NETMON_SECRET", os.urandom(32).hex())


# ── session helpers ────────────────────────────────────────────────────────
def _tok():
    return (request.headers.get("X-Session-Token") or
            request.cookies.get("netmon_session", ""))

def _session():
    return auth.validate_session(_tok())

def _is_admin():
    s = _session()
    return s is not None and s.get("role") == "admin"

def _is_logged_in():
    return _session() is not None

def _require_admin():
    if not _is_admin():
        return jsonify({"error": "Admin access required"}), 401
    return None

def _require_login():
    if not _is_logged_in():
        return jsonify({"error": "Login required"}), 401
    return None

def _email():
    s = _session()
    return s.get("email", "system") if s else "system"


# ── page routes ────────────────────────────────────────────────────────────
@app.route("/")
def dashboard_page():
    return render_template("index.html", active="dashboard", version=APP_VERSION)

@app.route("/devices")
def devices_page():
    return render_template("devices.html", active="devices", version=APP_VERSION)

@app.route("/settings")
def settings_page():
    return render_template("settings.html", active="settings", version=APP_VERSION)

@app.route("/activation")
def activation_page():
    """Standalone full-page license activation view (also embedded in Settings -> License)."""
    return render_template("activation.html", active="activation", version=APP_VERSION)

@app.route("/alerts")
def alerts_page():
    return render_template("alerts.html", active="alerts", version=APP_VERSION)

@app.route("/about")
def about_page():
    return render_template("about.html", active="about", version=APP_VERSION)

@app.route("/admin")
def admin_page():
    return render_template("admin.html", active="admin", version=APP_VERSION)


# =============================================================================
# V7.2: Alert Event Logs -- Acknowledge / Resolve lifecycle API
# =============================================================================
@app.route("/api/alerts/active")
def api_alerts_active():
    """List active/acknowledged/resolved alerts. ?status=active|acknowledged|resolved (omit for all)."""
    status = request.args.get("status")
    limit  = int(request.args.get("limit", 200))
    return jsonify(db.get_active_alerts(status_filter=status, limit=limit))

@app.route("/api/alerts/count")
def api_alerts_count():
    """Public lightweight count for the sidebar badge."""
    return jsonify({"open": db.count_open_alerts()})

@app.route("/api/alerts/<int:alert_id>/acknowledge", methods=["POST"])
def api_alert_acknowledge(alert_id):
    """Acknowledge -- suppresses further escalation for this metric until 23:59:59 today."""
    err = _require_login()
    if err: return err
    db.acknowledge_alert(alert_id, _email())
    db.audit_log(_email(), "alert_acknowledge", str(alert_id), "")
    return jsonify({"ok": True})

@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
def api_alert_resolve(alert_id):
    """
    Resolve -- immediately closes the alert (no re-verification required)
    and sends the device's normal recovery/status notification to its
    configured recipients (or admins by default), per device notify config.
    """
    err = _require_login()
    if err: return err
    open_rows = db.get_active_alerts(limit=500)
    row = next((a for a in open_rows if a["id"] == alert_id), None)
    db.resolve_alert(alert_id, _email())
    db.audit_log(_email(), "alert_resolve", str(alert_id), "")

    if row:
        try:
            cfg = config_manager.get_config()
            dn  = db.get_device_notify(row["device_id"]) or {}
            email_notifier.send_alert_email(
                cfg.get("smtp", {}), row.get("device_name",""), row.get("device_host",""),
                row.get("metric","status"), None, "resolved",
                threshold=None, device_notify=dn,
            )
        except Exception:
            pass  # Never fail the resolve action just because email sending had an issue
    return jsonify({"ok": True})


# ── auth API ───────────────────────────────────────────────────────────────
@app.route("/api/auth/login", methods=["POST"])
def api_login():
    body  = request.get_json(force=True) or {}
    email = body.get("email", "").strip().lower()
    token = body.get("token", "").strip()
    if not email or not token:
        return jsonify({"ok": False, "error": "Email and token required"}), 400
    sess, role = auth.attempt_login(email, token)
    if sess:
        return jsonify({"ok": True, "session": sess, "role": role})
    return jsonify({"ok": False, "error": "Invalid email or token"}), 401

@app.route("/api/auth/logout", methods=["POST"])
def api_logout():
    auth.logout(_tok())
    return jsonify({"ok": True})

@app.route("/api/auth/check")
def api_auth_check():
    s = _session()
    if s:
        return jsonify({"logged_in": True, "role": s["role"], "email": s["email"]})
    return jsonify({"logged_in": False, "role": None, "email": None})


# ── user preferences: theme ────────────────────────────────────────────────
@app.route("/api/prefs/theme", methods=["GET"])
def api_get_theme():
    err = _require_login()
    if err: return err
    theme = db.get_user_pref(_email(), "theme") or "dark"
    return jsonify({"theme": theme})

@app.route("/api/prefs/theme", methods=["POST"])
def api_set_theme():
    err = _require_login()
    if err: return err
    body  = request.get_json(force=True) or {}
    theme = body.get("theme", "dark")
    if theme not in ("dark", "light", "system"):
        return jsonify({"error": "Invalid theme"}), 400
    db.set_user_pref(_email(), "theme", theme)
    return jsonify({"ok": True})


# ── user preferences: accent colour (V7.2) ─────────────────────────────────
import re as _re_color
_HEX_COLOR_RE = _re_color.compile(r"^#[0-9A-Fa-f]{6}$")

@app.route("/api/prefs/accent-color", methods=["GET"])
def api_get_accent():
    err = _require_login()
    if err: return err
    color = db.get_user_pref(_email(), "accent_color") or db.get_system_setting("default_accent_color") or "#0078d4"
    return jsonify({"color": color})

@app.route("/api/prefs/accent-color", methods=["POST"])
def api_set_accent():
    err = _require_login()
    if err: return err
    body  = request.get_json(force=True) or {}
    color = body.get("color", "").strip()
    if not _HEX_COLOR_RE.match(color):
        return jsonify({"error": "Color must be a hex value like #0078d4"}), 400
    db.set_user_pref(_email(), "accent_color", color)
    return jsonify({"ok": True})


# ── admin: system-wide default appearance (V7.2) ───────────────────────────
@app.route("/api/admin/appearance", methods=["GET"])
def api_get_admin_appearance():
    err = _require_admin()
    if err: return err
    return jsonify({
        "default_theme":        db.get_system_setting("default_theme") or "dark",
        "default_accent_color": db.get_system_setting("default_accent_color") or "#0078d4",
    })

@app.route("/api/admin/appearance", methods=["POST"])
def api_set_admin_appearance():
    err = _require_admin()
    if err: return err
    body  = request.get_json(force=True) or {}
    theme = body.get("default_theme", "dark")
    color = body.get("default_accent_color", "#0078d4")
    if theme not in ("dark", "light", "system"):
        return jsonify({"error": "Invalid theme"}), 400
    if not _HEX_COLOR_RE.match(color):
        return jsonify({"error": "Color must be a hex value like #0078d4"}), 400
    db.set_system_setting("default_theme", theme)
    db.set_system_setting("default_accent_color", color)
    db.audit_log(_email(), "set_default_appearance", "", f"theme={theme} color={color}")
    return jsonify({"ok": True})


# ── dashboard layout (tile positions, sizes, visibility) ──────────────────
@app.route("/api/dashboard/layout", methods=["GET"])
def api_get_layout():
    err = _require_login()
    if err: return err
    layout = db.get_dashboard_layout(_email())
    return jsonify(layout)

@app.route("/api/dashboard/layout", methods=["POST"])
def api_save_layout():
    err = _require_login()
    if err: return err
    body = request.get_json(force=True) or {}
    db.save_dashboard_layout(_email(), body.get("layout", []))
    return jsonify({"ok": True})

@app.route("/api/dashboard/view-mode", methods=["POST"])
def api_set_view_mode():
    err = _require_login()
    if err: return err
    body = request.get_json(force=True) or {}
    mode = body.get("mode", "grid")
    if mode not in ("grid", "list"):
        return jsonify({"error": "Invalid mode"}), 400
    db.set_user_pref(_email(), "view_mode", mode)
    return jsonify({"ok": True})

@app.route("/api/dashboard/view-mode", methods=["GET"])
def api_get_view_mode():
    err = _require_login()
    if err: return err
    mode = db.get_user_pref(_email(), "view_mode") or "grid"
    return jsonify({"mode": mode})


# ── live status ────────────────────────────────────────────────────────────
@app.route("/api/status")
def api_status():
    rows    = db.get_all_device_status()
    session = _session()
    role    = session["role"] if session else None
    email   = session["email"] if session else None

    # Per-user layout
    layout_list = db.get_dashboard_layout(email) if email else []
    layout_map  = {item["device_id"]: item for item in layout_list}

    cfg = config_manager.get_config()
    polled_ids = {r["device_id"] for r in rows}
    for d in cfg.get("devices", []):
        if d["id"] not in polled_ids:
            rows.append({
                "device_id": d["id"], "name": d["name"],
                "type": d.get("type","network"), "method": d.get("method","ping"),
                "host": d.get("host",""), "status": "unknown",
                "last_checked": None, "last_error": None, "metrics_json": "{}",
            })

    for r in rows:
        r["metrics"] = json.loads(r.pop("metrics_json") or "{}")
        lay = layout_map.get(r["device_id"], {})
        r["tile_position"]  = lay.get("position", 0)
        r["tile_hidden"]    = lay.get("hidden", False)
        r["tile_size"]      = lay.get("size", "normal")
        r["tile_col"]       = lay.get("col", 0)
        r["tile_row"]       = lay.get("row", 0)
        if role != "admin":
            r["host"] = "*** (admin only)"
            r.pop("last_error", None)

    rows.sort(key=lambda x: x["tile_position"])
    visible = [r for r in rows if not r["tile_hidden"]]
    summary = {s: sum(1 for r in visible if r["status"] == s)
               for s in ("ok","warning","critical","offline")}
    summary["total"] = len(visible)

    view_mode = db.get_user_pref(email, "view_mode") if email else "grid"
    theme     = db.get_user_pref(email, "theme") if email else "dark"

    return jsonify({
        "devices":    rows,
        "summary":    summary,
        "server_time": time.time(),
        "role":       role,
        "version":    APP_VERSION,
        "port":       APP_PORT,
        "platform":   platform.system(),
        "license":    license_manager.get_status_dict(),
        "view_mode":  view_mode or "grid",
        "theme":      theme or "dark",
    })


@app.route("/api/history/<device_id>/<metric>")
def api_history(device_id, metric):
    since = int(request.args.get("since_seconds", 3600))
    return jsonify(db.get_metric_history(device_id, metric, since))

@app.route("/api/alerts")
def api_alerts():
    return jsonify(db.get_recent_alerts(int(request.args.get("limit", 100))))

@app.route("/api/system/info")
def api_system_info():
    return jsonify({
        "version":  APP_VERSION,
        "port":     APP_PORT,
        "platform": platform.system(),
        "python":   platform.python_version(),
        "hostname": platform.node(),
        "license":  license_manager.get_status_dict(),
    })


# ── devices ────────────────────────────────────────────────────────────────
@app.route("/api/devices", methods=["GET"])
def api_get_devices():
    cfg  = config_manager.get_config()
    devs = cfg.get("devices", [])
    if not _is_admin():
        devs = [{"id":d["id"],"name":d["name"],
                 "type":d.get("type",""),"method":d.get("method","")} for d in devs]
    return jsonify(devs)

@app.route("/api/devices", methods=["POST"])
def api_add_device():
    err = _require_admin()
    if err: return err
    device  = request.get_json(force=True)
    missing = {"id","name","type","method","host"} - set(device)
    if missing:
        return jsonify({"error": f"Missing fields: {missing}"}), 400
    cfg = config_manager.add_or_update_device(device)
    sched.reload_scheduler(cfg)
    db.audit_log(_email(), "add_device", device.get("id",""), "")
    return jsonify({"ok": True})

@app.route("/api/devices/<device_id>", methods=["PUT"])
def api_update_device(device_id):
    err = _require_admin()
    if err: return err
    device = request.get_json(force=True)
    device["id"] = device_id
    cfg = config_manager.add_or_update_device(device)
    sched.reload_scheduler(cfg)
    db.audit_log(_email(), "edit_device", device_id, "")
    return jsonify({"ok": True})

@app.route("/api/devices/<device_id>", methods=["DELETE"])
def api_delete_device(device_id):
    err = _require_admin()
    if err: return err
    cfg = config_manager.remove_device(device_id)
    sched.reload_scheduler(cfg)
    db.audit_log(_email(), "delete_device", device_id, "")
    return jsonify({"ok": True})


@app.route("/api/devices/<device_id>/test", methods=["POST"])
def api_test_device(device_id):
    err = _require_admin()
    if err: return err
    cfg    = config_manager.get_config()
    device = next((d for d in cfg.get("devices",[]) if d["id"]==device_id), None)
    if not device:
        return jsonify({"ok":False,"status":"error","detail":"Device not found"}), 404
    method = device.get("method","ping")
    host   = device.get("host","")
    try:
        if method == "ping":
            from monitor.checkers.ping_check import check
            r  = check(host, timeout_ms=device.get("ping_timeout_ms",1500))
            ok = r.get("reachable",False)
            detail = f"Latency: {r.get('latency_ms','?')} ms, Loss: {r.get('packet_loss_pct','?')}%" if ok else r.get("error","No response")
        elif method == "powershell":
            from monitor.checkers.powershell_check import check
            from monitor import crypto
            pc = device.get("powershell",{})
            r  = check(host, remote=pc.get("remote",False), use_winrm=pc.get("use_winrm",True),
                       username=pc.get("username"), password=crypto.decrypt(pc.get("password","") or ""), timeout=20)
            ok = r.get("reachable",False)
            detail = f"CPU: {r.get('cpu_pct','?')}%, Mem: {r.get('memory_pct','?')}%, Disk: {r.get('disk_pct','?')}%" if ok else r.get("error","PS check failed")
        elif method == "ssh":
            from monitor.checkers.ssh_check import check
            from monitor import crypto
            sc = device.get("ssh",{})
            r  = check(host, port=sc.get("port",22), username=sc.get("username","monitor"),
                       password=crypto.decrypt(sc.get("password","") or ""), key_path=sc.get("key_path"))
            ok = r.get("reachable",False)
            detail = f"CPU: {r.get('cpu_pct','?')}%, Mem: {r.get('memory_pct','?')}%" if ok else r.get("error","SSH failed")
        elif method == "snmp":
            from monitor.checkers.snmp_check import check
            sc = device.get("snmp",{})
            r  = check(device_id, host, community=sc.get("community","public"), version=sc.get("version",2))
            ok = r.get("reachable",False)
            detail = f"SNMP OK  uptime: {r.get('uptime_ticks','?')}" if ok else r.get("error","SNMP failed")
        elif method == "disk_usage":
            from monitor.checkers.disk_usage_check import check
            r  = check(device)
            ok = r.get("reachable",False)
            detail = f"Disk: {r.get('disk_pct','?')}%, Free: {r.get('free_gb','?')} GB" if ok else r.get("error","Disk failed")
        else:
            ok, detail = False, f"Unknown method: {method}"
        db.audit_log(_email(), "test_device", device_id, "PASS" if ok else "FAIL")
        return jsonify({"ok":ok, "status":"pass" if ok else "fail", "detail":detail})
    except Exception as e:
        log.exception("Device test error %s", device_id)
        return jsonify({"ok":False,"status":"error","detail":str(e)}), 500


# ── per-device notifications ───────────────────────────────────────────────
@app.route("/api/devices/<device_id>/notify", methods=["GET"])
def api_get_notify(device_id):
    err = _require_admin()
    if err: return err
    return jsonify(db.get_device_notify(device_id))

@app.route("/api/devices/<device_id>/notify", methods=["POST"])
def api_set_notify(device_id):
    err = _require_admin()
    if err: return err
    b = request.get_json(force=True) or {}
    db.set_device_notify(
        device_id,
        notifications_enabled   = b.get("notifications_enabled", 1),
        notify_emails           = b.get("notify_emails", []),
        escalation_emails_l1    = b.get("escalation_emails_l1", []),
        escalation_emails_l2    = b.get("escalation_emails_l2", []),
        escalation_emails_l3    = b.get("escalation_emails_l3", []),
        escalation_after_sec_l1 = int(b.get("escalation_after_sec_l1", 300)),
        escalation_after_sec_l2 = int(b.get("escalation_after_sec_l2", 600)),
        escalation_after_sec_l3 = int(b.get("escalation_after_sec_l3", 1200)),
        escalation_levels       = int(b.get("escalation_levels", 1)),
        thresholds              = b.get("thresholds", {}),
    )
    return jsonify({"ok": True})


# ── tile layout (legacy per-tile ops) ─────────────────────────────────────
@app.route("/api/tiles/<device_id>/hide",  methods=["POST"])
def api_hide_tile(device_id):
    err = _require_login()
    if err: return err
    db.set_tile_hidden(device_id, True)
    return jsonify({"ok": True})

@app.route("/api/tiles/<device_id>/show",  methods=["POST"])
def api_show_tile(device_id):
    err = _require_login()
    if err: return err
    db.set_tile_hidden(device_id, False)
    return jsonify({"ok": True})

@app.route("/api/tiles/order", methods=["POST"])
def api_tile_order():
    err = _require_login()
    if err: return err
    db.set_tile_order(request.get_json(force=True).get("device_ids",[]))
    return jsonify({"ok": True})

@app.route("/api/tiles/<device_id>/size", methods=["POST"])
def api_tile_size(device_id):
    err = _require_login()
    if err: return err
    db.set_tile_size(device_id, (request.get_json(force=True) or {}).get("size","normal"))
    return jsonify({"ok": True})


# ── SMTP settings ──────────────────────────────────────────────────────────
@app.route("/api/settings/smtp", methods=["GET"])
def api_get_smtp():
    err = _require_admin()
    if err: return err
    cfg  = config_manager.get_config()
    smtp = dict(cfg.get("smtp", {}))
    smtp["password"] = ""
    return jsonify(smtp)

@app.route("/api/settings/smtp", methods=["POST"])
def api_update_smtp():
    err = _require_admin()
    if err: return err
    config_manager.update_smtp(request.get_json(force=True))
    return jsonify({"ok": True})

@app.route("/api/settings/test-email", methods=["POST"])
def api_test_email():
    err = _require_admin()
    if err: return err
    cfg  = config_manager.get_config()
    body = request.get_json(silent=True) or {}
    ok, msg = email_notifier.send_alert_email(
        cfg["smtp"], "Test Device", "127.0.0.1",
        "test_metric", 99.9, body.get("state","warning"), threshold=75
    )
    return jsonify({"ok": ok, "message": msg})


# ── notification + threshold settings ─────────────────────────────────────
@app.route("/api/settings/notifications", methods=["GET"])
def api_get_notifications():
    err = _require_admin()
    if err: return err
    cfg = config_manager.get_config()
    return jsonify(cfg.get("notifications") or {
        "send_on_warning": True,"send_on_critical": True,
        "send_on_recovery": True,"send_on_offline": True,
        "resend_warn_minutes": 60,"resend_crit_minutes": 30,
        "include_detail": True,"include_host": True,
    })

@app.route("/api/settings/notifications", methods=["POST"])
def api_update_notifications():
    err = _require_admin()
    if err: return err
    config_manager.update_notifications(request.get_json(force=True))
    return jsonify({"ok": True})

@app.route("/api/settings/thresholds", methods=["GET"])
def api_get_thresholds():
    err = _require_admin()
    if err: return err
    return jsonify(config_manager.get_config().get("global_thresholds") or {})

@app.route("/api/settings/thresholds", methods=["POST"])
def api_update_thresholds():
    err = _require_admin()
    if err: return err
    config_manager.update_global_thresholds(request.get_json(force=True))
    return jsonify({"ok": True})

@app.route("/api/settings/escalation-defaults", methods=["GET"])
def api_get_esc():
    err = _require_admin()
    if err: return err
    return jsonify(config_manager.get_config().get("escalation_defaults") or {})

@app.route("/api/settings/escalation-defaults", methods=["POST"])
def api_update_esc():
    err = _require_admin()
    if err: return err
    config_manager.update_escalation_defaults(request.get_json(force=True))
    return jsonify({"ok": True})

@app.route("/api/settings/escalation-defaults/apply-all", methods=["POST"])
def api_apply_esc_all():
    err = _require_admin()
    if err: return err
    body = request.get_json(force=True) or {}
    cfg  = config_manager.get_config()
    for d in cfg.get("devices",[]):
        ex = db.get_device_notify(d["id"])
        db.set_device_notify(
            d["id"],
            notifications_enabled   = ex.get("notifications_enabled",1),
            notify_emails           = ex.get("notify_emails",[]),
            escalation_emails_l1    = body.get("escalation_emails_l1",[]),
            escalation_emails_l2    = body.get("escalation_emails_l2",[]),
            escalation_emails_l3    = body.get("escalation_emails_l3",[]),
            escalation_after_sec_l1 = int(body.get("escalation_after_sec_l1",300)),
            escalation_after_sec_l2 = int(body.get("escalation_after_sec_l2",600)),
            escalation_after_sec_l3 = int(body.get("escalation_after_sec_l3",1200)),
            escalation_levels       = ex.get("escalation_levels",1),
            thresholds              = ex.get("thresholds",{}),
        )
    db.audit_log(_email(),"apply_esc_all","all","")
    return jsonify({"ok":True,"count":len(cfg.get("devices",[]))})


# ── users ──────────────────────────────────────────────────────────────────
@app.route("/api/admin/users", methods=["GET"])
def api_get_users():
    err = _require_admin()
    if err: return err
    users = db.get_all_users()
    return jsonify([{"id":u["id"],"email":u["email"],"role":u["role"],"active":u["active"]} for u in users])

@app.route("/api/admin/users", methods=["POST"])
def api_add_user():
    err = _require_admin()
    if err: return err
    body  = request.get_json(force=True) or {}
    email = body.get("email","").strip().lower()
    role  = body.get("role","user")
    token = body.get("token","").strip()
    if not email or not token:
        return jsonify({"error": "email and token required"}), 400
    if len(token) < 8:
        return jsonify({"error": "Token must be 8+ characters"}), 400
    if role not in ("admin","user"):
        return jsonify({"error": "Role must be admin or user"}), 400
    auth.add_user(email, role, token)
    db.audit_log(_email(),"add_user",email,f"role={role}")
    cfg      = config_manager.get_config()
    app_host = request.host or f"localhost:{APP_PORT}"
    sent, msg = config_manager.send_welcome_email(cfg["smtp"],email,role,token,app_host)
    return jsonify({"ok":True,"welcome_email_sent":sent,"welcome_email_msg":msg})

@app.route("/api/admin/users/<path:email>/token", methods=["PUT"])
def api_reset_token(email):
    err = _require_admin()
    if err: return err
    body  = request.get_json(force=True) or {}
    token = body.get("token","").strip()
    if not token or len(token) < 8:
        return jsonify({"error": "Token must be 8+ characters"}), 400
    users = db.get_all_users()
    role  = next((u["role"] for u in users if u["email"]==email.lower()),"user")
    auth.add_user(email.lower(), role, token)
    db.audit_log(_email(),"reset_token",email,"")
    cfg = config_manager.get_config()
    sent, msg = config_manager.send_welcome_email(
        cfg["smtp"], email, role, token, request.host or f"localhost:{APP_PORT}"
    )
    return jsonify({"ok":True,"welcome_email_sent":sent,"welcome_email_msg":msg})

@app.route("/api/admin/users/<path:email>", methods=["DELETE"])
def api_delete_user(email):
    err = _require_admin()
    if err: return err
    db.delete_user(email.lower())
    db.audit_log(_email(),"delete_user",email,"")
    return jsonify({"ok": True})

@app.route("/api/admin/generate-token")
def api_gen_token():
    err = _require_admin()
    if err: return err
    return jsonify({"token": auth.generate_token()})

@app.route("/api/admin/email-groups")
def api_email_groups():
    err = _require_admin()
    if err: return err
    users  = db.get_all_users()
    emails = [u["email"] for u in users if u.get("active",1)]
    cfg    = config_manager.get_config()
    smtp   = cfg.get("smtp",{})
    all_e  = list(dict.fromkeys(emails + smtp.get("admin_emails",[]) +
                                smtp.get("support_emails",[]) + smtp.get("manager_emails",[])))
    return jsonify({"all_emails":all_e,"admin_emails":smtp.get("admin_emails",[]),
                    "support_emails":smtp.get("support_emails",[]),"manager_emails":smtp.get("manager_emails",[])})

@app.route("/api/audit")
def api_audit():
    err = _require_admin()
    if err: return err
    return jsonify(db.get_audit_log(int(request.args.get("limit",200))))


# ── license API ────────────────────────────────────────────────────────────
@app.route("/api/license/status")
def api_license_status():
    license_manager.refresh()
    return jsonify(license_manager.get_status_dict())

@app.route("/api/license/activate", methods=["POST"])
def api_license_activate():
    err = _require_admin()
    if err: return err
    body = request.get_json(force=True) or {}
    key  = body.get("license_key","").strip()
    if not key:
        return jsonify({"ok": False, "message": "License key is required"}), 400
    result = license_manager.activate(key)
    if result["ok"]:
        db.audit_log(_email(),"license_activate","","success")
    return jsonify(result), (200 if result["ok"] else 400)




# =============================================================================
# V7.2 NEW FEATURES: Speed Test | URL Monitor | Network Scan
# =============================================================================

# ── Page routes for new features ──────────────────────────────────────────
@app.route("/speedtest")
def speedtest_page():
    return render_template("speedtest.html", active="speedtest", version=APP_VERSION)

@app.route("/urlmonitor")
def sitesmonitor_page():
    return render_template("urlmonitor.html", active="urlmonitor", version=APP_VERSION)

@app.route("/networkscan")
def networkscan_page():
    return render_template("networkscan.html", active="networkscan", version=APP_VERSION)


# ── Speed Test API ────────────────────────────────────────────────────────
@app.route("/api/speedtest/run", methods=["POST"])
def api_speedtest_run():
    """Run an on-demand internet speed test (can take 20-30s)."""
    from monitor.checkers.speedtest_check import check as speedtest_check
    import threading
    err = _require_login()
    if err: return err

    result = {}
    done   = threading.Event()
    def _run():
        result.update(speedtest_check({}))
        done.set()
    threading.Thread(target=_run, daemon=True).start()
    done.wait(timeout=60)

    if not result:
        return jsonify({"reachable": False, "error": "Timeout waiting for speed test"}), 504

    # Store result in DB for history
    db.record_speedtest(result)
    if result.get("reachable"):
        db.audit_log(_email(), "speedtest", "internet",
                     f"DL={result.get('download_mbps')} UL={result.get('upload_mbps')}")
    return jsonify(result)


@app.route("/api/speedtest/history")
def api_speedtest_history():
    # Public history - login only needed to run new tests
    limit = int(request.args.get("limit", 50))
    return jsonify(db.get_speedtest_history(limit))


@app.route("/api/speedtest/history", methods=["DELETE"])
def api_speedtest_clear_history():
    """Purge all speed test history (Admin only)."""
    err = _require_admin()
    if err: return err
    db.clear_speedtest_history()
    db.audit_log(_email(), "speedtest_purge", "internet", "history cleared")
    return jsonify({"ok": True})


# ── URL Monitor API ───────────────────────────────────────────────────────
@app.route("/api/urlmonitor/check", methods=["POST"])
def api_urlmonitor_check():
    """On-demand URL check. Public endpoint - no login required for quick checks."""
    from monitor.checkers.url_check import check as url_check
    # Public endpoint - anyone can check a URL
    body   = request.get_json(force=True) or {}
    device = {"host": body.get("url",""), "url_config": body.get("config",{})}
    if not device["host"]:
        return jsonify({"error": "url is required"}), 400
    result = url_check(device)
    return jsonify(result)


@app.route("/api/urlmonitor/results")
def api_urlmonitor_results():
    """Get latest status + saved configuration for all URL-monitored devices."""
    err = _require_login()
    if err: return err
    rows = db.get_all_device_status()
    cfg  = config_manager.get_config()
    cfg_by_id = {d["id"]: d for d in cfg.get("devices", [])}

    url_rows = [
        dict(r) for r in rows
        if (r.get("method") or "") == "url"
    ]
    for r in url_rows:
        r["metrics"] = __import__("json").loads(r.pop("metrics_json") or "{}")
        saved = cfg_by_id.get(r["device_id"], {})
        r["url_config"] = saved.get("url_config", {})
        r["poll_interval_seconds"] = saved.get("poll_interval_seconds", 60)

    # Also include configured URL devices that haven't reported status yet
    polled_ids = {r["device_id"] for r in url_rows}
    for d in cfg.get("devices", []):
        if d.get("method") == "url" and d["id"] not in polled_ids:
            url_rows.append({
                "device_id": d["id"], "name": d["name"], "host": d.get("host",""),
                "status": "unknown", "last_checked": None, "metrics": {},
                "url_config": d.get("url_config", {}),
                "poll_interval_seconds": d.get("poll_interval_seconds", 60),
            })

    return jsonify(url_rows)


# ── Network Scan API ──────────────────────────────────────────────────────
@app.route("/api/networkscan/detect-subnets")
def api_networkscan_detect():
    """Detect local subnets from network interfaces."""
    from monitor.checkers.network_scan import get_local_subnets
    err = _require_login()
    if err: return err
    return jsonify({"subnets": get_local_subnets()})


@app.route("/api/networkscan/scan", methods=["POST"])
def api_networkscan_scan():
    """
    Scan a subnet. Body: {subnet, port_scan, max_workers}
    This can take 10-60s for a /24 subnet.
    Runs in background; poll /api/networkscan/status for progress.
    """
    from monitor.checkers.network_scan import scan_subnet
    err = _require_admin()
    if err: return err
    body       = request.get_json(force=True) or {}
    subnet     = body.get("subnet","").strip()
    port_scan  = bool(body.get("port_scan", True))
    max_workers= int(body.get("max_workers", 64))

    if not subnet:
        return jsonify({"error": "subnet is required (e.g. 192.168.1.0/24)"}), 400

    # Safely pull user context string BEFORE leaving the HTTP request lifecycle
    user_email = _email()

    scan_id = db.create_scan_job(subnet)
    import threading
    def _run():
        try:
            db.update_scan_job(scan_id, "running", None)
            result = scan_subnet(subnet, port_scan=port_scan,
                                 max_workers=max_workers)
            db.update_scan_job(scan_id, "done", result)
            db.audit_log(user_email, "network_scan", subnet,
                         f"found={result.get('hosts_alive',0)}")
        except Exception as e:
            db.update_scan_job(scan_id, "error", {"error": str(e)})
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"scan_id": scan_id, "status": "started",
                    "subnet": subnet})


@app.route("/api/networkscan/status/<int:scan_id>")
def api_networkscan_status(scan_id):
    """Poll scan job status."""
    err = _require_login()
    if err: return err
    job = db.get_scan_job(scan_id)
    if not job:
        return jsonify({"error": "Scan job not found"}), 404
    return jsonify(job)


@app.route("/api/networkscan/history")
def api_networkscan_history():
    """List recent scan jobs."""
    err = _require_login()
    if err: return err
    return jsonify(db.get_scan_history(int(request.args.get("limit",20))))


@app.route("/api/networkscan/add-devices", methods=["POST"])
def api_networkscan_add_devices():
    """Add discovered hosts as ping-monitored devices."""
    err = _require_admin()
    if err: return err
    body    = request.get_json(force=True) or {}
    hosts   = body.get("hosts", [])
    added   = 0
    cfg     = config_manager.get_config()
    existing_ids   = {d["id"] for d in cfg.get("devices",[])}
    existing_hosts = {d["host"] for d in cfg.get("devices",[])}
    for h in hosts:
        ip   = h.get("ip","").strip()
        name = h.get("name") or h.get("hostname") or ip
        if not ip or ip in existing_hosts:
            continue
        dev_id = f"scan_{ip.replace('.','_')}"
        if dev_id in existing_ids:
            continue
        device = {
            "id":     dev_id,
            "name":   name,
            "type":   "network",
            "method": h.get("method","ping"),
            "host":   ip,
            "poll_interval_seconds": 60,
        }
        config_manager.add_or_update_device(device)
        added += 1
    if added:
        sched.reload_scheduler(config_manager.get_config())
        db.audit_log(_email(), "scan_add_devices", f"{added} devices", "")
    return jsonify({"ok": True, "added": added})


# ── startup ────────────────────────────────────────────────────────────────
def initialize():
    db.init_db()
    auth.seed_default_admin_if_empty()
    license_manager.refresh()
    cfg = config_manager.load_config()
    sched.start_scheduler(cfg)
    state = license_manager.state
    log.info("Net-monit V%s  port=%s  platform=%s  license=%s  devices=%d",
             APP_VERSION, APP_PORT, platform.system(), state,
             len(cfg.get("devices",[])))
    log.info("Dashboard: http://0.0.0.0:%s", APP_PORT)
    if state == "trial":
        log.info("TRIAL: %d days remaining. Get free key: abuabdullah.be@outlook.com",
                 license_manager.trial_days_remaining)

if __name__ == "__main__":
    initialize()
    ssl_ctx = None
    if SSL_CERT and SSL_KEY and os.path.isfile(SSL_CERT) and os.path.isfile(SSL_KEY):
        import ssl
        ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_ctx.load_cert_chain(SSL_CERT, SSL_KEY)
        log.info("HTTPS enabled: cert=%s", SSL_CERT)
    app.run(host="0.0.0.0", port=APP_PORT, debug=False,
            use_reloader=False, ssl_context=ssl_ctx)