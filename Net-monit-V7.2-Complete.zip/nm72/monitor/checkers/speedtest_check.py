# =============================================================================
# Net-monit V7.2 -- Speed Test Checker
# Copyright (c) 2024-2026 Abdullah | Abdullah-InfoXtek.com
# =============================================================================
"""
speedtest_check.py
Measures internet upload/download speed and latency.
Uses speedtest-cli (pure Python) or falls back to urllib-based test.
"""
import logging, time, socket, urllib.request, threading

log = logging.getLogger("monitor.checkers.speedtest")

# Public test file URLs for fallback bandwidth test
_TEST_URLS = [
    ("https://speed.cloudflare.com/__down?bytes=10000000", 10_000_000),
    ("https://httpbin.org/bytes/5000000", 5_000_000),
]

def _cloudflare_download_mbps(target_duration=10.0, chunk_bytes=6_000_000, timeout=15,
                               progress_cb=None):
    """
    Download test via Cloudflare, sampled like a real speedometer: repeated
    chunk transfers over ~target_duration seconds, averaged by total
    bytes/total time rather than a single instantaneous reading.
    progress_cb(sample_mbps, elapsed_sec) is called after every chunk so a
    caller can show a live-updating gauge.
    """
    url = f"https://speed.cloudflare.com/__down?bytes={chunk_bytes}"
    total_bytes  = 0
    t_start      = time.perf_counter()
    samples      = []
    try:
        while (time.perf_counter() - t_start) < target_duration:
            req = urllib.request.Request(url, headers={"User-Agent": "netmonit/7.2"})
            t0  = time.perf_counter()
            received = 0
            with urllib.request.urlopen(req, timeout=timeout) as r:
                while True:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    received += len(chunk)
            dt = time.perf_counter() - t0
            if dt > 0 and received > 0:
                sample_mbps = (received * 8) / (dt * 1_000_000)
                samples.append(sample_mbps)
                total_bytes += received
                if progress_cb:
                    progress_cb(round(sample_mbps, 2), round(time.perf_counter() - t_start, 1))
    except Exception as e:
        log.debug("Cloudflare download test failed: %s", e)

    total_elapsed = time.perf_counter() - t_start
    if total_bytes > 0 and total_elapsed > 0:
        # True average: total data moved over total wall-clock time
        return round((total_bytes * 8) / (total_elapsed * 1_000_000), 2)
    return None


def _cloudflare_upload_mbps(target_duration=6.0, chunk_bytes=2_000_000, timeout=15,
                             progress_cb=None):
    """Upload test, sampled the same way as download -- multiple chunks averaged."""
    url = "https://speed.cloudflare.com/__up"
    total_bytes = 0
    t_start     = time.perf_counter()
    try:
        while (time.perf_counter() - t_start) < target_duration:
            data = b"0" * chunk_bytes
            req  = urllib.request.Request(
                url, data=data, method="POST",
                headers={"Content-Type": "application/octet-stream",
                         "Content-Length": str(chunk_bytes),
                         "User-Agent": "netmonit/7.2"})
            t0 = time.perf_counter()
            with urllib.request.urlopen(req, timeout=timeout) as r:
                r.read()
            dt = time.perf_counter() - t0
            if dt > 0:
                total_bytes += chunk_bytes
                if progress_cb:
                    sample_mbps = (chunk_bytes * 8) / (dt * 1_000_000)
                    progress_cb(round(sample_mbps, 2), round(time.perf_counter() - t_start, 1))
    except Exception as e:
        log.debug("Cloudflare upload test failed: %s", e)

    total_elapsed = time.perf_counter() - t_start
    if total_bytes > 0 and total_elapsed > 0:
        return round((total_bytes * 8) / (total_elapsed * 1_000_000), 2)
    return None


def _latency_ms(host="1.1.1.1", port=443, samples=5):
    """TCP connect latency in ms (average of samples). Also returns raw sample list for jitter calc."""
    times = []
    for _ in range(samples):
        try:
            t0 = time.perf_counter()
            s  = socket.create_connection((host, port), timeout=3)
            s.close()
            times.append((time.perf_counter() - t0) * 1000)
        except Exception:
            pass
    if not times:
        return None, []
    return round(sum(times) / len(times), 1), times


def _jitter_ms(samples: list) -> float:
    """
    Jitter = average absolute difference between consecutive latency samples.
    Standard RFC-3550-style approximation used by most consumer speed test tools.
    """
    if len(samples) < 2:
        return 0.0
    diffs = [abs(samples[i] - samples[i - 1]) for i in range(1, len(samples))]
    return round(sum(diffs) / len(diffs), 1)


def _public_ip_and_isp(timeout=5):
    """
    Look up the public-facing IP and ISP/organisation name.
    Uses ipapi.co (no API key required, generous free tier) with a plain-IP fallback.
    """
    try:
        req = urllib.request.Request(
            "https://ipapi.co/json/",
            headers={"User-Agent": "netmonit/7.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            import json as _json
            info = _json.loads(r.read().decode("utf-8", errors="replace"))
        ip  = info.get("ip", "")
        isp = info.get("org") or info.get("asn") or ""
        if ip:
            return ip, (isp or "Unknown ISP")
    except Exception as e:
        log.debug("ipapi.co lookup failed: %s", e)

    # Fallback: plain public IP only, no ISP name
    try:
        req = urllib.request.Request(
            "https://api.ipify.org",
            headers={"User-Agent": "netmonit/7.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ip = r.read().decode("utf-8", errors="replace").strip()
        return ip, "Unknown ISP"
    except Exception as e:
        log.debug("ipify fallback failed: %s", e)
        return "", "Unknown ISP"


def _try_speedtest_cli():
    """Try to use speedtest-cli library if installed."""
    try:
        import speedtest as st_lib
        st = st_lib.Speedtest(secure=True)
        st.get_best_server()
        dl  = round(st.download() / 1_000_000, 2)
        ul  = round(st.upload()   / 1_000_000, 2)
        lat = round(st.results.ping, 1)
        srv = st.results.server.get("sponsor","") + " " + st.results.server.get("name","")
        return dl, ul, lat, srv.strip()
    except ImportError:
        return None
    except Exception as e:
        log.debug("speedtest-cli failed: %s", e)
        return None


def check(device: dict) -> dict:
    """
    Run speed test. Returns:
      reachable      bool
      download_mbps  float
      upload_mbps    float
      latency_ms     float   (ping to nearest test point)
      jitter_ms      float   (variance between latency samples — connection stability)
      isp            str     (ISP / organisation name from public IP lookup)
      public_ip      str     (this server's WAN-facing IP address)
      server         str     (which test backend/server was used)
      method_used    str
      elapsed_sec    float
    """
    t0 = time.perf_counter()

    # Public IP + ISP lookup runs in parallel with the speed test itself
    ip_isp_result = [None, None]
    def _lookup_ip_isp():
        ip_isp_result[0], ip_isp_result[1] = _public_ip_and_isp()
    ip_thread = threading.Thread(target=_lookup_ip_isp, daemon=True)
    ip_thread.start()

    # Try speedtest-cli first (most accurate — real ISP-graded test servers)
    result = _try_speedtest_cli()
    if result:
        dl, ul, lat, srv = result
        _, jitter_samples = _latency_ms(samples=6)
        jitter = _jitter_ms(jitter_samples)
        ip_thread.join(timeout=6)
        return {
            "reachable":     True,
            "download_mbps": dl,
            "upload_mbps":   ul,
            "latency_ms":    lat,
            "jitter_ms":     jitter,
            "isp":           ip_isp_result[1] or "Unknown ISP",
            "public_ip":     ip_isp_result[0] or "",
            "server":        srv or "Speedtest.net",
            "method_used":   "speedtest-cli",
            "elapsed_sec":   round(time.perf_counter() - t0, 1),
        }

    # Fallback: Cloudflare parallel tests
    dl_result  = [None]
    ul_result  = [None]
    lat_result = [None]
    jitter_samples_result = [[]]

    def _dl(): dl_result[0]  = _cloudflare_download_mbps()
    def _ul(): ul_result[0]  = _cloudflare_upload_mbps()
    def _lat():
        lat_result[0], jitter_samples_result[0] = _latency_ms(samples=6)

    threads = [threading.Thread(target=f, daemon=True) for f in (_dl, _ul, _lat)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=25)
    ip_thread.join(timeout=6)

    dl     = dl_result[0]
    ul     = ul_result[0]
    lat    = lat_result[0]
    jitter = _jitter_ms(jitter_samples_result[0])

    if dl is None and ul is None:
        return {
            "reachable":   False,
            "error":       "Speed test failed — no internet access or test endpoint unreachable",
            "latency_ms":  lat,
            "jitter_ms":   jitter,
            "isp":         ip_isp_result[1] or "Unknown ISP",
            "public_ip":   ip_isp_result[0] or "",
            "elapsed_sec": round(time.perf_counter() - t0, 1),
        }

    return {
        "reachable":     True,
        "download_mbps": dl or 0.0,
        "upload_mbps":   ul or 0.0,
        "latency_ms":    lat or 0.0,
        "jitter_ms":     jitter,
        "isp":           ip_isp_result[1] or "Unknown ISP",
        "public_ip":     ip_isp_result[0] or "",
        "server":        "Cloudflare Speed Test",
        "method_used":   "cloudflare",
        "elapsed_sec":   round(time.perf_counter() - t0, 1),
    }
