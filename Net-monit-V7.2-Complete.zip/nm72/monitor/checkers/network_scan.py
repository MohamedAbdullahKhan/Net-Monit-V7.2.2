# =============================================================================
# Net-monit V7.2 -- Network Scanner (Context-Safe Edition)
# Copyright (c) 2024-2026 Abdullah | Abdullah-InfoXtek.com
# =============================================================================
"""
network_scan.py
Scans a subnet for live hosts using:
  - ICMP ping (subprocess)
  - ARP table lookup (fast, no root needed on local subnet)
  - TCP port scan on common ports to identify device type
  - Reverse DNS lookup for hostname resolution
  - MAC vendor lookup (OUI prefix)
"""
import logging, socket, subprocess, platform, ipaddress
import concurrent.futures, time, re, os

# Standard localized fallback logger to prevent web-context leakage
log = logging.getLogger("monitor.checkers.network_scan")

# Common ports to probe for device-type identification
PORT_PROBES = {
    22:   "SSH",
    23:   "Telnet",
    25:   "SMTP",
    53:   "DNS",
    80:   "HTTP",
    110:  "POP3",
    143:  "IMAP",
    161:  "SNMP",
    443:  "HTTPS",
    445:  "SMB",
    3306: "MySQL",
    3389: "RDP",
    5000: "Flask/Dev",
    5072: "Net-monit",
    8080: "HTTP-Alt",
    8443: "HTTPS-Alt",
    9100: "Printer",
}

# OUI database (first 3 bytes of MAC → vendor)
OUI_PREFIXES = {
    "00:50:56": "VMware",       "00:0c:29": "VMware",
    "00:1a:11": "Google",       "b8:27:eb": "Raspberry Pi",
    "dc:a6:32": "Raspberry Pi", "e4:5f:01": "Raspberry Pi",
    "00:16:3e": "Xen",          "02:42:":   "Docker",
    "00:1b:21": "Intel",        "00:1f:c6": "Intel",
    "3c:97:0e": "Apple",        "a4:c3:f0": "Apple",
    "f0:18:98": "Apple",        "00:1e:c9": "Dell",
    "14:18:77": "Dell",         "00:21:9b": "Dell",
    "00:0d:3a": "Microsoft",    "00:15:5d": "Microsoft (Hyper-V)",
    "00:17:fa": "Microsoft",    "00:e0:4c": "Realtek",
    "00:1d:60": "Cisco",        "00:1e:13": "Cisco",
    "00:1f:27": "Cisco",        "fc:72:96": "TP-Link",
    "50:d4:f7": "TP-Link",      "c4:6e:1f": "TP-Link",
    "74:da:38": "Edimax",       "00:90:a9": "Western Digital",
    "00:26:18": "Netgear",      "20:e5:2a": "Netgear",
    "a0:21:b7": "Netgear",      "00:14:6c": "Netgear",
    "c8:3a:35": "Tenda",        "00:1a:2b": "Ubiquiti",
    "04:18:d6": "Ubiquiti",     "f0:9f:c2": "Ubiquiti",
    "b4:fb:e4": "ASUSTek",      "10:bf:48": "ASUSTek",
    "f8:32:e4": "ASUSTek",
}

IS_WIN = platform.system() == "Windows"


def _ping_one(ip: str, timeout_ms: int = 1000) -> bool:
    """Return True if host responds to ping."""
    try:
        if IS_WIN:
            cmd = ["ping", "-n", "1", "-w", str(timeout_ms), str(ip)]
        else:
            cmd = ["ping", "-c", "1", "-W", str(max(1, timeout_ms // 1000)), str(ip)]
        
        # Use explicit context isolation via subprocess environment configurations
        r = subprocess.run(cmd, capture_output=True, timeout=5, env=os.environ.copy())
        return r.returncode == 0
    except Exception:
        return False


def _tcp_port_open(ip: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((str(ip), port), timeout=timeout):
            return True
    except Exception:
        return False


def _get_hostname(ip: str) -> str:
    try:
        return socket.gethostbyaddr(str(ip))[0]
    except Exception:
        return ""


def _get_mac_arp(ip: str) -> str:
    """Get MAC from ARP table (no root needed)."""
    try:
        # Avoid thread inheritance issues by forcing clean subprocess environments
        clean_env = os.environ.copy()
        if IS_WIN:
            out = subprocess.check_output(
                ["arp", "-a", str(ip)], timeout=3,
                stderr=subprocess.DEVNULL, env=clean_env
            ).decode(errors="ignore")
            m = re.search(r"([0-9a-fA-F]{2}[-:]){5}[0-9a-fA-F]{2}", out)
            if m:
                return m.group(0).replace("-", ":").lower()
        else:
            out = subprocess.check_output(
                ["arp", "-n", str(ip)], timeout=3,
                stderr=subprocess.DEVNULL, env=clean_env
            ).decode(errors="ignore")
            m = re.search(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}", out)
            if m:
                return m.group(0).lower()
    except Exception:
        pass
    return ""


def _vendor_from_mac(mac: str) -> str:
    if not mac:
        return ""
    prefix6 = mac[:8]  # xx:xx:xx
    prefix4 = mac[:5]  # xx:xx
    for prefix, vendor in OUI_PREFIXES.items():
        if prefix6.startswith(prefix) or prefix.startswith(prefix4):
            return vendor
    return ""


def _identify_device_type(open_ports: list[int]) -> str:
    ports = set(open_ports)
    if 3389 in ports:      return "Windows Server/Desktop"
    if 22 in ports and 80 in ports: return "Linux Server"
    if 22 in ports:        return "Linux/Unix Host"
    if 445 in ports:       return "Windows Host"
    if 80 in ports or 443 in ports:  return "Web Server"
    if 161 in ports:       return "Network Device (SNMP)"
    if 23 in ports:        return "Network Device (Telnet)"
    if 9100 in ports:      return "Network Printer"
    if 3306 in ports:      return "Database Server"
    if 5072 in ports:      return "Net-monit Server"
    if ports:              return "Network Device"
    return "Host"


def _scan_host(ip_str: str, port_scan: bool, common_ports: list) -> dict | None:
    """Scan a single host. Returns dict if alive, None if unreachable."""
    alive = _ping_one(ip_str)
    if not alive:
        # Quick TCP check on port 80/443 (some devices block ICMP)
        alive = _tcp_port_open(ip_str, 80, 0.5) or \
                _tcp_port_open(ip_str, 443, 0.5) or \
                _tcp_port_open(ip_str, 22, 0.5)
    if not alive:
        return None

    result = {
        "ip":          ip_str,
        "hostname":    "",
        "mac":         "",
        "vendor":      "",
        "open_ports":  [],
        "device_type": "Host",
        "reachable":   True,
        "latency_ms":  None,
    }

    # Internal localized thread pool to guarantee execution isolation
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        f_host = ex.submit(_get_hostname, ip_str)
        f_mac  = ex.submit(_get_mac_arp, ip_str)
        if port_scan:
            f_ports = {ex.submit(_tcp_port_open, ip_str, p, 0.4): p for p in common_ports}
        else:
            f_ports = {}

        try:
            result["hostname"] = f_host.result(timeout=4) or ""
        except Exception:
            result["hostname"] = ""

        try:
            mac = f_mac.result(timeout=4) or ""
            result["mac"]      = mac
            result["vendor"]   = _vendor_from_mac(mac)
        except Exception:
            result["mac"]      = ""
            result["vendor"]   = ""

        open_ports = []
        for f, port in f_ports.items():
            try:
                if f.result(timeout=1):
                    open_ports.append(port)
            except Exception:
                pass
        result["open_ports"]  = sorted(open_ports)
        result["device_type"] = _identify_device_type(open_ports)

    return result


def scan_subnet(
    subnet: str,
    port_scan: bool = True,
    max_workers: int = 64,
    ports: list | None = None,
) -> dict:
    """
    Scan entire subnet securely outside framework global request tracking pools.
    """
    if ports is None:
        ports = list(PORT_PROBES.keys())

    try:
        net = ipaddress.ip_network(subnet, strict=False)
    except ValueError as e:
        return {"error": str(e), "hosts_found": [], "total_scanned": 0}

    if net.num_addresses > 65536:
        return {"error": "Subnet too large. Maximum /16 (65536 hosts).",
                "hosts_found": [], "total_scanned": 0}

    all_hosts = [str(h) for h in net.hosts()]
    t0        = time.perf_counter()
    found     = []

    # Safe log parsing string execution references
    try:
        log.info(f"Scanning {subnet} ({len(all_hosts)} hosts, port_scan={port_scan}, workers={max_workers})")
    except Exception:
        pass # Safeguards against web servers hooking current logger objects to context strings

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_scan_host, ip, port_scan, ports): ip for ip in all_hosts}
        for f in concurrent.futures.as_completed(futures, timeout=120):
            try:
                result = f.result(timeout=10)
                if result:
                    found.append(result)
            except Exception:
                pass

    found.sort(key=lambda h: ipaddress.ip_address(h["ip"]))
    duration = round(time.perf_counter() - t0, 1)

    try:
        log.info(f"Scan complete: {len(found)}/{len(all_hosts)} hosts alive in {duration}s")
    except Exception:
        pass

    return {
        "subnet":        str(subnet),
        "hosts_found":   found,
        "total_scanned": len(all_hosts),
        "hosts_alive":   len(found),
        "duration_sec":  duration,
        "port_scan":     port_scan,
    }


def get_local_subnets() -> list[str]:
    """Auto-detect local network subnets safely."""
    subnets = []
    clean_env = os.environ.copy()
    try:
        hostname = socket.gethostname()
        addrs    = socket.getaddrinfo(hostname, None, socket.AF_INET)
        for addr in addrs:
            ip = addr[4][0]
            if not ip.startswith("127."):
                parts = ip.split(".")
                subnets.append(f"{parts[0]}.{parts[1]}.{parts[2]}.0/24")
    except Exception:
        pass

    try:
        if IS_WIN:
            out = subprocess.check_output(
                ["ipconfig"], stderr=subprocess.DEVNULL, timeout=5, env=clean_env
            ).decode(errors="ignore")
            ips = re.findall(r"IPv4.*?:\s*([\d.]+)", out)
        else:
            out = subprocess.check_output(
                ["ip", "-o", "-4", "addr", "show"], stderr=subprocess.DEVNULL, timeout=5, env=clean_env
            ).decode(errors="ignore")
            ips = re.findall(r"inet\s+([\d.]+)/(\d+)", out)
            subnets = []
            for ip, prefix in ips:
                if not ip.startswith("127."):
                    try:
                        net = ipaddress.ip_interface(f"{ip}/{prefix}").network
                        subnets.append(str(net))
                    except Exception:
                        pass
            return list(dict.fromkeys(subnets))
            
        for ip in ips:
            if not ip.startswith("127.") and not ip.startswith("169."):
                parts = ip.split(".")
                subnet = f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
                if subnet not in subnets:
                    subnets.append(subnet)
    except Exception:
        pass
    return list(dict.fromkeys(subnets)) or ["192.168.1.0/24"]