# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
config_manager.py — Network Monitor v4.0
Loads config.yaml into memory; writes back on UI changes.
Fix (V4.0 from V3.5): _save_config was missing (caused 500 on save notifications/thresholds/escalation).
"""
import os, threading, yaml
from pathlib import Path
from . import database as db
from . import crypto

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"
_lock   = threading.Lock()
_config = None


def load_config():
    global _config
    with _lock:
        _config = _load()
    return _config


def get_config():
    global _config
    if _config is None:
        return load_config()
    return _config


def _load():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            raw = f.read()
    except FileNotFoundError:
        raw = ""

    try:
        cfg = yaml.safe_load(raw) or {}
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        loc  = f" (line {mark.line+1}, column {mark.column+1})" if mark else ""
        err_msg = "config.yaml YAML error" + loc + ": " + str(getattr(exc,"problem",exc))
        raise SystemExit(err_msg) from None

    cfg.setdefault("defaults", {})
    cfg["defaults"].setdefault("poll_interval_seconds", 30)
    cfg["defaults"].setdefault("ping_timeout_ms", 1000)
    cfg["defaults"].setdefault("thresholds", {})
    cfg.setdefault("devices", [])
    cfg.setdefault("smtp", {})

    # Sanitise from_address (must be single email)
    fa = str(cfg["smtp"].get("from_address") or "")
    if "," in fa:
        parts = [p.strip() for p in fa.split(",") if p.strip()]
        cfg["smtp"]["from_address"] = parts[0]
        extras = parts[1:]
        adm = cfg["smtp"].get("admin_emails") or cfg["smtp"].get("to_addresses", [])
        for e in extras:
            if e not in adm:
                adm.append(e)

    cfg["smtp"].setdefault("admin_emails",   cfg["smtp"].get("to_addresses", []))
    cfg["smtp"].setdefault("manager_emails", [])
    cfg["smtp"].setdefault("support_emails", [])

    # Env-var password override
    env_pw = os.environ.get("NETMON_SMTP_PASSWORD")
    if env_pw:
        cfg["smtp"]["password"] = env_pw

    return cfg


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(cfg, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    global _config
    with _lock:
        _config = cfg

# Alias so internal calls using _save_config() work correctly
_save_config = save_config


def update_smtp(settings):
    cfg = get_config()
    smtp = cfg["smtp"]
    for k in ("enabled","host","port","use_tls","username","from_address",
              "admin_emails","manager_emails","support_emails",
              "resend_interval_minutes","to_addresses"):
        if k in settings:
            smtp[k] = settings[k]
    if settings.get("password"):
        smtp["password"] = settings["password"]
    if "admin_emails" in settings:
        smtp["to_addresses"] = settings["admin_emails"]
    save_config(cfg)
    return cfg


def add_or_update_device(device):
    cfg = get_config()
    # Encrypt credentials before persisting to config.yaml
    device_to_save = crypto.encrypt_device_creds(device)
    devices = cfg.get("devices", [])
    idx = next((i for i, d in enumerate(devices) if d["id"] == device["id"]), None)
    if idx is not None:
        devices[idx] = device_to_save
    else:
        devices.append(device_to_save)
    cfg["devices"] = devices
    save_config(cfg)
    return cfg


def remove_device(device_id):
    cfg = get_config()
    cfg["devices"] = [d for d in cfg["devices"] if d["id"] != device_id]
    save_config(cfg)
    db.purge_device(device_id)
    return cfg


def send_welcome_email(smtp_cfg, to_email, role, token, app_host="localhost:5000"):
    """Send welcome email with login credentials to a newly created or updated user."""
    import smtplib, ssl
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    if not smtp_cfg.get("enabled"):
        return False, "SMTP not enabled"

    subject = "Your Net-monit Access Credentials"
    html = f"""<html><body style="font-family:Arial,sans-serif;background:#0B0E14;padding:24px;">
<div style="max-width:480px;margin:auto;background:#12161F;border:1px solid #232A36;border-radius:8px;overflow:hidden;">
  <div style="background:#4FD1C5;padding:14px 20px;color:#07221F;font-weight:700;font-size:15px;">
    Net-monit — Account Created
  </div>
  <div style="padding:22px;color:#E6E9EF;">
    <p style="margin:0 0 16px;">Your Net-monit account is ready. Sign in using the credentials below.</p>
    <table style="width:100%;font-size:14px;">
      <tr><td style="color:#8B93A3;padding:5px 0;width:80px;">Email</td>
          <td style="color:#E6E9EF;font-family:monospace;">{to_email}</td></tr>
      <tr><td style="color:#8B93A3;padding:5px 0;">Token</td>
          <td style="color:#4FD1C5;font-family:monospace;font-weight:700;">{token}</td></tr>
      <tr><td style="color:#8B93A3;padding:5px 0;">Role</td>
          <td style="color:#E6E9EF;">{role}</td></tr>
    </table>
    <div style="margin:16px 0;padding:12px;background:#0B0E14;border-radius:6px;">
      <p style="margin:0 0 6px;font-size:12px;color:#8B93A3;">Dashboard URL:</p>
      <a href="http://{app_host}" style="color:#4FD1C5;font-family:monospace;font-size:13px;">http://{app_host}</a>
    </div>
    <p style="color:#5B6472;font-size:12px;margin:0;">Keep your token secure — it is stored as a one-way hash and cannot be recovered.</p>
  </div>
</div></body></html>"""
    plain = "Net-monit Account\nEmail: " + to_email + "\nToken: " + token + "\nRole: " + role + "\nDashboard: http://" + app_host

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = smtp_cfg.get("from_address") or smtp_cfg.get("username","")
    msg["To"]      = to_email
    msg.attach(MIMEText(plain,"plain"))
    msg.attach(MIMEText(html,"html"))

    try:
        ctx = ssl.create_default_context()
        with smtplib.SMTP(smtp_cfg["host"], smtp_cfg.get("port",587), timeout=15) as s:
            if smtp_cfg.get("use_tls",True): s.starttls(context=ctx)
            if smtp_cfg.get("username"):     s.login(smtp_cfg["username"], smtp_cfg["password"])
            s.sendmail(msg["From"], [to_email], msg.as_string())
        return True, "Sent"
    except Exception as e:
        return False, str(e)


# ── V4.0 save helpers ────────────────────────────────────────────────
def update_notifications(settings: dict):
    cfg = get_config()
    cfg.setdefault("notifications", {}).update(settings)
    save_config(cfg)   # FIX: was _save_config(cfg) which was undefined


def update_global_thresholds(thresholds: dict):
    cfg = get_config()
    cfg["global_thresholds"] = thresholds
    save_config(cfg)   # FIX: was _save_config(cfg) which was undefined


def update_escalation_defaults(defaults: dict):
    cfg = get_config()
    cfg["escalation_defaults"] = defaults
    save_config(cfg)   # FIX: was _save_config(cfg) which was undefined
