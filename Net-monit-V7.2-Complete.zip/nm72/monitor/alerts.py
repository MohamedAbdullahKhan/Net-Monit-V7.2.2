# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
alerts.py  —  Network Monitor v4.0
Threshold evaluation + per-device alert routing with multi-level escalation.

Escalation levels:
  Level 1 — first escalation (escalation_emails_l1)
  Level 2 — second escalation (escalation_emails_l2)
  Level 3 — third escalation  (escalation_emails_l3)
  escalation_levels: 1 | 2 | 3   (how many levels active; default 1)
  Each level triggers after its own time threshold (escalation_after_sec_l1/l2/l3).

Default notifications:
  All alerts always CC admin_emails (global SMTP setting) regardless of
  per-device notify_emails, so admin is always in the loop.
  Support group is always CCd on warning+.
"""
import time
from . import database as db
from . import email_notifier

STATE_RANK = {"ok": 0, "warning": 1, "critical": 2, "offline": 3}

DEFAULT_THRESHOLDS = {
    "latency_ms":      {"warning": 100,  "critical": 300},
    "packet_loss_pct": {"warning": 5,    "critical": 20},
    "cpu_pct":         {"warning": 75,   "critical": 90},
    "memory_pct":      {"warning": 80,   "critical": 95},
    "disk_pct":        {"warning": 80,   "critical": 95},
    "bandwidth_pct":   {"warning": 70,   "critical": 90},
}


def evaluate_metric_state(value, thresholds):
    if value is None or not thresholds:
        return "ok"
    if not thresholds.get("enabled", True):
        return "ok"
    c = thresholds.get("critical")
    w = thresholds.get("warning")
    if c is not None and value >= c:
        return "critical"
    if w is not None and value >= w:
        return "warning"
    return "ok"


def evaluate_device(device, metrics, global_thresholds, device_notify=None):
    """
    Returns (overall_status, metric_states)
    metric_states: {metric: (state, value, thresholds_used)}
    """
    if not metrics.get("reachable", False):
        return "offline", {"availability": ("offline", 0, None)}

    eff = {**DEFAULT_THRESHOLDS}
    eff.update(global_thresholds or {})
    eff.update(device.get("thresholds") or {})
    if device_notify:
        eff.update(device_notify.get("thresholds") or {})

    metric_states = {}
    worst = "ok"
    KEYS = ["latency_ms", "packet_loss_pct", "cpu_pct", "memory_pct",
            "disk_pct", "bandwidth_pct"]

    for key in KEYS:
        if key not in metrics:
            continue
        thr   = eff.get(key)
        state = evaluate_metric_state(metrics[key], thr)
        metric_states[key] = (state, metrics[key], thr)
        if STATE_RANK.get(state, 0) > STATE_RANK.get(worst, 0):
            worst = state

    if not metric_states:
        worst = "ok"
        metric_states["availability"] = ("ok", 1, None)

    return worst, metric_states


def process_alerts(device, metric_states, smtp_cfg, resend_interval_minutes,
                   device_notify=None):
    """
    Multi-level escalation support:
      escalation_levels: 1 | 2 | 3
      escalation_after_sec_l1 / _l2 / _l3
      escalation_emails_l1 / _l2 / _l3

    Admin CC default: admin_emails from smtp_cfg always CC'd on every alert.
    Support CC default: always CC'd on warning+.
    """
    did   = device["id"]
    dname = device["name"]
    host  = device["host"]
    now   = time.time()
    resend_sec = resend_interval_minutes * 60

    dn = device_notify or {}
    notif_enabled   = bool(dn.get("notifications_enabled", 1))
    esc_levels      = int(dn.get("escalation_levels", 1))  # 1-3
    esc_sec_l1      = int(dn.get("escalation_after_sec_l1", dn.get("escalation_after_sec", 300)))
    esc_sec_l2      = int(dn.get("escalation_after_sec_l2", esc_sec_l1 * 2))
    esc_sec_l3      = int(dn.get("escalation_after_sec_l3", esc_sec_l1 * 3))

    for metric, (state, value, thresholds) in metric_states.items():
        # V7.2: if this device+metric's active alert has been Acknowledged
        # by an admin, suppress further escalation emails until the
        # suppression window (23:59:59 the day it was acknowledged) passes.
        # upsert_active_alert() reopens it as a fresh cycle automatically
        # once that window expires, so this check only needs to look at
        # current DB state -- no separate timer logic required here.
        if state in ("warning", "critical"):
            open_alerts = db.get_active_alerts(status_filter="acknowledged", limit=500)
            suppressed  = any(
                a["device_id"] == did and a["metric"] == metric
                and a.get("ack_until_ts") and time.time() <= a["ack_until_ts"]
                for a in open_alerts
            )
            if suppressed:
                continue

        prev        = db.get_alert_state(did, metric) or {}
        prev_state  = prev.get("current_state", "ok")
        last_ts     = prev.get("last_email_ts", 0) or 0
        worst       = prev.get("worst_state", "ok")
        started_ts  = prev.get("alert_started_ts")
        esc_reached = int(prev.get("escalated", 0))  # bitmask: bit0=L1, bit1=L2, bit2=L3

        should_email = False
        email_state  = state
        new_esc_level = 0  # which level fires this round

        if state in ("warning", "critical", "offline"):
            if state != prev_state:
                should_email = True
                started_ts   = now
                esc_reached  = 0
            elif (now - last_ts) >= resend_sec:
                should_email = True

            if STATE_RANK.get(state, 0) > STATE_RANK.get(worst, 0):
                worst = state

            # Multi-level escalation checks
            if started_ts:
                elapsed = now - started_ts
                if esc_levels >= 3 and not (esc_reached & 4) and elapsed >= esc_sec_l3:
                    new_esc_level = 3
                    should_email  = True
                elif esc_levels >= 2 and not (esc_reached & 2) and elapsed >= esc_sec_l2:
                    new_esc_level = 2
                    should_email  = True
                elif esc_levels >= 1 and not (esc_reached & 1) and elapsed >= esc_sec_l1:
                    new_esc_level = 1
                    should_email  = True

        elif state == "ok" and prev_state in ("warning", "critical", "offline"):
            should_email = True
            email_state  = "recovered"
            started_ts   = None
            esc_reached  = 0

        # Build notify context
        notify_ctx = dict(dn)
        notify_ctx["escalation_level_fired"] = new_esc_level
        notify_ctx["escalated"] = new_esc_level > 0 or bool(esc_reached)

        thr_display = None
        if thresholds:
            thr_display = (thresholds.get("critical") if state == "critical"
                           else thresholds.get("warning"))

        emailed = False
        if should_email and notif_enabled:
            ok, _ = email_notifier.send_alert_email(
                smtp_cfg, dname, host, metric, value, email_state,
                threshold=thr_display,
                recovered_from=worst if email_state == "recovered" else None,
                device_notify=notify_ctx,
            )
            emailed = ok

        # Update escalation bitmask
        if new_esc_level == 1:
            esc_reached |= 1
        elif new_esc_level == 2:
            esc_reached |= 3  # L1+L2
        elif new_esc_level == 3:
            esc_reached |= 7  # L1+L2+L3

        next_worst    = "ok"       if email_state == "recovered" else worst
        next_escalated= 0          if email_state == "recovered" else esc_reached
        next_started  = started_ts
        new_last_ts   = (now if (should_email and emailed) else last_ts)

        if state != prev_state or should_email or new_esc_level:
            db.set_alert_state(did, metric, state, new_last_ts,
                               worst_state=next_worst,
                               alert_started_ts=next_started,
                               escalated=next_escalated)
            msg = _msg(dname, metric, value, email_state, thr_display)
            db.log_alert(did, dname, metric,
                         value if isinstance(value, (int, float)) else 0,
                         email_state, msg, emailed)


def _msg(device_name, metric, value, state, threshold):
    ml = metric.replace("_", " ")
    if state == "recovered":
        return f"{device_name}: {ml} back to normal ({value})"
    if state == "offline":
        return f"{device_name}: device is unreachable"
    ts = f" (threshold {threshold})" if threshold is not None else ""
    return f"{device_name}: {ml} is {state.upper()} at {value}{ts}"
