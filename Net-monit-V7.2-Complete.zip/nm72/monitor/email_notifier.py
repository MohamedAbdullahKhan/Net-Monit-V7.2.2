# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
email_notifier.py  —  Network Monitor v4.0
Multi-level escalation + default admin/support CC on all alerts.

Routing rules:
  To  : per-device notify_emails  (falls back to global admin_emails)
  Cc  : support_emails always on warning+
        manager_emails on critical
        admin_emails CC'd on EVERY alert (default always-in-loop)
        + escalation emails added when their level fires
"""
import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

STATE_COLORS = {"warning":"#F2B84B","critical":"#FF5C5C","recovered":"#3DD68C","offline":"#888888"}
STATE_LABELS = {"warning":"WARNING","critical":"CRITICAL","recovered":"RECOVERED","offline":"OFFLINE"}
STATE_BG     = {"warning":"#2A2000","critical":"#280000","recovered":"#002010","offline":"#1A1A1A"}
ESC_COLORS   = {1:"#F2B84B", 2:"#FF8C00", 3:"#FF5C5C"}
ESC_LABELS   = {1:"ESCALATION L1", 2:"ESCALATION L2", 3:"ESCALATION L3"}


def _dedup(lst):
    seen = set()
    return [x for x in lst if x and not (x in seen or seen.add(x))]


def _pick_recipients(smtp_cfg, device_notify, state, recovered_from=None):
    """
    Returns (to_list, cc_list).
    Admin emails are ALWAYS CC'd (default always-in-loop behaviour).
    Support is CC on warning+.
    Managers CC on critical.
    Escalation emails added per active level.
    """
    admins   = smtp_cfg.get("admin_emails") or smtp_cfg.get("to_addresses", [])
    managers = smtp_cfg.get("manager_emails", [])
    support  = smtp_cfg.get("support_emails", [])

    dn = device_notify or {}
    dev_to       = dn.get("notify_emails", []) or admins
    esc_l1_emails= dn.get("escalation_emails_l1", dn.get("escalation_emails", []))
    esc_l2_emails= dn.get("escalation_emails_l2", [])
    esc_l3_emails= dn.get("escalation_emails_l3", [])
    fired_level  = int(dn.get("escalation_level_fired", 0))

    eff = recovered_from if state == "recovered" else state

    to_list = _dedup(dev_to)

    # Build CC: always include admins (default always-in-loop)
    cc_list = _dedup(support + admins)
    if eff == "critical":
        cc_list = _dedup(cc_list + managers)

    # Add escalation emails for fired level (and all lower levels already CC'd)
    if fired_level >= 1:
        cc_list = _dedup(cc_list + esc_l1_emails)
    if fired_level >= 2:
        cc_list = _dedup(cc_list + esc_l2_emails)
    if fired_level >= 3:
        cc_list = _dedup(cc_list + esc_l3_emails)

    # Remove anyone already in To from Cc
    cc_list = [e for e in cc_list if e not in to_list]
    return to_list, cc_list


def send_alert_email(smtp_cfg, device_name, device_host, metric, value,
                     state, threshold=None, recovered_from=None,
                     device_notify=None):
    if not smtp_cfg.get("enabled", False):
        return False, "Email alerts disabled"

    to_list, cc_list = _pick_recipients(smtp_cfg, device_notify, state, recovered_from)
    if not to_list:
        return False, "No recipients configured"

    dn           = device_notify or {}
    fired_level  = int(dn.get("escalation_level_fired", 0))
    is_esc       = fired_level > 0

    label  = ESC_LABELS.get(fired_level, STATE_LABELS.get(state, state.upper())) if is_esc else STATE_LABELS.get(state, state.upper())
    color  = ESC_COLORS.get(fired_level, STATE_COLORS.get(state, "#888888")) if is_esc else STATE_COLORS.get(state, "#888888")
    bg     = STATE_BG.get(state, "#12161F")
    ts     = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    val_str= f"{value:.1f}" if isinstance(value, (int, float)) else str(value)
    thr_str= f"  (threshold: {threshold})" if threshold is not None else ""
    subject= f"[{label}] {device_name} — {metric.replace('_',' ')}"

    esc_banner = ""
    if is_esc:
        esc_banner = f"""<div style="background:#3A1500;border:1px solid {color};border-radius:6px;padding:10px 14px;margin-bottom:14px;">
  <span style="color:{color};font-weight:700;font-size:12px;">⚡ ESCALATION LEVEL {fired_level}</span>
  <span style="color:#aaa;font-size:12px;margin-left:10px;">Alert has been active and unresolved — escalated to level {fired_level} recipients.</span>
</div>"""

    text = (
        f"Network Monitor Alert [{label}]\n======================\n"
        f"Device:    {device_name} ({device_host})\n"
        f"Metric:    {metric}\nValue:     {val_str}{thr_str}\n"
        f"State:     {label}\nTime:      {ts}\n"
    )
    if is_esc:
        text += f"Escalation: Level {fired_level}\n"

    html = f"""<html><body style="margin:0;padding:24px;background:#0B0E14;font-family:Arial,sans-serif;">
<div style="max-width:520px;margin:auto;background:{bg};border:1px solid {color}33;border-radius:10px;overflow:hidden;">
  <div style="background:{color};padding:16px 22px;">
    <span style="font-weight:800;font-size:13px;letter-spacing:1px;color:#0B0E14;">{label}</span>
    <span style="float:right;font-size:12px;color:#0B0E14;opacity:.7;">{ts}</span>
  </div>
  <div style="padding:22px;color:#E6E9EF;">
    {esc_banner}
    <h2 style="margin:0 0 14px;font-size:20px;color:#fff;">{device_name}</h2>
    <table style="width:100%;font-size:14px;border-collapse:collapse;">
      <tr><td style="padding:6px 0;color:#888;width:110px;">Host</td>
          <td style="color:#E6E9EF;">{device_host}</td></tr>
      <tr><td style="padding:6px 0;color:#888;">Metric</td>
          <td style="color:#E6E9EF;">{metric.replace("_"," ")}</td></tr>
      <tr><td style="padding:6px 0;color:#888;">Value</td>
          <td style="color:{color};font-weight:700;font-size:16px;">{val_str}{thr_str}</td></tr>
      <tr><td style="padding:6px 0;color:#888;">Threshold</td>
          <td style="color:#aaa;">{threshold if threshold is not None else "—"}</td></tr>
    </table>
  </div>
  <div style="padding:10px 22px 16px;color:#555;font-size:12px;border-top:1px solid #232A36;">
    Sent by Net-monit V5.0 &nbsp;·&nbsp; {ts}
  </div>
</div></body></html>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = smtp_cfg.get("from_address") or smtp_cfg.get("username", "")
    msg["To"]      = ", ".join(to_list)
    if cc_list:
        msg["Cc"]  = ", ".join(cc_list)
    msg.attach(MIMEText(text, "plain"))
    msg.attach(MIMEText(html, "html"))

    all_rcpt = _dedup(to_list + cc_list)
    try:
        if smtp_cfg.get("use_tls", True):
            ctx = ssl.create_default_context()
            with smtplib.SMTP(smtp_cfg["host"], smtp_cfg["port"], timeout=15) as s:
                s.starttls(context=ctx)
                s.login(smtp_cfg["username"], smtp_cfg["password"])
                s.sendmail(msg["From"], all_rcpt, msg.as_string())
        else:
            with smtplib.SMTP_SSL(smtp_cfg["host"], smtp_cfg["port"], timeout=15) as s:
                s.login(smtp_cfg["username"], smtp_cfg["password"])
                s.sendmail(msg["From"], all_rcpt, msg.as_string())
        return True, "Sent"
    except Exception as exc:
        return False, str(exc)
