# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
database.py  —  Network Monitor v4.0
SQLite storage — extended for multi-level escalation in device_notify.
"""
import json
import sqlite3
import time
import threading
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "monitor.db"
_lock = threading.Lock()


def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = get_connection()
    with conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS device_status (
                device_id      TEXT PRIMARY KEY,
                name           TEXT,
                type           TEXT,
                method         TEXT,
                host           TEXT,
                status         TEXT DEFAULT 'unknown',
                last_checked   REAL,
                last_error     TEXT,
                metrics_json   TEXT
            );
            CREATE TABLE IF NOT EXISTS metric_history (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id   TEXT,
                metric      TEXT,
                value       REAL,
                state       TEXT,
                ts          REAL
            );
            CREATE TABLE IF NOT EXISTS alert_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id   TEXT,
                device_name TEXT,
                metric      TEXT,
                value       REAL,
                state       TEXT,
                message     TEXT,
                ts          REAL,
                emailed     INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS alert_state (
                device_id           TEXT,
                metric              TEXT,
                current_state       TEXT,
                last_email_ts       REAL,
                worst_state         TEXT DEFAULT 'ok',
                alert_started_ts    REAL,
                escalated           INTEGER DEFAULT 0,
                PRIMARY KEY (device_id, metric)
            );
            CREATE TABLE IF NOT EXISTS dashboard_tiles (
                device_id   TEXT PRIMARY KEY,
                position    INTEGER DEFAULT 0,
                hidden      INTEGER DEFAULT 0
            );
            -- V5.0: per-user dashboard tile layout (position/size/hidden/width/height)
            -- Falls back to the global dashboard_tiles table when a user has no
            -- saved layout of their own (e.g. first login, or anonymous viewers).
            CREATE TABLE IF NOT EXISTS user_tile_layout (
                email       TEXT NOT NULL,
                device_id   TEXT NOT NULL,
                position    INTEGER DEFAULT 0,
                hidden      INTEGER DEFAULT 0,
                size        TEXT DEFAULT 'normal',
                grid_w      INTEGER DEFAULT 1,
                grid_h      INTEGER DEFAULT 1,
                PRIMARY KEY (email, device_id)
            );
            -- V5.0: per-user dashboard view preferences (view type, grid density)
            CREATE TABLE IF NOT EXISTS user_prefs_kv (
                email     TEXT NOT NULL,
                pref_key  TEXT NOT NULL,
                pref_value TEXT DEFAULT '',
                PRIMARY KEY (email, pref_key)
            );
                        CREATE TABLE IF NOT EXISTS user_dashboard_prefs (
                email       TEXT PRIMARY KEY,
                view_type   TEXT DEFAULT 'grid',
                grid_cols   INTEGER DEFAULT 0
            );
            -- email_users: role = admin | user
            CREATE TABLE IF NOT EXISTS email_users (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                email       TEXT UNIQUE NOT NULL,
                email_hash  TEXT NOT NULL,
                role        TEXT NOT NULL DEFAULT 'user',
                token_hash  TEXT NOT NULL,
                active      INTEGER DEFAULT 1,
                created_ts  REAL
            );
            -- device_notify: extended for multi-level escalation (V3.4)
            CREATE TABLE IF NOT EXISTS device_notify (
                device_id                   TEXT PRIMARY KEY,
                notifications_enabled       INTEGER DEFAULT 1,
                notify_emails_json          TEXT DEFAULT '[]',
                -- L1 escalation (was escalation_emails in V3.3)
                escalation_emails_l1_json   TEXT DEFAULT '[]',
                -- L2 escalation
                escalation_emails_l2_json   TEXT DEFAULT '[]',
                -- L3 escalation
                escalation_emails_l3_json   TEXT DEFAULT '[]',
                -- time thresholds per level (seconds)
                escalation_after_sec_l1     INTEGER DEFAULT 300,
                escalation_after_sec_l2     INTEGER DEFAULT 600,
                escalation_after_sec_l3     INTEGER DEFAULT 1200,
                -- how many levels are active (1, 2, or 3)
                escalation_levels           INTEGER DEFAULT 1,
                thresholds_json             TEXT DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                actor       TEXT,
                action      TEXT,
                target      TEXT,
                detail      TEXT,
                ts          REAL
            );
            CREATE TABLE IF NOT EXISTS license_record (
                id              INTEGER PRIMARY KEY CHECK (id = 1),
                device_id       TEXT,
                activation_code TEXT,
                license_key     TEXT DEFAULT '',
                trial_start     REAL,
                activated       INTEGER DEFAULT 0
            );
        """)

        def _cols(table):
            return [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]

        # Schema migrations for existing databases (V3.3 → V3.4)
        migrations = [
            ("worst_state",             "alert_state",  "TEXT DEFAULT 'ok'"),
            ("alert_started_ts",        "alert_state",  "REAL"),
            ("escalated",               "alert_state",  "INTEGER DEFAULT 0"),
            # V7.2 fix: dashboard_tiles was only ever created with
            # (device_id, position, hidden) but get_dashboard_layout()'s
            # fallback path selects size/col/row too -- this was crashing
            # every single logged-in /api/status call with
            # "sqlite3.OperationalError: no such column: size".
            ("size", "dashboard_tiles", "TEXT DEFAULT 'normal'"),
            ("col",  "dashboard_tiles", "INTEGER DEFAULT 0"),
            ("row",  "dashboard_tiles", "INTEGER DEFAULT 0"),
            ("escalation_emails_l1_json","device_notify","TEXT DEFAULT '[]'"),
            ("escalation_emails_l2_json","device_notify","TEXT DEFAULT '[]'"),
            ("escalation_emails_l3_json","device_notify","TEXT DEFAULT '[]'"),
            ("escalation_after_sec_l1", "device_notify","INTEGER DEFAULT 300"),
            ("escalation_after_sec_l2", "device_notify","INTEGER DEFAULT 600"),
            ("escalation_after_sec_l3", "device_notify","INTEGER DEFAULT 1200"),
            ("escalation_levels",       "device_notify","INTEGER DEFAULT 1"),
        ]
        for col, tbl, defn in migrations:
            if col not in _cols(tbl):
                conn.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {defn}")

        # Migrate old escalation_emails_json → escalation_emails_l1_json
        old_cols = _cols("device_notify")
        if "escalation_emails_json" in old_cols:
            conn.execute("""
                UPDATE device_notify
                SET escalation_emails_l1_json = escalation_emails_json
                WHERE escalation_emails_l1_json = '[]' AND escalation_emails_json != '[]'
            """)
        if "escalation_after_sec" in old_cols:
            conn.execute("""
                UPDATE device_notify
                SET escalation_after_sec_l1 = escalation_after_sec
                WHERE escalation_after_sec_l1 = 300 AND escalation_after_sec != 300
            """)

    conn.close()


# ============================================================
# Device status
# ============================================================
def purge_device(device_id):
    with _lock:
        conn = get_connection()
        with conn:
            for tbl in ("device_status", "metric_history", "alert_state",
                        "dashboard_tiles", "device_notify", "user_tile_layout"):
                conn.execute(f"DELETE FROM {tbl} WHERE device_id=?", (device_id,))
        conn.close()


def upsert_device_status(device_id, name, dtype, method, host, status, metrics, error=None):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO device_status
                    (device_id, name, type, method, host, status, last_checked, last_error, metrics_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(device_id) DO UPDATE SET
                    name=excluded.name, type=excluded.type, method=excluded.method,
                    host=excluded.host, status=excluded.status,
                    last_checked=excluded.last_checked,
                    last_error=excluded.last_error, metrics_json=excluded.metrics_json
            """, (device_id, name, dtype, method, host, status,
                  time.time(), error, json.dumps(metrics or {})))
        conn.close()


def get_all_device_status():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM device_status ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Metric history
# ============================================================
def record_metric(device_id, metric, value, state):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute(
                "INSERT INTO metric_history (device_id,metric,value,state,ts) VALUES (?,?,?,?,?)",
                (device_id, metric, value, state, time.time()))
            conn.execute("DELETE FROM metric_history WHERE ts<?", (time.time() - 14 * 86400,))
        conn.close()


def get_metric_history(device_id, metric, since_seconds=3600):
    conn = get_connection()
    rows = conn.execute(
        "SELECT value,state,ts FROM metric_history WHERE device_id=? AND metric=? AND ts>? ORDER BY ts ASC",
        (device_id, metric, time.time() - since_seconds)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Alert state + log
# ============================================================
def get_alert_state(device_id, metric):
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM alert_state WHERE device_id=? AND metric=?",
        (device_id, metric)).fetchone()
    conn.close()
    return dict(row) if row else None


def set_alert_state(device_id, metric, state, last_email_ts,
                    worst_state=None, alert_started_ts=None, escalated=None):
    with _lock:
        conn = get_connection()
        prev = conn.execute(
            "SELECT * FROM alert_state WHERE device_id=? AND metric=?",
            (device_id, metric)).fetchone()
        prev = dict(prev) if prev else {}
        ws  = worst_state      if worst_state      is not None else prev.get("worst_state", "ok")
        ast = alert_started_ts if alert_started_ts is not None else prev.get("alert_started_ts")
        esc = escalated        if escalated         is not None else prev.get("escalated", 0)
        with conn:
            conn.execute("""
                INSERT INTO alert_state
                    (device_id, metric, current_state, last_email_ts, worst_state,
                     alert_started_ts, escalated)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(device_id, metric) DO UPDATE SET
                    current_state=excluded.current_state,
                    last_email_ts=excluded.last_email_ts,
                    worst_state=excluded.worst_state,
                    alert_started_ts=excluded.alert_started_ts,
                    escalated=excluded.escalated
            """, (device_id, metric, state, last_email_ts, ws, ast, esc))
        conn.close()


def log_alert(device_id, device_name, metric, value, state, message, emailed):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO alert_log
                    (device_id, device_name, metric, value, state, message, ts, emailed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (device_id, device_name, metric, value, state, message, time.time(), int(emailed)))
        conn.close()


def get_recent_alerts(limit=100):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM alert_log ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Dashboard tile layout
# ============================================================
def get_tile_layout():
    conn = get_connection()
    # Ensure size column exists (V3.5)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(dashboard_tiles)").fetchall()]
    if "size" not in cols:
        conn.execute("ALTER TABLE dashboard_tiles ADD COLUMN size TEXT DEFAULT 'normal'")
        conn.commit()
    rows = conn.execute("SELECT * FROM dashboard_tiles").fetchall()
    conn.close()
    result = {}
    for r in rows:
        rd = dict(r)
        result[rd["device_id"]] = {
            "position": rd["position"],
            "hidden":   bool(rd["hidden"]),
            "size":     rd.get("size", "normal"),
        }
    return result


def set_tile_size(device_id, size="normal"):
    """Store tile size preference: normal | wide | tall"""
    with _lock:
        conn = get_connection()
        cols = [r[1] for r in conn.execute("PRAGMA table_info(dashboard_tiles)").fetchall()]
        if "size" not in cols:
            with conn:
                conn.execute("ALTER TABLE dashboard_tiles ADD COLUMN size TEXT DEFAULT 'normal'")
        with conn:
            conn.execute("""
                INSERT INTO dashboard_tiles (device_id, position, hidden, size)
                VALUES (?, COALESCE((SELECT position FROM dashboard_tiles WHERE device_id=?), 0),
                        COALESCE((SELECT hidden FROM dashboard_tiles WHERE device_id=?), 0), ?)
                ON CONFLICT(device_id) DO UPDATE SET size=excluded.size
            """, (device_id, device_id, device_id, size))
        conn.close()


def set_tile_hidden(device_id, hidden):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO dashboard_tiles (device_id, position, hidden)
                VALUES (?, COALESCE((SELECT position FROM dashboard_tiles WHERE device_id=?), 0), ?)
                ON CONFLICT(device_id) DO UPDATE SET hidden=excluded.hidden
            """, (device_id, device_id, int(hidden)))
        conn.close()


def set_tile_order(device_ids):
    with _lock:
        conn = get_connection()
        with conn:
            for pos, did in enumerate(device_ids):
                conn.execute("""
                    INSERT INTO dashboard_tiles (device_id, position, hidden)
                    VALUES (?, ?, COALESCE((SELECT hidden FROM dashboard_tiles WHERE device_id=?), 0))
                    ON CONFLICT(device_id) DO UPDATE SET position=excluded.position
                """, (did, pos, did))
        conn.close()


# ============================================================
# V5.0: Per-user dashboard tile layout
# ============================================================
# Each user (identified by email) can have their own saved tile
# positions, sizes, and visibility. Anonymous/guest viewers and any
# user who has never customised their layout fall back to the global
# dashboard_tiles table above (get_tile_layout()).

def get_user_tile_layout(email):
    """Returns the per-user layout dict, or {} if the user has no saved layout."""
    if not email:
        return {}
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM user_tile_layout WHERE email=?", (email,)).fetchall()
    conn.close()
    result = {}
    for r in rows:
        rd = dict(r)
        result[rd["device_id"]] = {
            "position": rd["position"],
            "hidden":   bool(rd["hidden"]),
            "size":     rd.get("size", "normal"),
            "grid_w":   rd.get("grid_w", 1),
            "grid_h":   rd.get("grid_h", 1),
        }
    return result


def user_has_custom_layout(email):
    """True if this user has saved at least one tile layout row of their own."""
    if not email:
        return False
    conn = get_connection()
    row = conn.execute(
        "SELECT 1 FROM user_tile_layout WHERE email=? LIMIT 1", (email,)).fetchone()
    conn.close()
    return row is not None


def save_user_tile_layout(email, tiles):
    """
    Bulk-save a user's complete tile layout.
    tiles: list of dicts, each with device_id, position, hidden, size, grid_w, grid_h
    Replaces the user's entire saved layout in one transaction.
    """
    if not email:
        return
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("DELETE FROM user_tile_layout WHERE email=?", (email,))
            for t in tiles:
                conn.execute("""
                    INSERT INTO user_tile_layout
                        (email, device_id, position, hidden, size, grid_w, grid_h)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    email,
                    t.get("device_id"),
                    int(t.get("position", 0)),
                    int(bool(t.get("hidden", False))),
                    t.get("size", "normal"),
                    int(t.get("grid_w", 1)),
                    int(t.get("grid_h", 1)),
                ))
        conn.close()


def reset_user_tile_layout(email):
    """Delete a user's custom layout so they revert to the global default."""
    if not email:
        return
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("DELETE FROM user_tile_layout WHERE email=?", (email,))
        conn.close()


def get_user_dashboard_prefs(email):
    """Returns {'view_type': 'grid'|'list', 'grid_cols': int} for this user."""
    defaults = {"view_type": "grid", "grid_cols": 0}
    if not email:
        return defaults
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM user_dashboard_prefs WHERE email=?", (email,)).fetchone()
    conn.close()
    if not row:
        return defaults
    rd = dict(row)
    return {
        "view_type": rd.get("view_type") or "grid",
        "grid_cols": rd.get("grid_cols") or 0,
    }


def save_user_dashboard_prefs(email, view_type=None, grid_cols=None):
    if not email:
        return
    cur = get_user_dashboard_prefs(email)
    vt = view_type if view_type is not None else cur["view_type"]
    gc = grid_cols if grid_cols is not None else cur["grid_cols"]
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO user_dashboard_prefs (email, view_type, grid_cols)
                VALUES (?, ?, ?)
                ON CONFLICT(email) DO UPDATE SET
                    view_type=excluded.view_type,
                    grid_cols=excluded.grid_cols
            """, (email, vt, int(gc)))
        conn.close()


# ============================================================
# Per-device notification config (V3.4 multi-level escalation)
# ============================================================
def get_device_notify(device_id):
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM device_notify WHERE device_id=?", (device_id,)).fetchone()
    conn.close()
    if row:
        r = dict(row)
        r["notify_emails"]         = json.loads(r.get("notify_emails_json") or "[]")
        r["escalation_emails_l1"]  = json.loads(r.get("escalation_emails_l1_json") or "[]")
        r["escalation_emails_l2"]  = json.loads(r.get("escalation_emails_l2_json") or "[]")
        r["escalation_emails_l3"]  = json.loads(r.get("escalation_emails_l3_json") or "[]")
        r["thresholds"]            = json.loads(r.get("thresholds_json") or "{}")
        # Back-compat: escalation_emails = L1 list
        r["escalation_emails"]     = r["escalation_emails_l1"]
        r["escalation_after_sec"]  = r.get("escalation_after_sec_l1", 300)
        return r
    return {
        "device_id": device_id,
        "notifications_enabled": 1,
        "notify_emails": [],
        "escalation_emails_l1": [],
        "escalation_emails_l2": [],
        "escalation_emails_l3": [],
        "escalation_after_sec_l1": 300,
        "escalation_after_sec_l2": 600,
        "escalation_after_sec_l3": 1200,
        "escalation_levels": 1,
        "thresholds": {},
        "escalation_emails": [],
        "escalation_after_sec": 300,
    }


def set_device_notify(device_id, notifications_enabled, notify_emails,
                      escalation_emails_l1, escalation_emails_l2, escalation_emails_l3,
                      escalation_after_sec_l1, escalation_after_sec_l2, escalation_after_sec_l3,
                      escalation_levels, thresholds):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO device_notify
                    (device_id, notifications_enabled, notify_emails_json,
                     escalation_emails_l1_json, escalation_emails_l2_json, escalation_emails_l3_json,
                     escalation_after_sec_l1, escalation_after_sec_l2, escalation_after_sec_l3,
                     escalation_levels, thresholds_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(device_id) DO UPDATE SET
                    notifications_enabled=excluded.notifications_enabled,
                    notify_emails_json=excluded.notify_emails_json,
                    escalation_emails_l1_json=excluded.escalation_emails_l1_json,
                    escalation_emails_l2_json=excluded.escalation_emails_l2_json,
                    escalation_emails_l3_json=excluded.escalation_emails_l3_json,
                    escalation_after_sec_l1=excluded.escalation_after_sec_l1,
                    escalation_after_sec_l2=excluded.escalation_after_sec_l2,
                    escalation_after_sec_l3=excluded.escalation_after_sec_l3,
                    escalation_levels=excluded.escalation_levels,
                    thresholds_json=excluded.thresholds_json
            """, (device_id, int(notifications_enabled),
                  json.dumps(notify_emails),
                  json.dumps(escalation_emails_l1),
                  json.dumps(escalation_emails_l2),
                  json.dumps(escalation_emails_l3),
                  int(escalation_after_sec_l1),
                  int(escalation_after_sec_l2),
                  int(escalation_after_sec_l3),
                  int(escalation_levels),
                  json.dumps(thresholds)))
        conn.close()


def get_all_device_notify():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM device_notify").fetchall()
    conn.close()
    out = {}
    for r in rows:
        d = dict(r)
        d["notify_emails"]        = json.loads(d.get("notify_emails_json") or "[]")
        d["escalation_emails_l1"] = json.loads(d.get("escalation_emails_l1_json") or "[]")
        d["escalation_emails_l2"] = json.loads(d.get("escalation_emails_l2_json") or "[]")
        d["escalation_emails_l3"] = json.loads(d.get("escalation_emails_l3_json") or "[]")
        d["thresholds"]           = json.loads(d.get("thresholds_json") or "{}")
        out[d["device_id"]] = d
    return out


# ============================================================
# Email user registry
# ============================================================
def get_all_users():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM email_users ORDER BY role, email").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_user_by_email(email):
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM email_users WHERE email=? AND active=1", (email.lower(),)).fetchone()
    conn.close()
    return dict(row) if row else None


def add_user(email, role, token_hash):
    import hashlib
    email_hash = hashlib.sha256(email.lower().encode()).hexdigest()
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT INTO email_users (email, email_hash, role, token_hash, active, created_ts)
                VALUES (?, ?, ?, ?, 1, ?)
                ON CONFLICT(email) DO UPDATE SET
                    role=excluded.role, token_hash=excluded.token_hash,
                    email_hash=excluded.email_hash, active=1
            """, (email.lower(), email_hash, role, token_hash, time.time()))
        conn.close()


def delete_user(email):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("DELETE FROM email_users WHERE email=?", (email.lower(),))
        conn.close()


def validate_user(email_hash, token_hash):
    conn = get_connection()
    row = conn.execute(
        "SELECT role FROM email_users WHERE email_hash=? AND token_hash=? AND active=1",
        (email_hash, token_hash)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


# ============================================================
# Audit log
# ============================================================
def audit_log(actor, action, target, detail=""):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute(
                "INSERT INTO audit_log (actor,action,target,detail,ts) VALUES (?,?,?,?,?)",
                (actor, action, target, detail, time.time()))
        conn.close()


def get_audit_log(limit=200):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ============================================================
# License record
# ============================================================
def get_license_record():
    conn = get_connection()
    row = conn.execute("SELECT * FROM license_record WHERE id=1").fetchone()
    conn.close()
    return dict(row) if row else None

def set_license_record(device_id, activation_code, license_key, trial_start, activated):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute("""
                INSERT OR REPLACE INTO license_record
                    (id, device_id, activation_code, license_key, trial_start, activated)
                VALUES (1, ?, ?, ?, ?, ?)
            """, (device_id, activation_code, license_key, trial_start, activated))
        conn.close()

def set_license_activated(license_key):
    with _lock:
        conn = get_connection()
        with conn:
            conn.execute(
                "UPDATE license_record SET license_key=?, activated=1 WHERE id=1",
                (license_key,))
        conn.close()


# =============================================================================
# V7.2 ADDITIONS: per-user dashboard layout + user preferences
# =============================================================================

def get_user_pref(email: str, key: str):
    """Get a user preference value. Returns None if not set."""
    if not email:
        return None
    conn = get_connection()
    with conn:
        row = conn.execute(
            "SELECT pref_value FROM user_prefs_kv WHERE email=? AND pref_key=?",
            (email.lower(), key)
        ).fetchone()
    return row["pref_value"] if row else None


def set_user_pref(email: str, key: str, value: str):
    """Upsert a user preference."""
    if not email:
        return
    conn = get_connection()
    with conn:
        conn.execute(
            """INSERT INTO user_prefs_kv (email, pref_key, pref_value)
               VALUES (?, ?, ?)
               ON CONFLICT(email, pref_key) DO UPDATE SET pref_value=excluded.pref_value""",
            (email.lower(), key, str(value))
        )
        conn.commit()


def get_dashboard_layout(email: str) -> list:
    """
    Return per-user tile layout as list of dicts:
      [{device_id, position, hidden, size, col, row}, ...]
    Falls back to global dashboard_tiles table if no per-user layout saved.
    """
    if not email:
        return _get_global_layout()
    conn = get_connection()
    with conn:
        rows = conn.execute(
            """SELECT pref_value
               FROM user_prefs_kv
               WHERE email=? AND pref_key='tile_layout_v2'""",
            (email.lower(),)
        ).fetchone()
    if rows and rows["pref_value"]:
        try:
            import json
            return json.loads(rows["pref_value"])
        except Exception:
            pass
    return _get_global_layout()


def _get_global_layout() -> list:
    """Read from legacy dashboard_tiles table."""
    conn = get_connection()
    with conn:
        rows = conn.execute(
            "SELECT device_id, position, hidden, size, col, row FROM dashboard_tiles"
        ).fetchall()
    return [{"device_id": r["device_id"], "position": r["position"],
             "hidden": bool(r["hidden"]), "size": r["size"] or "normal",
             "col": r["col"] or 0, "row": r["row"] if r["row"] is not None else r["position"]} for r in rows]


def save_dashboard_layout(email: str, layout: list):
    """
    Save per-user tile layout. layout is list of dicts:
      [{device_id, position, hidden, size, col, row}, ...]
    """
    import json
    if not email:
        return
    layout_json = json.dumps(layout)
    conn = get_connection()
    with conn:
        conn.execute(
            """INSERT INTO user_prefs_kv (email, pref_key, pref_value)
               VALUES (?, 'tile_layout_v2', ?)
               ON CONFLICT(email, pref_key) DO UPDATE SET pref_value=excluded.pref_value""",
            (email.lower(), layout_json)
        )
        conn.commit()


# =============================================================================
# V7.2 NEW FEATURE TABLES: Speed Test | Network Scan
# =============================================================================

def _ensure_new_tables():
    """Create V7.2+ feature tables if they don't exist, and migrate new columns."""
    conn = get_connection()
    with conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS speedtest_history (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                ts            REAL,
                download_mbps REAL,
                upload_mbps   REAL,
                latency_ms    REAL,
                server        TEXT,
                method_used   TEXT,
                elapsed_sec   REAL
            );
            CREATE TABLE IF NOT EXISTS network_scan_jobs (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                subnet     TEXT,
                status     TEXT DEFAULT 'pending',
                result_json TEXT,
                created_ts REAL,
                updated_ts REAL
            );
        """)
        # V7.2: WAN telemetry columns (jitter, ISP, public IP) — added via
        # migration so upgrades from V6.x databases don't lose history.
        existing_cols = {row["name"] for row in
                          conn.execute("PRAGMA table_info(speedtest_history)").fetchall()}
        for col, coltype in (("jitter_ms", "REAL"),
                              ("isp", "TEXT"),
                              ("public_ip", "TEXT")):
            if col not in existing_cols:
                conn.execute(f"ALTER TABLE speedtest_history ADD COLUMN {col} {coltype}")
    conn.close()


def record_speedtest(result: dict):
    _ensure_new_tables()
    conn = get_connection()
    with conn:
        conn.execute(
            """INSERT INTO speedtest_history
               (ts, download_mbps, upload_mbps, latency_ms, jitter_ms, isp, public_ip,
                server, method_used, elapsed_sec)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (time.time(),
             result.get("download_mbps"),
             result.get("upload_mbps"),
             result.get("latency_ms"),
             result.get("jitter_ms"),
             result.get("isp", ""),
             result.get("public_ip", ""),
             result.get("server",""),
             result.get("method_used",""),
             result.get("elapsed_sec"))
        )
    conn.close()


def get_speedtest_history(limit: int = 50) -> list:
    _ensure_new_tables()
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM speedtest_history ORDER BY ts DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def clear_speedtest_history():
    """Delete all speed test history rows (used by the 'Purge Logs' button)."""
    _ensure_new_tables()
    conn = get_connection()
    with conn:
        conn.execute("DELETE FROM speedtest_history")
    conn.close()


def create_scan_job(subnet: str) -> int:
    _ensure_new_tables()
    conn = get_connection()
    with conn:
        cur = conn.execute(
            "INSERT INTO network_scan_jobs (subnet, status, created_ts, updated_ts) VALUES (?,?,?,?)",
            (subnet, "pending", time.time(), time.time())
        )
        job_id = cur.lastrowid
    conn.close()
    return job_id


def update_scan_job(job_id: int, status: str, result: dict | None):
    _ensure_new_tables()
    conn = get_connection()
    with conn:
        conn.execute(
            "UPDATE network_scan_jobs SET status=?, result_json=?, updated_ts=? WHERE id=?",
            (status, json.dumps(result) if result else None, time.time(), job_id)
        )
    conn.close()


def get_scan_job(job_id: int) -> dict | None:
    _ensure_new_tables()
    conn = get_connection()
    row  = conn.execute(
        "SELECT * FROM network_scan_jobs WHERE id=?", (job_id,)
    ).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    if d.get("result_json"):
        d["result"] = json.loads(d["result_json"])
    d.pop("result_json", None)
    return d


def get_scan_history(limit: int = 20) -> list:
    _ensure_new_tables()
    conn = get_connection()
    rows = conn.execute(
        "SELECT id, subnet, status, created_ts, updated_ts FROM network_scan_jobs ORDER BY id DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# =============================================================================
# V7.2: System-wide settings (admin-configured defaults, e.g. default theme)
# =============================================================================

def _ensure_system_settings_table():
    conn = get_connection()
    with conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS system_settings (
                setting_key   TEXT PRIMARY KEY,
                setting_value TEXT
            )
        """)
    conn.close()


def get_system_setting(key: str, default=None):
    _ensure_system_settings_table()
    conn = get_connection()
    row = conn.execute(
        "SELECT setting_value FROM system_settings WHERE setting_key=?", (key,)
    ).fetchone()
    conn.close()
    return row["setting_value"] if row else default


def set_system_setting(key: str, value: str):
    _ensure_system_settings_table()
    conn = get_connection()
    with conn:
        conn.execute(
            """INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
               ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value""",
            (key, str(value))
        )
    conn.close()


# =============================================================================
# V7.2: Active Alerts (Acknowledge / Resolve lifecycle)
# =============================================================================

def _ensure_active_alerts_table():
    conn = get_connection()
    with conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS active_alerts (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id       TEXT NOT NULL,
                device_name     TEXT,
                device_host     TEXT,
                metric          TEXT,
                severity        TEXT,      -- warning | critical
                message         TEXT,
                status          TEXT DEFAULT 'active',  -- active | acknowledged | resolved
                triggered_ts    REAL,
                acknowledged_ts REAL,
                acknowledged_by TEXT,
                ack_until_ts    REAL,      -- suppress re-escalation until this time
                resolved_ts     REAL,
                resolved_by     TEXT
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_active_alerts_lookup
            ON active_alerts (device_id, metric, status)
        """)
    conn.close()


def upsert_active_alert(device_id, device_name, device_host, metric, severity, message):
    """
    Create a new active alert row for this device+metric if one isn't
    already open (active or acknowledged). Returns the alert id.
    If an acknowledged alert's suppression window (ack_until_ts) has
    passed, it is reopened as a fresh 'active' alert (new escalation cycle).
    """
    _ensure_active_alerts_table()
    conn = get_connection()
    now = time.time()
    row = conn.execute(
        """SELECT * FROM active_alerts
           WHERE device_id=? AND metric=? AND status IN ('active','acknowledged')
           ORDER BY id DESC LIMIT 1""",
        (device_id, metric)
    ).fetchone()

    if row:
        r = dict(row)
        if r["status"] == "acknowledged" and r.get("ack_until_ts") and now > r["ack_until_ts"]:
            # Suppression window expired -- start a fresh escalation cycle
            with conn:
                conn.execute(
                    "UPDATE active_alerts SET status='active', severity=?, message=?, triggered_ts=? WHERE id=?",
                    (severity, message, now, r["id"])
                )
            conn.close()
            return r["id"]
        # Still open (active, or acknowledged and within suppression window) -- leave as-is
        conn.close()
        return r["id"]

    with conn:
        cur = conn.execute(
            """INSERT INTO active_alerts
               (device_id, device_name, device_host, metric, severity, message,
                status, triggered_ts)
               VALUES (?,?,?,?,?,?,'active',?)""",
            (device_id, device_name, device_host, metric, severity, message, now)
        )
        alert_id = cur.lastrowid
    conn.close()
    return alert_id


def auto_resolve_active_alerts(device_id, metric):
    """Called when a metric returns to 'ok' -- silently closes any open alert."""
    _ensure_active_alerts_table()
    conn = get_connection()
    now = time.time()
    with conn:
        conn.execute(
            """UPDATE active_alerts SET status='resolved', resolved_ts=?, resolved_by='system (auto-recovered)'
               WHERE device_id=? AND metric=? AND status IN ('active','acknowledged')""",
            (now, device_id, metric)
        )
    conn.close()


def acknowledge_alert(alert_id, by_email):
    """Acknowledge -- suppresses further escalation until 23:59:59 today."""
    _ensure_active_alerts_table()
    import datetime
    conn = get_connection()
    now = time.time()
    end_of_day = datetime.datetime.now().replace(hour=23, minute=59, second=59, microsecond=0).timestamp()
    with conn:
        conn.execute(
            """UPDATE active_alerts SET status='acknowledged', acknowledged_ts=?,
               acknowledged_by=?, ack_until_ts=? WHERE id=?""",
            (now, by_email, end_of_day, alert_id)
        )
    conn.close()


def resolve_alert(alert_id, by_email):
    _ensure_active_alerts_table()
    conn = get_connection()
    with conn:
        conn.execute(
            "UPDATE active_alerts SET status='resolved', resolved_ts=?, resolved_by=? WHERE id=?",
            (time.time(), by_email, alert_id)
        )
    conn.close()


def get_active_alerts(status_filter=None, limit=200):
    """status_filter: None (all), 'active', 'acknowledged', 'resolved'."""
    _ensure_active_alerts_table()
    conn = get_connection()
    if status_filter:
        rows = conn.execute(
            "SELECT * FROM active_alerts WHERE status=? ORDER BY triggered_ts DESC LIMIT ?",
            (status_filter, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM active_alerts ORDER BY triggered_ts DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_open_alerts():
    """Count of active + acknowledged (i.e. not yet resolved) alerts."""
    _ensure_active_alerts_table()
    conn = get_connection()
    row = conn.execute(
        "SELECT COUNT(*) as c FROM active_alerts WHERE status IN ('active','acknowledged')"
    ).fetchone()
    conn.close()
    return row["c"] if row else 0
