# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
crypto.py – Net-monit V5.0
Encrypts/decrypts device credentials stored in config.yaml.
Uses Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).
Key derived from a per-installation secret stored in data/secret.key.
If the key file does not exist it is generated on first run.
Encrypted values are stored as strings prefixed with "ENC:".
"""
import os
import base64
from pathlib import Path

_KEY_PATH = Path(__file__).resolve().parent.parent / "data" / "secret.key"
_fernet = None


def _get_fernet():
    global _fernet
    if _fernet is not None:
        return _fernet
    try:
        from cryptography.fernet import Fernet
    except ImportError:
        return None  # cryptography not installed — fall back to plaintext

    _KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    if _KEY_PATH.exists():
        key = _KEY_PATH.read_bytes().strip()
    else:
        key = Fernet.generate_key()
        _KEY_PATH.write_bytes(key)
        _KEY_PATH.chmod(0o600)

    _fernet = Fernet(key)
    return _fernet


def encrypt(plaintext: str) -> str:
    """Encrypt a string. Returns 'ENC:<base64>' or original if crypto unavailable."""
    if not plaintext:
        return plaintext
    if plaintext.startswith("ENC:"):
        return plaintext  # already encrypted
    f = _get_fernet()
    if f is None:
        return plaintext  # cryptography not installed
    token = f.encrypt(plaintext.encode())
    return "ENC:" + base64.urlsafe_b64encode(token).decode()


def decrypt(value: str) -> str:
    """Decrypt an 'ENC:...' string. Returns original if not encrypted."""
    if not value or not value.startswith("ENC:"):
        return value
    f = _get_fernet()
    if f is None:
        return value
    try:
        raw = base64.urlsafe_b64decode(value[4:])
        return f.decrypt(raw).decode()
    except Exception:
        return value  # return as-is if decryption fails


def is_encrypted(value: str) -> bool:
    return bool(value and value.startswith("ENC:"))


# Credential fields to encrypt/decrypt per device method
CRED_FIELDS = {
    "powershell": [("powershell", "password")],
    "ssh":        [("ssh", "password")],
    "disk_usage": [("disk", "password")],
    "snmp":       [],
    "ping":       [],
}


def encrypt_device_creds(device: dict) -> dict:
    """Encrypt credential fields before saving to config.yaml."""
    d = dict(device)
    method = d.get("method", "")
    for section, field in CRED_FIELDS.get(method, []):
        if section in d and isinstance(d[section], dict):
            sec = dict(d[section])
            if sec.get(field):
                sec[field] = encrypt(sec[field])
            d[section] = sec
    return d


def decrypt_device_creds(device: dict) -> dict:
    """Decrypt credential fields when loading from config.yaml for use by checkers."""
    d = dict(device)
    method = d.get("method", "")
    for section, field in CRED_FIELDS.get(method, []):
        if section in d and isinstance(d[section], dict):
            sec = dict(d[section])
            if sec.get(field):
                sec[field] = decrypt(sec[field])
            d[section] = sec
    return d
