# =============================================================================
# Net-monit V5.0
# Copyright (c) 2024-2026 Abdullah. All rights reserved.
# Contact: abuabdullah.be@outlook.com
# Unauthorised copying, modification or distribution of this software
# is strictly prohibited without prior written permission from the author.
# =============================================================================
"""
auth.py  —  Network Monitor v4.0
Two roles:
  admin — full access: dashboard + all config, devices, alerts, user mgmt
  user  — read-only dashboard only (status tiles, no host IPs, no config)

Default admin on first run:
  email : admin@email.com
  token : Admin@54321$
Both can be changed or deleted via the Admin Panel once logged in.
Stored as SHA-256 hashes — raw values never written to disk.
Sessions: 32-byte random hex, server-side in-memory dict, 1-hour idle TTL.
"""
import hashlib, secrets, time, threading
from . import database as db

AUTH_SESSION_TTL_SEC = 3600   # 1 hour idle

DEFAULT_ADMIN_EMAIL = "admin@email.com"
DEFAULT_ADMIN_TOKEN = "Admin@54321$"

_sessions = {}   # session_token -> {"email": str, "role": str, "last_seen": float}
_lock     = threading.Lock()


# ── hashing ────────────────────────────────────────────────────────────────
def _sha256(text: str) -> str:
    return hashlib.sha256(text.strip().encode()).hexdigest()


# ── token generation ───────────────────────────────────────────────────────
def generate_token() -> str:
    """Random 12-char token: upper + lower + digit + special."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%^&*"
    return "".join(secrets.choice(alphabet) for _ in range(12))


# ── user management ────────────────────────────────────────────────────────
def add_user(email: str, role: str, raw_token: str):
    """Hash the token and persist the user. role must be 'admin' or 'user'."""
    if role not in ("admin", "user"):
        role = "user"
    db.add_user(email.lower().strip(), role, _sha256(raw_token))


def seed_default_admin_if_empty():
    """
    Creates the default admin on first run if no users exist at all.
    Prints credentials to console — change them immediately via the Admin Panel.
    """
    if db.get_all_users():
        return   # already seeded
    add_user(DEFAULT_ADMIN_EMAIL, "admin", DEFAULT_ADMIN_TOKEN)
    print("\n" + "=" * 60)
    print("  FIRST-RUN DEFAULT ADMIN CREATED")
    print(f"  Email : {DEFAULT_ADMIN_EMAIL}")
    print(f"  Token : {DEFAULT_ADMIN_TOKEN}")
    print("  Log in via the Admin eye-button (top-right) and")
    print("  change or remove these credentials immediately.")
    print("=" * 60 + "\n")


# ── authentication ─────────────────────────────────────────────────────────
def attempt_login(email: str, raw_token: str):
    """
    Returns (session_token, role) if valid, else (None, None).
    Accepts both admin and user roles — callers decide what each can access.
    """
    eh = _sha256(email.lower().strip())
    th = _sha256(raw_token)
    user = db.validate_user(eh, th)   # returns {"role":...} or None
    if not user:
        return None, None
    sess = secrets.token_hex(32)
    with _lock:
        _sessions[sess] = {
            "email":     email.lower().strip(),
            "role":      user["role"],
            "last_seen": time.time(),
        }
    return sess, user["role"]


def validate_session(session_token: str):
    """
    Returns the session dict {"email", "role"} if valid, else None.
    Refreshes last_seen on every call.
    """
    if not session_token:
        return None
    with _lock:
        entry = _sessions.get(session_token)
        if not entry:
            return None
        if time.time() - entry["last_seen"] > AUTH_SESSION_TTL_SEC:
            del _sessions[session_token]
            return None
        entry["last_seen"] = time.time()
        return dict(entry)


def logout(session_token: str):
    with _lock:
        _sessions.pop(session_token, None)
